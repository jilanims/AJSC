#!/bin/bash
cd .
#chmod +x  main.sh

#variables
jmeter_version=5.1.1

cleanup_s(){
  echo "Stage::cleanup - Started"
  rm apache-jmeter*.zip
  rm -rf apache-jmeter*
  rm -rf reports/*
  rm tag-jmeter-extn-1.1.*
  rm http.csv
  rm sqs.csv
}
cleanup_i(){
rm -rf reports/$1
mkdir reports/$1
rm http.csv
rm sqs.csv
}

setup(){
  echo "Stage::Setup - Started at $(date)"
  echo "****Downloading Jmeter****"
  wget https://archive.apache.org/dist/jmeter/binaries/apache-jmeter-${jmeter_version}.zip
  echo "****Unzipping Jmeter****"
  unzip apache-jmeter-${jmeter_version}.zip

  echo "****Downloading Property File Reader from packages.atlassian.com, please enter your username and maven password token ****"
  #wget http://www.testautomationguru.com/download/87/ -O tag-jmeter-extn-1.1.zip
  #echo "****Unzipping Property File Reade****"
  #unzip tag-jmeter-extn-1.1.zip
  read -p "Enter Atlassian AD (without @atlassian.com): "  username
  read -p "Enter the API Key : "  token
  wget --server-response --user=$username --password=$token https://packages.atlassian.com/mvn/maven-internal/com/atlassian/mulesoft/jmeterext/tag-jmeter-extn/1.1/tag-jmeter-extn-1.1.jar

  if [[ $? -ne 0 ]]; then
    echo "****Error in getting the jar file from packages.atlassian.com, Please check above for error details.****"
    exit
  fi

  echo "****Copying Property File Reaser to /lib/ext****"
  mv tag-jmeter-extn-1.1.jar $(pwd)/apache-jmeter-${jmeter_version}/lib/ext
  ls -ltr $(pwd)/apache-jmeter-${jmeter_version}/lib/ext
  rm tag-jmeter-extn-1.1.zip
  # export path is not working when a jmeter has been already installed say for eg brew.
  $(pwd)/apache-jmeter-${jmeter_version}/bin/jmeter --version

}

if [ "$#" -lt 1 ]; then
    echo "****Invalid args. Use HTTP or SQS eg. ./main.sh HTTP"
    exit
fi

if [ -f apache-jmeter-${jmeter_version}.zip ]; then
  echo "****setup has been alredy done. skipping this step."
else
  cleanup_s
  setup
fi

echo "****Stage::Invoke - Started at $(date)"
cleanup_i
if [ "$1" == "HTTP" ]; then
    $(pwd)/apache-jmeter-${jmeter_version}/bin/jmeter -n -e -t HTTP/HTTP.jmx -o reports/$1 -l http.csv
elif [ "$1" == "SQS" ]; then
   $(pwd)/apache-jmeter-${jmeter_version}/bin/jmeter -n -e -t SQS/SQS.jmx -o reports/$1 -l sqs.csv -DACCESS_KEY=$ACCESS_KEY -DSECRET_KEY=$SECRET_KEY
else
  echo "****Invalid arguments. Use HTTP or SQS"
fi
echo "****Stage::Invoke - Ended at $(date)"
