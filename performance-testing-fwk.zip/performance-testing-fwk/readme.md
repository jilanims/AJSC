## Introduction

This page will provide details about how to load test your application by download the framework to a machine. The framework was designed in such a way that, as long as the user provides the required details in the properties file  ( while be covered in the upcoming sections ) and run the script file in the terminal of one’s choice, the load testing will be initiated. The load engine is based on JMeter.

Assumption: Java has been already installed on the machine.

### Details.

Below are the steps that need to be performed when using the Performance Testing Framework.

### Repo Download

clone the repo from https://stash.atlassian.com/projects/MOE/repos/performance-testing-fwk/browse, make sure the checkout is against “master” branch.

### Main.sh

After updating the load testing details in the properties file, one needs to execute this file in the terminal along with an argument ( HTTP/SQS). This file takes care of downloading the jmeter distribution, plugins and setting the necessary environment details, the jmeter command is called from within this file.

Note: CD to the above-cloned repo in your terminal before executing the main.sh

```
./main.sh HTTP  
or
./main.sh SQS
```

### Supported Protocols

#### HTTP

Under the home folder where you have cloned the repo, go to HTTP > http.properties. Here we have to update the target system details against which the load testing framework is going to be executed against for eg, headers, host, port, the number of users. let see each property in detail.

Note: when executing the .main.sh script, do pass the HTTP as an argument

##### Load testing details

The below three properties correspond to the number of users (threads), the ramp period(seconds) of these users and what should be the loop count. for eg, I would like to have 2 thread that needs to be loaded in a second and the iteration has to run for 10 times.

number_of_threads=2
ramp_up_period=1
loop_count=10

##### Target endpoint  details

The below properties are used to set the target system details against which the load testing will be initiated.

One can pass any number of headers to the target system but the prerequisite is the header name should be prefixed by “header__”

```
protocol=http
host=localhost
port=9090
path=/incrementcounter?email=test@c.aom
method=GET
#Header Details, format header__Your_Header.
#header__client_id=id
#header__client_secret=client_secret
header__Authorization=Basic asdfasdfpiasdfasdf
header__content-type=application/json
```

##### Random Number

In case if there is a need to generate a unique number for each thread execution and use it as part of the payload, there are two inbuilt random number will be generated, below are the details on the same. the usage is being shown in the next section

gen.rnd_1=true
rnd_1.min.value=10000
rnd_1.max.value=1000000
rnd_1.seed=3000

gen.rnd_2=true
rnd_2.min.value=1000
rnd_2.max.value=100000
rnd_2.seed=300

##### Payload

During POST or PUT calls, there would be a need to send an input payload and also there might need to send randomly generated value. Users can add the payload in the payload.txt. For the fields that need a Random value to be generated, use this expression ${rnd_1} or ${rnd_2} (currently, we are supporting tow random values, if a need arises, we can increase it)

Note: the eg has JSON payload, but one can use any format.

```
{
   "subaction":"Remove permissions",
   "properties":{
      "role_id" : "${rnd_1}",
      "context_params":{
         "org":"${__UUID()}",
         "envId":"${__UUID()}"
      },
      "name":"Cloudhub Network Administrator ${rnd_2}"
   }
}
```

#### SQS

Under the home folder where you have cloned the repo, go to SQS > sqs.properties. Here we have to update the SQS  details against which the load testing framework is going to be executed against for eg, credential, queue url, message attributes, the number of users. let see each property in detail.

Note: when executing the .main.sh script, do pass the SQS as an argument

##### Load testing details

The below three properties correspond to the number of users (threads), the ramp period(seconds) of these users and what should be the loop count. for eg, I would like to have 2 thread that needs to be loaded in a second and the iteration has to run for 10 times.

number_of_threads=2
ramp_up_period=1
loop_count=10

##### SQS  details

The below properties are used to set the target SQS  details against which the load testing will be initiated.

One can pass any number of message attributes to the target system but the prerequisite is the message attribute key/name should be prefixed by “msg_attribute__”

```
#Message Attributes.
#msg_attribute__source=BizSystem
#msg_attribute__content-type=application/json

##aws creds
msgDataType= String
accessKey =
secretKey =
queueUrl =
region=
```

In case, if the user doesn't want to use an accessKey and secretKey from a properties file, one can leverage the export option as well.

```
export ACCESS_KEY=YOUR_ACCESS_KEY
export SECRET_KEY=YOUR_SECRET_KEY
export AWS_REGION=YOUR_AWS_REGION
```

##### Random Number

In case if there is a need to generate a unique number for each thread execution and use it as part of the payload, there are two inbuilt random number will be generated, below are the details on the same. the usage is being shown in the next section

```
gen.rnd_1=true
rnd_1.min.value=10000
rnd_1.max.value=1000000
rnd_1.seed=3000

gen.rnd_2=true
rnd_2.min.value=1000
rnd_2.max.value=100000
rnd_2.seed=300
```

##### Defined set of values as input from file

If the user wish to pass a defined set of values as a part of payload then put up your values in SQS/vars.csv with the headers. This headers can then be used to access the values inside the csv file in the payload. Also you need to set the below property in SQS/sqs.properties as true if in case you need to use the values from file

```
use_csv=true
```

##### Payload

For pushing the payload data to SQS, the  Users can add the payload details in the payload.txt. For the fields that need a Random value to be generated, use this expression ${rnd_1} or ${rnd_2} (currently, we are supporting two random values, if a need arises, we can increase it). If data has to be obtained from csv file then use ${header_name). For example.. in SQS/vars.csv we have a header --> envId with values 2,3,5,8. If you want to access the same in the payload use ${envId}.

Note: the eg has JSON payload, but one can use any format.

```
{
   "subaction":"Remove permissions",
   "properties":{
      "role_id" : "${rnd_1}",
      "context_params":{
         "org":"${__UUID()}",
         "envId":"${envId}"
      },
      "name":"Cloudhub Network Administrator ${rnd_2}"
   }
}
```

#### Reports

The reports will be generated under the reports/HTTP or reports/SQS folder. opening the index.html in a browser will open up the generated reports.
