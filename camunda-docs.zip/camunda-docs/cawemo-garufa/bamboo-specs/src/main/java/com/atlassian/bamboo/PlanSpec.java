package com.atlassian.bamboo;

import static com.atlassian.bamboo.BambooSpecVariables.bambooPlanKey;
import static com.atlassian.bamboo.BambooSpecVariables.bambooProjectKey;
import static com.atlassian.bamboo.BambooSpecVariables.bambooProjectName;
import static com.atlassian.bamboo.BambooSpecVariables.bambooRepositoryName;
import static com.atlassian.bamboo.BambooSpecVariables.enableReleaseNotes;
import static com.atlassian.bamboo.BambooSpecVariables.envList;
import static com.atlassian.bamboo.BambooSpecVariables.groupNameForPermission;
import static com.atlassian.bamboo.BambooSpecVariables.planOwner;
import static com.atlassian.bamboo.BambooSpecVariables.serviceReadableName;
import static com.atlassian.bamboo.BambooSpecVariables.slackChannelName;
import static com.atlassian.bamboo.SourceClear.runSourceClear;
import static com.atlassian.bamboo.Utilities.checkoutRepo;
import static com.atlassian.bamboo.Utilities.determineImage;
import static com.atlassian.bamboo.Utilities.isDeploymentBamboo;
import static com.atlassian.bamboo.Utilities.storeAppName;
import static com.atlassian.bamboo.Utilities.storeAppPackaging;
import static com.atlassian.bamboo.Utilities.storeAppVersion;

import java.util.Map;

import com.atlassian.bamboo.specs.api.BambooSpec;
import com.atlassian.bamboo.specs.api.builders.AtlassianModule;
import com.atlassian.bamboo.specs.api.builders.BambooKey;
import com.atlassian.bamboo.specs.api.builders.notification.AnyNotificationRecipient;
import com.atlassian.bamboo.specs.api.builders.notification.Notification;
import com.atlassian.bamboo.specs.api.builders.owner.PlanOwner;
import com.atlassian.bamboo.specs.api.builders.pbc.PerBuildContainerForJob;
import com.atlassian.bamboo.specs.api.builders.permission.PermissionType;
import com.atlassian.bamboo.specs.api.builders.permission.Permissions;
import com.atlassian.bamboo.specs.api.builders.permission.PlanPermissions;
import com.atlassian.bamboo.specs.api.builders.pbc.ContainerSize;
import com.atlassian.bamboo.specs.api.builders.pbc.ExtraContainer;
import com.atlassian.bamboo.specs.api.builders.pbc.ExtraContainerSize;
import com.atlassian.bamboo.specs.api.builders.pbc.PerBuildContainerForJob;
import com.atlassian.bamboo.specs.api.builders.plan.Job;
import com.atlassian.bamboo.specs.api.builders.plan.Plan;
import com.atlassian.bamboo.specs.api.builders.plan.PlanIdentifier;
import com.atlassian.bamboo.specs.api.builders.plan.Stage;
import com.atlassian.bamboo.specs.api.builders.plan.artifact.Artifact;
import com.atlassian.bamboo.specs.api.builders.plan.artifact.ArtifactSubscription;
import com.atlassian.bamboo.specs.api.builders.plan.branches.BranchCleanup;
import com.atlassian.bamboo.specs.api.builders.plan.branches.PlanBranchManagement;
import com.atlassian.bamboo.specs.api.builders.plan.dependencies.Dependencies;
import com.atlassian.bamboo.specs.api.builders.plan.dependencies.DependenciesConfiguration;
import com.atlassian.bamboo.specs.api.builders.project.Project;
import com.atlassian.bamboo.specs.api.builders.task.Task;
import com.atlassian.bamboo.specs.builders.notification.CommittersRecipient;
import com.atlassian.bamboo.specs.builders.notification.PlanCompletedNotification;
import com.atlassian.bamboo.specs.builders.notification.PlanFailedNotification;
import com.atlassian.bamboo.specs.builders.task.ArtifactDownloaderTask;
import com.atlassian.bamboo.specs.builders.task.DownloadItem;
import com.atlassian.bamboo.specs.builders.task.MavenTask;
import com.atlassian.bamboo.specs.builders.task.TestParserTask;
import com.atlassian.bamboo.specs.builders.trigger.BitbucketServerTrigger;
import com.atlassian.bamboo.specs.model.task.TestParserTaskProperties;
import com.atlassian.bamboo.specs.util.BambooServer;
import com.atlassian.bamboo.specs.builders.task.ScriptTask;
import com.atlassian.bamboo.specs.model.task.InjectVariablesScope;
import com.atlassian.bamboo.specs.model.task.ScriptTaskProperties;

@BambooSpec
@SuppressWarnings("rawtypes")
public class PlanSpec {

	private static boolean isDeploymentBamboo = isDeploymentBamboo();
	static final String BUILD_OUTPUT_FOLDER = "target/classes";
    static final String VARIABLES_PROPERTIES_FILE = "target/release-version.properties";

	public Plan plan() {

		final Plan plan = new Plan(new Project().key(new BambooKey(bambooProjectKey)).name(bambooProjectName),
				serviceReadableName + " Build and Test", new BambooKey(bambooPlanKey))
						.description(serviceReadableName + " - Build and Test")
						.pluginConfigurations(
								new PerBuildContainerForJob().enabled(true).image(determineImage()).size("REGULAR"),
								new PlanOwner(planOwner))
						.linkedRepositories(bambooRepositoryName).triggers(new BitbucketServerTrigger())
						.dependencies(new Dependencies()
								.configuration(new DependenciesConfiguration().enabledForBranches(false)))
						.notifications(
								new Notification().type(new PlanCompletedNotification())
										.recipients(new AnyNotificationRecipient(new AtlassianModule(
												"com.atlassian.bamboo.plugins.bamboo-slack:recipient.slack"))
														.recipientString(
																"${bamboo.atlassian.slack.webhook.url.password}|"
																		+ slackChannelName + "||")),
								new Notification().type(new PlanFailedNotification())
										.recipients(new CommittersRecipient()))
						.forceStopHungBuilds().labels("plan-templates");
		if (!isDeploymentBamboo) {
			plan.planBranchManagement(
					new PlanBranchManagement()
							.createForVcsBranchMatching(".*").delete(new BranchCleanup()
									.whenRemovedFromRepositoryAfterDays(1).whenInactiveInRepositoryAfterDays(10))
							.notificationLikeParentPlan());
		}

		// CONFIGURE STAGES
		plan.stages(buildTask()); 		// 1. BUILD
		plan.stages(stagePushDockerImage());   // docker push
		//plan.stages(unitTask()); 		// 2. UNIT TEST CASES
		plan.stages(releaseStage()); 	// 3. MAVEN ARTIFACTORY DEPLOY/RELEASE AND RELEASE NOTES
		
		
		return plan;
	}

	// Build Task
	public static Stage buildTask() {

		Stage buildStage = new Stage("Build Stage").description("Build " + serviceReadableName);
		Job buildJob = new Job("Build Job", new BambooKey("BUILD"))
				.description("Build " + serviceReadableName + " project")
				.pluginConfigurations(
						new PerBuildContainerForJob().enabled(true).image(determineImage()).size("REGULAR"))
				.artifacts(new Artifact().name("Project-dir").copyPattern("**/**").shared(true),
						new Artifact().name("Logs").copyPattern("**/*.log"))
				.tasks(checkoutRepo(), storeAppName(), storeAppVersion(), runSourceClear(), storeAppPackaging(),
						Utilities.updateSettingsXml());
		buildJob.tasks(buildAndRelease());
		return buildStage.jobs(buildJob);
	}

	// Method to build the project and create release version
	private static Task buildAndRelease() {
		return new MavenTask().description("Build Project and Release Version").goal(buildAndPrepareReleaseGoal())
				.jdk("JDK 8").executableLabel("mvnvm");
	}

	// Method to determine build and check for prepare release goal
	private static String buildAndPrepareReleaseGoal() {

		if (Utilities.isDeploymentBamboo()) {
			return " -e -B clean -DskipTests -Darguments=-DskipTests release:prepare package";
		} else {
			return " -e -B clean -DskipTests -DdryRun=true -Darguments=-DskipTests release:prepare package";
		}

	}

	// Method to execute units for all environments
	public static Stage unitTask() {

		Stage unitTestStage = new Stage("Unit Test Stage").description("Test " + serviceReadableName);
		for (String env : envList.keySet()) {
			unitTestStage.jobs(unitTest(env, envList.get(env)));
		}

		return unitTestStage;

	}

	// Method to run unit tests for each env
	private static Job unitTest(String env, Map<String, String> envProperties) {
		return new Job(env + " Unit Tests Job", new BambooKey(env.toUpperCase() + "UNITTESTS"))
				.description("Run " + env + " " + serviceReadableName + " Unit tests")
				.pluginConfigurations(
						new PerBuildContainerForJob().enabled(true).image(determineImage()).size("REGULAR"))
				.artifacts(new Artifact().name("Logs").copyPattern("**/*.unit.log"))
				.tasks(new ArtifactDownloaderTask().artifacts(new DownloadItem().artifact("Project-dir").path(".")),
						runUnitTest(env, envProperties))
				.finalTasks(junitTask(env)).artifactSubscriptions(new ArtifactSubscription().artifact("Project-dir"));

	}

	//// Method to run unit tests
	private static Task runUnitTest(String env, Map<String, String> envProperties) {
		return new MavenTask().description("Run Unit tests in " + env + " environment")
				.goal(runUnitTestGoal(env, envProperties)).jdk("JDK 8").executableLabel("mvnvm").hasTests(true);
	}

	// Method to run unit tests
	private static String runUnitTestGoal(String env, Map<String, String> envProperties) {

		return "-f pom.xml -s ./settings.xml -B clean test -Denv=" + env + " -Dkey=${bamboo." + env 
				+ "}";
	}

	// Method to run junit tasks
	private static Task junitTask(String env) {

		return new TestParserTask(TestParserTaskProperties.TestType.JUNIT).description("Parse JUnit Results")
				.resultDirectories("**/*-" + env + "-unit-reports/*.xml");

	}

	// Method to create release stage
	public static Stage releaseStage() {
		
		Stage releaseStage = new Stage("Release Stage").description("Release the version to artifactory")
				.jobs(releaseJob());
		return releaseStage;
	}

	// method to create a release job
	private static Job releaseJob() {
		
		Job releaseJob = new Job("Release Job", new BambooKey("RELEASE"))
				.description("Release " + serviceReadableName + " project")
				.pluginConfigurations(
						new PerBuildContainerForJob().enabled(true).image(determineImage()).size("REGULAR"))
				.artifacts(new Artifact().name("Logs").copyPattern("**/*.log"))
				.artifactSubscriptions(new ArtifactSubscription().artifact("Project-dir"));
		releaseJob.tasks(new ArtifactDownloaderTask().artifacts(new DownloadItem().artifact("Project-dir").path(".")),
				releaseMavenTask());
		if (Utilities.isDeploymentBamboo()) {
			if (enableReleaseNotes) { // RELEASE NOTES
				releaseJob.tasks(ReleaseNotes.updateReleaseNotes());
			}
		}

		return releaseJob;

	}

	// Method to release artifact version to artifactory
	private static Task releaseMavenTask()
    {
        if(isDeploymentBamboo)
        {
            return new MavenTask()
                                .description("Release version to artifactory")
                                .goal("-f pom.xml -DskipTests -Darguments=-DskipTests release:perform")
                                .jdk("JDK 8")
                                .executableLabel("mvnvm");
        }
        else
        {
            return new MavenTask()
                                .description("Release version to artifactory")
                                .goal("-f pom.xml -DskipTests -Darguments=-DskipTests deploy")
                                .jdk("JDK 8")
                                .executableLabel("mvnvm");
        }

    }

	// Set plan permissions
	public PlanPermissions planPermission() {
		final PlanPermissions planPermission = new PlanPermissions(new PlanIdentifier(bambooProjectKey, bambooPlanKey))
				.permissions(new Permissions()
						.groupPermissions(groupNameForPermission, PermissionType.BUILD, PermissionType.VIEW)
						.loggedInUserPermissions(PermissionType.VIEW, PermissionType.BUILD));
		return planPermission;
	}
	
	//
	private static final PerBuildContainerForJob PER_BUILD_CONTAINER = new PerBuildContainerForJob()
            .image("docker.atl-paas.net/sox/buildeng/agent-baseagent")
            .size(ContainerSize.REGULAR)
            // This microservice relies on building a docker image so we need docker to be available.
            .extraContainers(new ExtraContainer()
                    .name("docker")
                    .image("docker:18.04-dind")
                    .size(ExtraContainerSize.SMALL)
            );
	
	// Method to create docker publish stage
	public static Stage stagePushDockerImage() {
		
		return new Stage("Docker Image Pulblish")
                .jobs(new Job("Docker Image Publish Job", "JOB4")
                        .pluginConfigurations(PER_BUILD_CONTAINER)
                        .artifacts(new Artifact()
                                .name("Service descriptor")
                                .location(BUILD_OUTPUT_FOLDER)
                                .copyPattern("*.sd.yml")
                                .shared(true)
                        )
                        .tasks(checkoutRepo(), storeAppName(), storeAppVersion(), runSourceClear(), pushDockerImage())
                        .finalTasks( stopInBamboo())
//                        .finalTasks(junitParser(), stopInBamboo()) TODO revert this back.
                );
	}
		
	private static ScriptTask pushDockerImage() {
        return new ScriptTask()
                .description("Package and push Docker image")
                .interpreter(ScriptTaskProperties.Interpreter.BINSH_OR_CMDEXE)
                .inlineBody("\n./bin/build-in-bamboo.sh\n");
    }
	
	/**
     * Used to clean up after the tests in bamboo have run.
     */
    private static Task stopInBamboo() {
        return new ScriptTask()
                .description("Cleanup bamboo environment: ./bin/stop-in-bamboo.sh")
                .inlineBody("./bin/stop-in-bamboo.sh");
    }
	

	public static void main(String... argv) {
		// By default credentials are read from the '.credentials' file.

		final PlanSpec planSpec = new PlanSpec();
		final BambooServer bambooServer = new BambooServer(Utilities.bambooServerUrl());

		final Plan plan = planSpec.plan();
		bambooServer.publish(plan);

		final PlanPermissions planPermission = planSpec.planPermission();
		bambooServer.publish(planPermission);
	}
}