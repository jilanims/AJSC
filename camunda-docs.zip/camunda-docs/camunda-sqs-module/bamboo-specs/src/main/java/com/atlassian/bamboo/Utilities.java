package com.atlassian.bamboo;

import static com.atlassian.bamboo.BambooSpecVariables.bambooRepositoryName;
import static com.atlassian.bamboo.BambooSpecVariables.deploymentBambooImage;
import static com.atlassian.bamboo.BambooSpecVariables.itBambooImage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.atlassian.bamboo.specs.api.builders.AtlassianModule;
import com.atlassian.bamboo.specs.api.builders.repository.VcsRepositoryIdentifier;
import com.atlassian.bamboo.specs.api.builders.task.AnyTask;
import com.atlassian.bamboo.specs.api.builders.task.Task;
import com.atlassian.bamboo.specs.builders.task.CheckoutItem;
import com.atlassian.bamboo.specs.builders.task.InjectVariablesTask;
import com.atlassian.bamboo.specs.builders.task.ScriptTask;
import com.atlassian.bamboo.specs.builders.task.VcsCheckoutTask;
import com.atlassian.bamboo.specs.model.task.InjectVariablesScope;
import com.atlassian.bamboo.specs.util.MapBuilder;
import com.atlassian.bamboo.specs.api.context.RssRuntimeContext;

@SuppressWarnings({"rawtypes","unchecked"})
public final class Utilities {
	private static Logger LOGGER = LoggerFactory.getLogger(Utilities.class);
    
    //Check for deploymnet bamboo
    public static boolean isDeploymentBamboo() {
    	
    	// Do not use the system property, use the helper method instead.
        final String instanceName = RssRuntimeContext.getServerName().get();

        // We include sandbox bamboo for testing but note that deployment does not work in this environment for
        // some reason
        boolean isDeployBamboo = "deployment-bamboo".equals(instanceName);
        LOGGER.info("CHECK FOR DEPLOYMENT BAMBOO FLAG :"+isDeployBamboo);
        return isDeployBamboo;
    }

    //Method to determine bamboo image
    public static String determineImage()
    {
        if(isDeploymentBamboo())
        {
            return deploymentBambooImage; 
        }
        else
        {
            return itBambooImage;
                                             
        }
    }

    //This method injects variables as bamboo variables
    public static Task bambooInjectVariables(String description,String path,String namespace)
    {
    	LOGGER.info("INVOKE BAMBOO INJECT VARIABLES METHOD");
        return new InjectVariablesTask()
                            .description(description)
                            .path(path)
                            .namespace(namespace)
                            .scope(InjectVariablesScope.LOCAL);
    }

    //Check out repository
    public static Task checkoutRepo() {
    	LOGGER.info("INVOKE BAMBOO CHECKOUT REPO METHOD");
        return new VcsCheckoutTask()
                                    .description("Check out Default Repository")
                                    .checkoutItems(new CheckoutItem()
                                            .repository(new VcsRepositoryIdentifier()
                                                    .name(bambooRepositoryName)));

    }

    //Method to store application name
	public static Task storeAppName(){
		LOGGER.info("CONFIGURE STORE APPLICATION NAME");
        return new AnyTask(new AtlassianModule("com.davidehringer.atlassian.bamboo.maven.maven-pom-parser-plugin:maven-pom-parser-plugin"))
                                    .description("Store app name from pom")
                                    .configuration(new MapBuilder()
                                            .put("gavOrCustom", "1")
                                            .put("variableType", "2")
                                            .put("prefixOption", "1")
                                            .put("userDescription", "Store app name from pom")
                                            .put("customVariableName", "appname")
                                            .put("type", "custom")
                                            .put("customElement", "artifactId")
                                            .build());
    }

    //Method to store app version
    public static Task storeAppVersion() {
    	LOGGER.info("CONFIGURE STORE APPLICATION VERSION");
        if(isDeploymentBamboo())
        {
            return new AnyTask(new AtlassianModule("com.atlassian.bamboo.plugins.variable.updater.variable-updater-generic:variable-extractor"))
                                        .description("Store app version from pom")
                                        .configuration(new MapBuilder()
                                                .put("variable", "pom.version")
                                                .put("userDescription", "Store app version from pom")
                                                .put("type", "custom")
                                                .put("variableScope", "RESULT")
                                                .put("removeSnapshot","true")
                                                .build());
        }
        else
        {
            return new AnyTask(new AtlassianModule("com.atlassian.bamboo.plugins.variable.updater.variable-updater-generic:variable-extractor"))
                                        .description("Store app version from pom")
                                        .configuration(new MapBuilder()
                                                .put("variable", "pom.version")
                                                .put("userDescription", "Store app version from pom")
                                                .put("type", "custom")
                                                .put("variableScope", "RESULT")
                                                .build());
        }
    }

    //Method ro store app packaging info from pom
    public static Task storeAppPackaging() {
    	LOGGER.info("CONFIGURE STORE APPLICATION PACKAGING");
        return new AnyTask(new AtlassianModule("com.davidehringer.atlassian.bamboo.maven.maven-pom-parser-plugin:maven-pom-parser-plugin"))
                                    .description("Store app packaging from pom")
                                    .configuration(new MapBuilder()
                                            .put("gavOrCustom", "1")
                                            .put("variableType", "2")
                                            .put("prefixOption", "1")
                                            .put("userDescription", "Store app packaging from pom")
                                            .put("customVariableName", "mule.packaging")
                                            .put("type", "custom")
                                            .put("customElement", "packaging")
                                            .build());
    }
    
  //Method to create unencrypted settings
    public static Task updateSettingsXml() {
        return new ScriptTask()
                                    .description("generate unencrypted settings")
                                    .inlineBody("    set -e\n    set -x\n    echo \"Creating unencrypted settings.xml\"\n    sed -e s#\\<username\\>.*\\</username\\>#\\<username\\>${bamboo.packages.user.username}\\</username\\>#g -e s#\\<password\\>.*\\</password\\>#\\<password\\>${bamboo.packages.user.api.key.password}\\</password\\>#g ~/.m2/settings.xml > ./settings.xml\n    ");

    }

}