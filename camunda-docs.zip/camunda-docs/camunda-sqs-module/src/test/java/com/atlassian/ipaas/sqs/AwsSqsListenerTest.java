
package com.atlassian.ipaas.sqs;

import java.util.HashMap;
import java.util.Map;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.test.Deployment;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.amazonaws.services.sqs.AmazonSQSAsync;
import com.atlassian.ipaas.sqs.config.AwsSqsConfig;
import com.atlassian.ipaas.sqs.config.ProcessEngineConfigurationTest;
import com.atlassian.ipaas.sqs.config.WorkflowMapping;
import com.atlassian.ipaas.sqs.constants.AwsSqsConstants;
import com.atlassian.ipaas.workflow.TriggerWorkflow;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(JUnitPlatform.class)
@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = { ProcessEngineConfigurationTest.class, AwsSqsConfig.class, AwsSqsSender.class })
@ActiveProfiles("test")
@ContextConfiguration
public class AwsSqsListenerTest {

	private static final Logger LOG = LoggerFactory.getLogger(AwsSqsListenerTest.class);
	
	@MockBean
	AmazonSQSAsync amazonSqs;

	@InjectMocks
	AwsSqsListener awsSqsListener;
	
	@Value("${aws.sqs.defaultDeletionPolicy:true}")
	private boolean awsSqsMsgDefaultDeletion;
	
	@Value("${aws.sqs.message.type:type}")
	String TYPE;
	
	@Value("${aws.sqs.message.id:id}")
	String ID;
	
	@Spy
	TriggerWorkflow camunda;
	
	@Autowired
	private RuntimeService runtimeService;
	
	private Map<String, String> header;
	

	//private static final String HELLOW_WORLD_CONS = "Hello World!";

	@BeforeEach
	public void init() throws JsonProcessingException {
		LOG.info("BeforeAll method init loading...");
		ObjectMapper objectMapper = new ObjectMapper();
		//camunda.setObjectMapper(objectMapper);
		camunda.setRuntimeService(runtimeService);
		camunda.setTYPE("type");
		camunda.setID("id");
		WorkflowMapping workflowMapping = new WorkflowMapping();
		HashMap<String, String> mapping = new HashMap<String, String>();
		mapping.put("START_EVENT", "startEventId:startEvent");
		mapping.put("MESSAGE_EVENT", "MessageEvent:messageEvent");
		workflowMapping.setMapping(mapping);
		camunda.setWorkflowMapping(workflowMapping);
		
		header = new HashMap<String, String>();
		header.put( AwsSqsConstants.AWS_SQS_MESSAGE_ID, AwsSqsConstants.AWS_SQS_MESSAGE_ID);
		header.put( AwsSqsConstants.AWS_SQS_RECEIPT_HANDLE, AwsSqsConstants.AWS_SQS_RECEIPT_HANDLE);
	}

	@Test
	@Deployment(resources = { "bpmn/StartEvent.bpmn"})
	public void receivedStartMessage() throws Exception {
		
		awsSqsListener.setCamunda(camunda);
		
		LOG.info("Send Message to AWS SQS");
		String message = "{\"type\":\"START_EVENT\",\"workflowName\":\"startEventId\",\"id\":\"88598da0-8090-4951-9f47-d1ac0edca9d0\",\"time\":1586224144437,\"payload\":\"Hello World!\",\"datacontenttype\":\"application/json\",\"specversion\":\"1.0\",\"traceid\":\"6b41b7e0-ceca-436a-a889-f1922e5ecc2e\",\"correlationid\":null}";
		awsSqsListener.receivedMessage(message, null, header);
		//assertNotNull

	}
	
	@Test
	@Deployment(resources = { "bpmn/MessageEvent.dmn" })
	public void receivedEventMessage() throws Exception {

		awsSqsListener.setCamunda(camunda);
		
		LOG.info("Send Message to AWS SQS");
		String message = "{" + 
				"   \"id\":\"88598da0-8090-4951\"," + 
				"   \"type\":\"MESSAGE_EVENT\"," + 
				"   \"subaction\":\"Remove permissions\"," + 
				"   \"properties\":{" + 
				"      \"role_id\" : \"123344\"," + 
				"      \"context_params\":{" + 
				"         \"org\":\"enterprise architecture\"," + 
				"         \"envId\":\"ddev\"" + 
				"      }," + 
				"      \"name\":\"Cloudhub Network Administrator ddev\"," + 
				"       \"eventTimestamp\": \"2020-04-23T06:49:23.326Z\"" + 
				"   }" + 
				"}";
		awsSqsListener.receivedMessage(message, null, header);
		//assertNotNull

	}
	
	@AfterAll
	public static void cleanUp() {
		System.out.println("After All cleanUp() method called");
	}

	@AfterEach
	public void cleanUpEach() {
		System.out.println("After Each cleanUpEach() method called");
	}
}
