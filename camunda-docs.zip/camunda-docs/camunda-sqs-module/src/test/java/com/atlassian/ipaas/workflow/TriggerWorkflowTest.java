package com.atlassian.ipaas.workflow;

import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.test.Deployment;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.atlassian.ipaas.sqs.config.ProcessEngineConfigurationTest;
import com.atlassian.ipaas.sqs.config.WorkflowMapping;
import com.atlassian.ipaas.sqs.constants.AwsSqsConstants;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(JUnitPlatform.class)
@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = { ProcessEngineConfigurationTest.class })
@ActiveProfiles("test")
@ContextConfiguration
public class TriggerWorkflowTest {

	private static final Logger LOG = LoggerFactory.getLogger(TriggerWorkflowTest.class);
	
	@Spy
	TriggerWorkflow camunda;
	
	@Autowired
	private RuntimeService runtimeService;
	
	@Value("${aws.sqs.message.type:type}")
	String TYPE;
	
	@Value("${aws.sqs.message.id:id}")
	String ID;
	
	//@Autowired
	//WorkflowMapping workflowMapping;
	
	
	@BeforeEach
	public void init() throws JsonProcessingException {
		LOG.info("BeforeAll method init loading...");
		ObjectMapper objectMapper = new ObjectMapper();
		camunda.setObjectMapper(objectMapper);
		camunda.setRuntimeService(runtimeService);
		camunda.setID("id");
		camunda.setTYPE("type");
		WorkflowMapping workflowMapping = new WorkflowMapping();
		HashMap<String, String> mapping = new HashMap<String, String>();
		mapping.put("START_EVENT", "startEventId:startEvent");
		mapping.put("MESSAGE_EVENT", "MessageEvent:messageEvent");
		workflowMapping.setMapping(mapping);
		camunda.setWorkflowMapping(workflowMapping);
		
	}
	
	
	@Test
	@Deployment(resources = { "bpmn/StartEvent.bpmn"})
	public void triggerStartEventTest() throws Exception {
		
		String wfStartEventType = AwsSqsConstants.START_EVENT;
		String workflowName = "StartEvent";
		String uniqueBusinessKey = UUID.randomUUID().toString();
		Map<String, String> headers= new HashMap<String, String>();
		headers.put(AwsSqsConstants.TYPE, "START_EVENT"); //lookup in application.yml
		headers.put(AwsSqsConstants.WORKFLOW_NAME, workflowName);
		headers.put(AwsSqsConstants.WORKFLOW_BUSINESS_KEY, uniqueBusinessKey);
		
		String payload= "Hello World!";
		String message = "{\"type\":\"START_EVENT\",\"workflowName\":\"startEventId\",\"id\":\"88598da0-8090-4951-9f47-d1ac0edca9d0\",\"time\":1586224144437,\"payload\":\""+payload+"\",\"datacontenttype\":\"application/json\",\"specversion\":\"1.0\",\"traceid\":\"6b41b7e0-ceca-436a-a889-f1922e5ecc2e\",\"correlationid\":null}";
		LOG.info("PAYLOAD CHARACTERS SIZE: {}", payload.length());
		assertNotNull(camunda.triggerWorkflow(message, null, headers));

	}
	
	@Test
	@Deployment(resources = { "bpmn/MessageEvent.dmn" })
	public void triggerEventMessageTest() throws Exception {
		String type = AwsSqsConstants.MESSAGE_EVENT;
		String workflowName = "MessageEvent";
		String uniqueBusinessKey = UUID.randomUUID().toString();
		Map<String, String> headers= new HashMap<String, String>();
		headers.put(AwsSqsConstants.TYPE, "MESSAGE_EVENT"); //lookup in application.yml for workflowname
		headers.put(AwsSqsConstants.WORKFLOW_NAME, workflowName);
		headers.put(AwsSqsConstants.WORKFLOW_BUSINESS_KEY, uniqueBusinessKey);
		
		String payload= "Hello World!";
		String message = "{\"type\":\"MESSAGE_EVENT\",\"workflowName\":\"MessageEvent\",\"id\":\"cecdd647-4531-4b20-a974-683533452d67\",\"time\":\"2020-04-03T19:05:26.649+0000\",\"payload\":\""+payload+"\",\"datacontenttype\":\"application/json\",\"specversion\":\"1.0\",\"traceid\":\"352a35d2-0441-472e-a4b3-471c20a87052\",\"correlationid\":null}";
		LOG.info("PAYLOAD CHARACTERS SIZE: {}", payload.length());
		assertNotNull(camunda.triggerWorkflow(message, null, headers));

	}
	
	//more than 4000 characters
		@Test
		@Deployment(resources = { "bpmn/StartEvent.bpmn"})
		public void triggerStartEventMorethan4000CharsTest() throws Exception {
			
			String wfStartEventType = AwsSqsConstants.START_EVENT;
			String workflowName = "StartEvent";
			String uniqueBusinessKey = UUID.randomUUID().toString();
			Map<String, String> headers= new HashMap<String, String>();
			headers.put(AwsSqsConstants.TYPE, "START_EVENT"); //lookup in application.yml 
			//headers.put(AwsSqsConstants.WORKFLOW_NAME, workflowName);
			headers.put(AwsSqsConstants.WORKFLOW_BUSINESS_KEY, uniqueBusinessKey);
			
			
			String payload = "Hello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello World!";
			String message = "{\"type\":\"START_EVENT\",\"workflowName\":\"startEventId\",\"id\":\"88598da0-8090-4951-9f47-d1ac0edca9d0\",\"time\":1586224144437,\"payload\":\""+payload+ "\",\"datacontenttype\":\"application/json\",\"specversion\":\"1.0\",\"traceid\":\"6b41b7e0-ceca-436a-a889-f1922e5ecc2e\",\"correlationid\":null}";
			LOG.info("PAYLOAD CHARACTERS SIZE: {}", payload.length());
			assertNotNull(camunda.triggerWorkflow(message, null, headers));

		}
		
		
		@Test
		@Deployment(resources = { "bpmn/StartEvent.bpmn"})
		public void triggerStartEventMorethan4000CharsTestFailure() throws Exception {
			
			String wfStartEventType = AwsSqsConstants.START_EVENT;
			String workflowName = "StartEvent";
			String uniqueBusinessKey = UUID.randomUUID().toString();
			Map<String, String> headers= new HashMap<String, String>();
			headers.put(AwsSqsConstants.TYPE, "START_EVENT"); //lookup in application.yml 
			//headers.put(AwsSqsConstants.WORKFLOW_NAME, workflowName);
			headers.put(AwsSqsConstants.WORKFLOW_BUSINESS_KEY, uniqueBusinessKey);
			
			
			String payload = "Hello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHelloHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello WorldHello World!";
			String message = "{\"type\":\"START_EVENT\",\"workflowName\":\"startEventId\",\"id\":\"88598da0-8090-4951-9f47-d1ac0edca9d0\",\"time\":1586224144437,\"payload\":\""+payload+ "\",\"datacontenttype\":\"application/json\",\"specversion\":\"1.0\",\"traceid\":\"6b41b7e0-ceca-436a-a889-f1922e5ecc2e\",\"correlationid\":null}";
			LOG.info("PAYLOAD CHARACTERS SIZE: {}", payload.length());
			assertNotNull(camunda.triggerWorkflow(message, null, headers));

		}

		@Test
		@Deployment(resources = { "bpmn/StartEvent.bpmn"})
		public void triggerStartEventPayloadIdTest() throws Exception {
			
			String wfStartEventType = AwsSqsConstants.START_EVENT;
			String workflowName = "StartEvent";
			String uniqueBusinessKey = UUID.randomUUID().toString();
			Map<String, String> headers= new HashMap<String, String>();
			headers.put(AwsSqsConstants.TYPE, "START_EVENT"); //lookup in application.yml
			headers.put(AwsSqsConstants.WORKFLOW_NAME, workflowName);
			headers.put(AwsSqsConstants.WORKFLOW_BUSINESS_KEY, uniqueBusinessKey);
			
			camunda.setID("payload.id");
			
			String payload= "Hello World!";
			String message = "{\"type\":\"START_EVENT\",\"workflowName\":\"startEventId\",\"payload\": {" + 
					"\"id\": \"09f325c8-aa50-4434-a3d2-01959d4dada0\"},\"time\":1586224144437,\"data\":\""+payload+"\",\"datacontenttype\":\"application/json\",\"specversion\":\"1.0\",\"traceid\":\"6b41b7e0-ceca-436a-a889-f1922e5ecc2e\",\"correlationid\":null}";
			LOG.info("PAYLOAD CHARACTERS SIZE: {}", payload.length());
			assertNotNull(camunda.triggerWorkflow(message, null, headers));

		}


	
	
}
