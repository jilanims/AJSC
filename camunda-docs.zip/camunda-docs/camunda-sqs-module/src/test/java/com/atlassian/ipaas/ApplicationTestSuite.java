package com.atlassian.ipaas;

import org.junit.platform.runner.JUnitPlatform;
import org.junit.platform.suite.api.SelectPackages;
import org.junit.runner.RunWith;

@RunWith(JUnitPlatform.class)
@SelectPackages({"com.atlassian.ipaas.sqs", "com.atlassian.ipaas.workflow"})
//@SuiteClasses({ TestFeatureOne.class, TestFeatureTwo.class })
class ApplicationTestSuite {

}
