package com.atlassian.ipaas.sqs;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.junit.Before;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.aws.messaging.core.QueueMessagingTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

import com.amazonaws.services.sqs.AmazonSQSAsync;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.MessageAttributeValue;
import com.atlassian.ipaas.sqs.config.AwsSqsConfig;
import com.atlassian.ipaas.sqs.constants.AwsSqsConstants;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(JUnitPlatform.class)
@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = { AwsSqsConfig.class, AwsSqsSender.class })
@ActiveProfiles("test")
@ContextConfiguration
public class AwsSqsSenderTest {

	private static final Logger LOG = LoggerFactory.getLogger(AwsSqsSenderTest.class);

	@Mock
	ObjectMapper objectMapper;
	
	@MockBean
	AmazonSQSAsync amazonSqs;

	@Mock
	QueueMessagingTemplate queueMessagingTemplate;

	@InjectMocks
	AwsSqsSender awsSqsSender;

	private static final String HELLOW_WORLD_CONS = "Hello World!";

	@Before
	public void init() throws JsonProcessingException {
		LOG.info("BeforeAll method init loading...");
	}

	@Test
	public void sendMessageToAwsSQS() throws JsonProcessingException {
		LOG.info("Send Message to AWS SQS");

		//Message msg = new Message(AwsSqsConstants.MESSAGE_EVENT, "MessageEvent", HELLOW_WORLD_CONS);
		
		String type = AwsSqsConstants.MESSAGE_EVENT;
		String workflowName = "MessageEvent";
		String uniqueBusinessKey = UUID.randomUUID().toString();
		Map<String, String> headers= new HashMap<String, String>();
		headers.put(AwsSqsConstants.TYPE, "MESSAGE_EVENT");
		headers.put(AwsSqsConstants.WORKFLOW_NAME, workflowName);
		headers.put(AwsSqsConstants.WORKFLOW_BUSINESS_KEY, uniqueBusinessKey);
		
		Message message = new Message();
		message.setMessageId(UUID.randomUUID().toString());
		message.setBody(HELLOW_WORLD_CONS);
		message.setAttributes(headers);
		
		Map<String, MessageAttributeValue> messageAttributes = new HashMap<String, MessageAttributeValue>();
		MessageAttributeValue mssageAttributeValue = new MessageAttributeValue();
		mssageAttributeValue.setStringValue("startEvent");
		messageAttributes.put("type", new MessageAttributeValue());
		message.setMessageAttributes(messageAttributes);


		String jsonStr = "{\"type\":\"MESSAGE_EVENT\",\"workflowName\":\"MessageEvent\",\"id\":\"cecdd647-4531-4b20-a974-683533452d67\",\"time\":\"2020-04-03T19:05:26.649+0000\",\"payload\":\"Hello World!\",\"datacontenttype\":\"application/json\",\"specversion\":\"1.0\",\"traceid\":\"352a35d2-0441-472e-a4b3-471c20a87052\",\"correlationid\":null}";
		when(objectMapper.writeValueAsString(message)).thenReturn(jsonStr);

		ReflectionTestUtils.setField(awsSqsSender, "sqsEndPoint",
				"https://sqs.us-east-1.amazonaws.com/644971318052/atl-sqs-replay-demo-dev");
		String response = awsSqsSender.sendMessageToAwsSQS(message);
		LOG.info("Response: {}", response);

		// Assert
		assertEquals("SUCCESS: Message send to AWS SQS", response);

	}
	
	@Test
	public void sendStartMessageToAwsSQS() throws JsonProcessingException {
		LOG.info("Send Message to AWS SQS");

		//Message<String> msg = new Message<String>(AwsSqsConstants.START_EVENT, "StartEvent", HELLOW_WORLD_CONS);
		
		String wfStartEventType = AwsSqsConstants.START_EVENT;
		String workflowName = "StartEvent";
		String uniqueBusinessKey = UUID.randomUUID().toString();
		Map<String, String> headers= new HashMap<String, String>();
		headers.put(AwsSqsConstants.TYPE, "START_EVENT");
		headers.put(AwsSqsConstants.WORKFLOW_NAME, workflowName);
		headers.put(AwsSqsConstants.WORKFLOW_BUSINESS_KEY, uniqueBusinessKey);
		
		Message message = new Message();
		message.setMessageId(UUID.randomUUID().toString());
		message.setBody(HELLOW_WORLD_CONS);
		message.setAttributes(headers);
		
		String jsonStr = "{\"type\":\"START_EVENT\",\"workflowName\":\"startEventId\",\"id\":\"cecdd647-4531-4b20-a974-683533452d67\",\"time\":\"2020-04-03T19:05:26.649+0000\",\"payload\":\"Hello World!\",\"datacontenttype\":\"application/json\",\"specversion\":\"1.0\",\"traceid\":\"352a35d2-0441-472e-a4b3-471c20a87052\",\"correlationid\":null}";
		when(objectMapper.writeValueAsString(message)).thenReturn(jsonStr);

		ReflectionTestUtils.setField(awsSqsSender, "sqsEndPoint",
				"https://sqs.us-east-1.amazonaws.com/644971318052/atl-sqs-replay-demo-dev");
		String response = awsSqsSender.sendMessageToAwsSQS(message);
		LOG.info("Response: {}", response);

		// Assert
		assertEquals("SUCCESS: Message send to AWS SQS", response);

	}
	
	@Test
	public void sendStartMessageToAwsSQSFailure() throws JsonProcessingException {
		LOG.info("Send Message to AWS SQS");
		
		Exception exception = assertThrows(RuntimeException.class, () -> {
			awsSqsSender.sendMessageToAwsSQS(null);
	    });
		
		String expectedMessage = "Could not tranform and send message due to: null";
		String actualMessage = exception.getMessage();
		assertTrue(actualMessage.contains(expectedMessage));

	}

	@AfterAll
	public static void cleanUp() {
		System.out.println("After All cleanUp() method called");
	}

	@AfterEach
	public void cleanUpEach() {
		System.out.println("After Each cleanUpEach() method called");
	}
}
