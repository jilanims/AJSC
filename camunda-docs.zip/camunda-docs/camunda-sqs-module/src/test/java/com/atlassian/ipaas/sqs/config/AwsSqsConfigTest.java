package com.atlassian.ipaas.sqs.config;

import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;

@SpringBootConfiguration
@EnableAutoConfiguration
public class AwsSqsConfigTest  extends AwsSqsConfig{
	
}
