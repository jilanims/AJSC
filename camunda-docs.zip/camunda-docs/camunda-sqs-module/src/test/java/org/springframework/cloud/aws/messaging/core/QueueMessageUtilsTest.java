package org.springframework.cloud.aws.messaging.core;

import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.MessageAttributeValue;
import org.junit.jupiter.api.Test;

public class QueueMessageUtilsTest {
    @Test
    public void testCanParseMessagesWithAttributeOfPrimitiveNumberType() {
        MessageAttributeValue value = new MessageAttributeValue().withDataType("Number.long").withStringValue("0");
        Message message = new Message().addMessageAttributesEntry(null, value).withBody("");

        QueueMessageUtils.createMessage(message);
    }
}
