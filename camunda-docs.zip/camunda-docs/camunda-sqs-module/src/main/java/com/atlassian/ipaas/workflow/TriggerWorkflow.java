/**
* The class trigger the workflow based on the start event type
* And output the workflow transaction Id: processinstanceId.
*/

package com.atlassian.ipaas.workflow;

import static org.camunda.spin.Spin.JSON;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.runtime.MessageCorrelationResult;
import org.camunda.bpm.engine.runtime.ProcessInstance;
import org.camunda.spin.Spin;
import org.camunda.spin.json.SpinJsonNode;
import org.camunda.spin.plugin.variable.SpinValues;
import org.camunda.spin.plugin.variable.value.JsonValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.atlassian.ipaas.model.CustomQueueMessageAcknowledgment;
import com.atlassian.ipaas.sqs.config.WorkflowMapping;
import com.atlassian.ipaas.sqs.constants.AwsSqsConstants;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component(value="camunda")
public class TriggerWorkflow {

	private static final Logger LOG = LoggerFactory.getLogger(TriggerWorkflow.class);
	
	@Autowired
	private ObjectMapper objectMapper;
	
	@Autowired
	private RuntimeService runtimeService;
	
	@Autowired
	WorkflowMapping workflowMapping;
	
	@Value("${aws.sqs.message.type:type}")
	String TYPE;
	
	@Value("${aws.sqs.message.id:id}")
	String ID;

	
	/**
	 * This method, triggers the camunda workflow based on start event type.
	 *
	 * @param  message data send to process variable 'SQS_PAYLOAD'
	 * @param  acknowledgment to acknowledge (deletion) the message from the queue.
	 * @return  unique transactionId: processInstanceId.
	 */
	public String triggerWorkflow(String message, CustomQueueMessageAcknowledgment acknowledgment, Map<String,String> headerMap) throws Exception {
		
		String processInstanceId = null;
		
		//convert the data into spin format
		Map<String, Object> variables = new HashMap<String, Object>();
		
		
		
		JsonValue jsonValue = SpinValues.jsonValue(message).create();
		variables.put(AwsSqsConstants.SQS_PAYLOAD, jsonValue);
		
		if(null!=acknowledgment) {
			variables.put(AwsSqsConstants.AWS_SQS_ACKNOWLEDGEMENT, Spin.JSON(acknowledgment));
		}
		
		//ObjectValue typedCustomerValue =
		//		  Variables.objectValue("Testing data data").serializationDataFormat("application/json").create();
		
		LOG.info("message: {}", message.replaceAll("\n", ""));
		SpinJsonNode json = JSON(message);
		SpinJsonNode typeSpin = json.prop(TYPE);
		String workFlowName = null;
		String eventType = null;
		String businessKey = null;
		String workflow_event = workflowMapping.getMapping().get(typeSpin.stringValue());
		String[] workflowArr = workflow_event.split(":");
		
		if(null!=workflowArr && workflowArr.length>1) {
			workFlowName = workflowArr[0];
			eventType = workflowArr[1];
		}
		
		try {
			businessKey = getJsonProp(json, ID);
		    
	    }catch(Exception e) {
	    	LOG.error("Error Id variable is not available in sqs payload to configure businesskey {}",e);
	    	businessKey=UUID.randomUUID().toString();
	    }
		LOG.info("businessKey of the workflow: {}", businessKey);
		LOG.info("workFlowName of the workflow: {}", workFlowName);
		LOG.info("eventType of the workflow: {}", eventType);
		
		ProcessInstance pi = null;
		if (AwsSqsConstants.START_EVENT.equals(eventType)) {
			pi = runtimeService.startProcessInstanceByKey(workFlowName, businessKey, variables);

		} else if (AwsSqsConstants.MESSAGE_EVENT.equals(eventType)) {
			pi = messageEvent(workFlowName, businessKey, variables);
		}

		if (pi != null) {
			LOG.info("Process Instance Id:{}", pi.getProcessInstanceId());
			LOG.info("Process Definition Id:{}", pi.getProcessDefinitionId());
			processInstanceId = pi.getProcessInstanceId();
		}
		return processInstanceId;

	}
	
	/**
	 * This method, listens to the queues configured in end-point.uri 
	 * then validate to trigger the camunda workflow 
	 *
	 * @param  messageName is message event task name
	 * @param  businessKey is unique business key
	 * @return ProcessInstance of the triggered workflow transaction
	 */
	private ProcessInstance messageEvent(String messageName, String businessKey, Map<String, Object> variables) {
		MessageCorrelationResult messageCorrelationResult = null;
		long correlatingInstances = runtimeService.createExecutionQuery() //
				.messageEventSubscriptionName(messageName) //
				.processInstanceBusinessKey(businessKey) //
				.count();
		LOG.info("Correlating {} to waiting flow instance", businessKey);
		if (correlatingInstances == 1) {
			// invoke the message event for existing process instance
			messageCorrelationResult = runtimeService.createMessageCorrelation(messageName).processInstanceBusinessKey(businessKey)
					.setVariable(AwsSqsConstants.SQS_PAYLOAD, variables.get(AwsSqsConstants.SQS_PAYLOAD))//
					.correlateWithResult();

		} else {
			// and kick off a new workflow process instance
			messageCorrelationResult = runtimeService.createMessageCorrelation(messageName).processInstanceBusinessKey(businessKey)
					.setVariable(AwsSqsConstants.SQS_PAYLOAD, variables.get(AwsSqsConstants.SQS_PAYLOAD)).correlateWithResult();
		}
		return messageCorrelationResult.getProcessInstance();

	}
	
	public String getJsonProp(SpinJsonNode json, String jsonName) {
		String idArray[] = jsonName.split("\\.");
		SpinJsonNode childNode = null;
		if (idArray.length > 0) {

			for (String childVariableName : idArray) {
				if (childNode == null) {
					childNode = json.prop(childVariableName);
				} else {
					childNode = childNode.prop(childVariableName);
				}
			}
		} 
		if (childNode != null)
			return childNode.stringValue();
		else
			return null;
	}

	public void setObjectMapper(ObjectMapper objectMapper) {
		this.objectMapper = objectMapper;
	}

	public void setRuntimeService(RuntimeService runtimeService) {
		this.runtimeService = runtimeService;
	}

	public void setWorkflowMapping(WorkflowMapping workflowMapping) {
		this.workflowMapping = workflowMapping;
	}

	public void setTYPE(String tYPE) {
		TYPE = tYPE;
	}

	public void setID(String iD) {
		ID = iD;
	}
	
	
	
}
