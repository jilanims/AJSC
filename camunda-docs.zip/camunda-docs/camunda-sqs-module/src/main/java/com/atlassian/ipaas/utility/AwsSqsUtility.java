package com.atlassian.ipaas.utility;

import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.amazonaws.services.sqs.AmazonSQSAsync;
import com.amazonaws.services.sqs.model.DeleteMessageResult;

@Component
public class AwsSqsUtility {

	@Autowired
	AmazonSQSAsync amazonSqs;

	
	/**
	 * 
	 * This method always returns DeleteMessageResult, delete the message from AWS SQS Queue
	 *
	 * @param  queueUrl is the queue end-point url
	 * @param  receiptHandle is unique key of the SQS Queue
	 * @return  DeleteMessageResult;
	 */
	public DeleteMessageResult deleteMessage(String queueUrl, String receiptHandle) {
		return amazonSqs.deleteMessage(queueUrl, receiptHandle);
	}

	
	/**
	 * 
	 * This method always returns Future<DeleteMessageResult>, delete the message from AWS SQS Queue Asynchronously
	 *
	 * @param  queueUrl is the queue end-point url
	 * @param  receiptHandle is unique key of the SQS Queue
	 * @return  Future<DeleteMessageResult>;
	 */
	public Future<DeleteMessageResult> deleteMessageAsync(String queueUrl, String receiptHandle) {
		return amazonSqs.deleteMessageAsync(queueUrl, receiptHandle);
	}
}
