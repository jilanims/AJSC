package com.atlassian.ipaas.sqs.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cloud.aws.messaging.config.QueueMessageHandlerFactory;
import org.springframework.cloud.aws.messaging.config.SimpleMessageListenerContainerFactory;
import org.springframework.cloud.aws.messaging.core.QueueMessagingTemplate;
import org.springframework.cloud.aws.messaging.listener.QueueMessageHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.amazonaws.services.sqs.AmazonSQSAsync;
import com.fasterxml.jackson.databind.ObjectMapper;

@Configuration
@ConditionalOnProperty(value="aws.sqs.enable", havingValue="true", matchIfMissing = false)
public class AwsSqsConfig {

	private static final Logger LOG = LoggerFactory.getLogger(AwsSqsConfig.class);

	@Value("${aws.sqs.queue.maxNumberOfMessages}")
	private String maxNumberOfMessages;

	@Value("${aws.sqs.threadPool.corePoolSize}")
	private String corePoolSize;

	@Value("${aws.sqs.threadPool.maxPoolSize}")
	private String maxPoolSize;

	@Value("${aws.sqs.threadPool.threadNamePrefix}")
	private String threadNamePrefix;

	@Value("${aws.sqs.queue.visibilityTimeout}")
	private String visibilityTimeout;

	@Value("${aws.sqs.queue.waitTimeSeconds}")
	private String waitTimeSeconds;

	@Bean("queueMessagingTemplate")
	public QueueMessagingTemplate queueMessagingTemplate(AmazonSQSAsync async) {
		return new QueueMessagingTemplate(async);
	}
	
	@Autowired
	AsyncTaskExecutor taskExecutor;


	@Bean
	@DependsOn({"taskExecutor"})
	public SimpleMessageListenerContainerFactory simpleMessageListenerContainerFactory(AmazonSQSAsync async) {
		//refer here org.springframework.cloud.aws.messaging.config.SimpleMessageListenerContainerFactory
		SimpleMessageListenerContainerFactory factory = new SimpleMessageListenerContainerFactory();
		factory.setAmazonSqs(async);
		factory.setQueueMessageHandler(queueMessageHandler(async));
		factory.setMaxNumberOfMessages(Integer.valueOf(maxNumberOfMessages));
		factory.setTaskExecutor(taskExecutor);
		factory.setWaitTimeOut(Integer.valueOf(waitTimeSeconds));
		factory.setVisibilityTimeout(Integer.valueOf(visibilityTimeout));
		return factory;
	}

	//@Bean
	public QueueMessageHandler queueMessageHandler(AmazonSQSAsync async) {
		QueueMessageHandlerFactory queueMessageHandlerFactory = new QueueMessageHandlerFactory();
		queueMessageHandlerFactory.setAmazonSqs(async);
		QueueMessageHandler queueMessageHandler = queueMessageHandlerFactory.createQueueMessageHandler();
		return queueMessageHandler;
	}

	@Bean(name="taskExecutor")
	@ConditionalOnMissingBean(name = { "taskExecutor"})
	public ThreadPoolTaskExecutor threadPoolTaskExecutor() {
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(Integer.valueOf(corePoolSize));
		executor.setMaxPoolSize(Integer.valueOf(maxPoolSize));
		// executor.setQueueCapacity(11);
		executor.setThreadNamePrefix(threadNamePrefix);
		executor.initialize();
		return executor;
	}
	
	
	@Bean("objectMapper")
	@ConditionalOnMissingBean(name = { "objectMapper"})
	public ObjectMapper objectMapper() {
		LOG.info("objectMapper bean is created .....");
		return new ObjectMapper();
	}
	
}
