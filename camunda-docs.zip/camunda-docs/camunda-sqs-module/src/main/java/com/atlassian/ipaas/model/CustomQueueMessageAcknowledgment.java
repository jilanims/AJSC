package com.atlassian.ipaas.model;

public class CustomQueueMessageAcknowledgment {

	private final String queueUrl;
	private final String receiptHandle;

	public CustomQueueMessageAcknowledgment(String queueUrl, String receiptHandle) {
		this.queueUrl = queueUrl;
		this.receiptHandle = receiptHandle;
	}

	public String getQueueUrl() {
		return queueUrl;
	}

	public String getReceiptHandle() {
		return receiptHandle;
	}

}
