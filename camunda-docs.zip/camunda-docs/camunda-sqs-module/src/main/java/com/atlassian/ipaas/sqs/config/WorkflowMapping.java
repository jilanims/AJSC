package com.atlassian.ipaas.sqs.config;

import java.util.HashMap;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Component;

@Component(value="workflowMapping")
@EnableConfigurationProperties
@ConfigurationProperties(prefix = "aws.sqs.consumer.workflow")
public class WorkflowMapping {

	private HashMap<String, String> mapping;

	public HashMap<String, String> getMapping() {
		return mapping;
	}

	public void setMapping(HashMap<String, String> mapping) {
		this.mapping = mapping;
	}
	
	

}
