/**
* The class send the message to AWS SQS Queue 
* 
*/
package com.atlassian.ipaas.sqs;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cloud.aws.messaging.core.QueueMessagingTemplate;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Component;

import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.MessageAttributeValue;
import com.atlassian.ipaas.sqs.constants.AwsSqsConstants;

@Component("awsSqsSender")
@ConditionalOnProperty(value="aws.sqs.enable", havingValue="true")
public class AwsSqsSender {

	private static final Logger LOG = LoggerFactory.getLogger(AwsSqsSender.class);

	@Autowired
	private QueueMessagingTemplate queueMessagingTemplate;

	@Value("${aws.sqs.sender.end-point.uri}")
	public String sqsEndPoint;
	
	@Value("${aws.sqs.message.type:type}")
	String TYPE;
	
	@Value("${aws.sqs.message.id:id}")
	String ID;
	
	/**
	 * 
	 * This method always returns SUCCESS, when the message is send to AWS SQS queue 
	 *
	 * @param  Message  to send the data to SQS Queue
	 * @return      send success message
	 */
	public String sendMessageToAwsSQS(Message message) {
		LOG.debug("Send Message to AWS SQS");

		try {
			String wfStartEventType = null,workflowName = null,uniqueBusinessKey  = null;
			
			
			if(null!=message.getAttributes()) {
				wfStartEventType = message.getAttributes().get(TYPE);
				workflowName =  message.getAttributes().get(AwsSqsConstants.WORKFLOW_NAME);
				uniqueBusinessKey = message.getAttributes().get(AwsSqsConstants.WORKFLOW_BUSINESS_KEY);
			}
			
			Map<String, MessageAttributeValue> messageAttributes = message.getMessageAttributes();
			if(null!=messageAttributes && messageAttributes.size()>0) {
				LOG.info("Message attributes : {}", messageAttributes);
			}
			
			queueMessagingTemplate.send(sqsEndPoint,
					MessageBuilder.withPayload(message.getBody())
					.setHeader(TYPE, wfStartEventType)
					.setHeader(AwsSqsConstants.WORKFLOW_NAME, workflowName)
					.setHeader(AwsSqsConstants.WORKFLOW_BUSINESS_KEY, uniqueBusinessKey)
					//.setHeader(AwsSqsConstants.QUEUE_URL, sqsEndPoint)
					
					.build());
			return "SUCCESS: Message send to AWS SQS";
		} catch (Exception e) {
			throw new RuntimeException("Could not tranform and send message due to: " + e.getMessage(), e);
		}
	}
}
