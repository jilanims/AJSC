/**
* The class consume the message from AWS SQS Queue using long polling through @sqslistener and trigger the camunda workflow.
* And output is to trigger the camunda workflow based on event
*/

package com.atlassian.ipaas.sqs;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cloud.aws.messaging.listener.Acknowledgment;
import org.springframework.cloud.aws.messaging.listener.SqsMessageDeletionPolicy;
import org.springframework.cloud.aws.messaging.listener.annotation.SqsListener;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.stereotype.Component;

import com.atlassian.ipaas.model.CustomQueueMessageAcknowledgment;
import com.atlassian.ipaas.sqs.constants.AwsSqsConstants;
import com.atlassian.ipaas.workflow.TriggerWorkflow;;

@Component
@ConditionalOnProperty(value = "aws.sqs.enable", havingValue = "true")
public class AwsSqsListener {

	private static final Logger LOG = LoggerFactory.getLogger(AwsSqsListener.class);

	@Value("${aws.sqs.defaultDeletionPolicy:true}")
	private boolean awsSqsMsgDefaultDeletion;
	
	@Autowired
	TriggerWorkflow camunda;
	
	/**
	 * This method, listens to the queues configured in end-point.uri 
	 * then validate to trigger the camunda workflow 
	 *
	 * @param  message data send to aws sqs queue
	 * @param  acknowledgment to acknowledge (deletion) the message from the queue.
	 * @param  header to get the list of message headers
	 * @return      void
	 */
	@SqsListener(value = "#{'${aws.sqs.consumer.end-point.uri}'.split(',')}", deletionPolicy = SqsMessageDeletionPolicy.NEVER)
	public void receivedMessage(String message, Acknowledgment acknowledgment, @Headers Map<String, String> header)
			throws Exception {
		
		LOG.info("SQS Message Id - {} ", header.get(AwsSqsConstants.AWS_SQS_MESSAGE_ID));
		
		CustomQueueMessageAcknowledgment customQueueMessageAcknowledgment = null;

		if (null != header && awsSqsMsgDefaultDeletion==false) {
			// user will explicitly delete the AWS SQS message from the queue after
			// completing all the tasks in the camunda workflow based on their business
			// requirements.
			customQueueMessageAcknowledgment = new CustomQueueMessageAcknowledgment(
					header.get(AwsSqsConstants.QUEUE_URL), header.get(AwsSqsConstants.AWS_SQS_RECEIPT_HANDLE));
		}
		camunda.triggerWorkflow(message, customQueueMessageAcknowledgment, header);
		
		LOG.info("awsSqsMsgDefaultDeletion:{}",awsSqsMsgDefaultDeletion);
		// After successfully triggering the camunda workflow, delete the message from
		// AWS SQS Queue
		if (awsSqsMsgDefaultDeletion==true && null!=acknowledgment) {
			acknowledgment.acknowledge();
		}
	}
	
	public void setCamunda(TriggerWorkflow camunda) {
		this.camunda = camunda;
	}

}
