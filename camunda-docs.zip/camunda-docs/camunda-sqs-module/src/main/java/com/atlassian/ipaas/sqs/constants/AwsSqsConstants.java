package com.atlassian.ipaas.sqs.constants;

public class AwsSqsConstants {
	public static final String START_EVENT = "startEvent";
	public static final String MESSAGE_EVENT = "messageEvent";
	public static final String SQS_PAYLOAD = "SQS_PAYLOAD";
	public static final String TYPE = "type";
	public static final String AWS_SQS_ACKNOWLEDGEMENT = "aws_sqs_acknowledgment";
	public static final String QUEUE_URL = "LogicalResourceId";
	public static final String RECEIPT_HANDLE = "receiptHandle";
	public static final String AWS_SQS_RECEIPT_HANDLE = "ReceiptHandle";
	public static final String AWS_SQS_MESSAGE_ID = "MessageId";
	public static final String WORKFLOW_NAME = "workFlowName";
	public static final String WORKFLOW_BUSINESS_KEY = "uniqueBusinessKey";
}
