# This dependency is used to listen to AWS SQS and trigger the camunda workflow SQS_PAYLOAD based on the startEvent and messageEvent.
# Please refer to https://hello.atlassian.net/wiki/spaces/CAM/pages/684188736/How-To+Invoke+Camunda+Process+through+AWS+SQS+Polling+module+in+Service+Application


1) Please add below dependency to your pom.xml
	
	<dependency>
		<groupId>com.atlassian.camunda</groupId>
		<artifactId>camunda-sqs-module</artifactId>
		<version>0.0.2</version>
	</dependency>

2) Configure your AWS SQS Queue of Sender and Listener in application.yml, please refer to below example

cloud:
  aws:
    region:
      static: us-east-1
      auto: false
    stack:
      auto: false

aws.sqs:
  credentials:
    useDefaultAwsCredentialsChain: true
  enable: "true"
  defaultDeletionPolicy: true
  queue:
    maxNumberOfMessages: 10
    visibilityTimeout: 30
    waitTimeSeconds: 20
    attributeName:
  threadPool:
    corePoolSize: 10
    maxPoolSize: 20
    threadNamePrefix: "threadPoolExecutor-"
  consumer:
      workflow:
        mapping:
          INVOICE: startEventId:startEvent
          key2: value2
          key3: value3
      end-point:
        uri: "SQS_QUEUE_HELLO_WORLD_RECEIVE"
  sender:
    end-point:
        uri: "SQS_QUEUE_HELLO_WORLD_SEND"
 
3) Based on I AM assume role, step 2 configuration works. So kindly setup your AWS CLI in Local for your SQS https://docs.aws.amazon.com/cli/latest/userguide/cli-chap-configure.html#cli-quick-configuration

4) suppose you need to deploy to micros, then please add SQS resource to your *.sd.yml file. please refer to https://hello.atlassian.net/wiki/spaces/MICROS/pages/169250134/SQS+Resource+Type

5) compile and build using 'mvn clean install'

6) jacoco-maven-plugin plugin has been add to pom.xml which will verify the 90% test cases code coverage for the application. Fore more info, please refer to https://hello.atlassian.net/wiki/spaces/CAM/pages/743623211/How-to+check+90+code+coverage
 