package com.atlassian.bamboo;

import java.util.HashMap;
import java.util.Map;

@SuppressWarnings("serial")
public final class BambooSpecVariables {

	/* Bamboo project/team id, where the plan will be created. eg: 'IPAAS' */
	public static final String bambooProjectKey = "IPAAS";

	/* Unique key for your new service. eg: 'HWIM4' */
	public static final String bambooPlanKey = "CAWEMOWEBAPP";

	/*
	 * Bamboo project/team name in Bamboo, where the plan will be created. eg: 'iPaaS' */
	public static final String bambooProjectName = "iPaaS";

	/* slack channel name */
	public static final String slackChannelName = "#moe-notifications";

	/* Integration project name. eg: 'Hi World Camunda' */
	public static final String serviceReadableName = "cawemo-webapp";

	/* Bamboo display name of the linked repository. eg: 'MOE Hi World Camunda' */
	public static final String bambooRepositoryName = "cawemo-webapp";

	/* Email for notifications in case of deploy failures in PROD. eg: 'vvarma@atlassian.com' */
	public static final String emailForNotifications = "vvarma@atlassian.com";

	/* User id of the person responsible for plan. eg: 'vvarma' */
	public static final String planOwner = "vvarma";

	/* Team's AD group for access to the plan & deployment. eg: 'ipaas-dl-all' */
	public static final String groupNameForPermission = "ipaas-dl-all";


	/* Environment and properties map */
	public static final Map<String, Map<String, String>> envList = new HashMap<String, Map<String, String>>() {
		{
			put("adev", new HashMap<String,String>());
		}
	};

	/* Do not change unless image change has been requested by Build-eng */

	public static final String itBambooImage = "docker.atl-paas.net/buildeng/agent-baseagent";
	public static final String deploymentBambooImage = "docker.atl-paas.net/sox/buildeng/agent-baseagent";

	/* Release Notes Variables */

	/* stash token */
	public static final String stashToken = "bamboo_ipaas_stashandbamboo_token_password";

	/* confluence token */
	public static final String confluenceToken = "bamboo_ipaas_confluence_token_password";
	/* bamboo token */
	public static final String bambooToken = "bamboo_ipaas_stashandbamboo_token_password";

	/* Release notes name */
	public static final String releaseNotesName = "cawemo-webapp";

	/* Confluence space key */
	public static final String spaceKey = "IAS";  //go/camunda homepage

	/* Confluence parent page id */
	public static final String parentPageId = "687332061";

	/* Project key */
	public static final String projectKey = "MOE";

	/* repository name */
	public static final String repositoryName = "cawemo-webapp";

	/* flag to enable/disable release notes */
	public static final Boolean enableReleaseNotes = true;
	
	/* flag to enable/disable Failing build if PR Description is not found */
	public static final Boolean emptyPRDescriptionFailBuild = false;

	/* flag to enable/disable appending the latest release notes towards the  start of the document */
	public static final Boolean latestReleaseNotesFirst = true;
}