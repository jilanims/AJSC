package bamboo;

import com.atlassian.bamboo.specs.api.builders.deployment.Deployment;
import com.atlassian.bamboo.specs.api.builders.deployment.Environment;
import com.atlassian.bamboo.specs.api.builders.deployment.ReleaseNaming;
import com.atlassian.bamboo.specs.api.builders.permission.DeploymentPermissions;
import com.atlassian.bamboo.specs.api.builders.permission.EnvironmentPermissions;
import com.atlassian.bamboo.specs.api.builders.permission.PermissionType;
import com.atlassian.bamboo.specs.api.builders.permission.Permissions;
import com.atlassian.bamboo.specs.api.builders.plan.PlanIdentifier;
import com.atlassian.bamboo.specs.api.builders.requirement.Requirement;
import com.atlassian.bamboo.specs.api.builders.task.Task;
import com.atlassian.bamboo.specs.builders.task.ArtifactDownloaderTask;
import com.atlassian.bamboo.specs.builders.task.CleanWorkingDirectoryTask;
import com.atlassian.bamboo.specs.builders.task.DownloadItem;
import com.atlassian.bamboo.specs.builders.task.ScriptTask;
import com.atlassian.bamboo.specs.builders.task.VcsCheckoutTask;
import com.atlassian.bamboo.specs.builders.trigger.AfterSuccessfulBuildPlanTrigger;
import com.atlassian.bamboo.specs.builders.trigger.AfterSuccessfulDeploymentTrigger;
import com.atlassian.bamboo.specs.util.BambooServer;
import com.atlassian.bamboo.specs.util.Logger;
import com.google.common.collect.ImmutableList;

import java.util.List;

import static bamboo.Constants.BUILD_AND_TEST_PLAN_KEY;
import static bamboo.Constants.BUILD_OUTPUT_FOLDER;
import static bamboo.Constants.DEPLOY_PLAN_NAME;
import static bamboo.Constants.PROJECT_KEY;
import static bamboo.Constants.RELEASE_NAME;
import static bamboo.Constants.REPOSITORY;
import static bamboo.MicrosEnvironment.*;
import static bamboo.PlanHelpers.isDeploymentBambooInstance;
import static bamboo.PlanHelpers.isSOXEnabled;

public class DeploymentSpec {
    private static final Logger LOG = Logger.getLogger(DeploymentSpec.class);

    private static final String DOMAIN_DEV_ENVIRONMENT = "Domain Dev";
    private static final String APP_DEV_ENVIRONMENT = "App Dev";
    private static final String STG_EAST_ENVIRONMENT = "Staging East";
    private static final String PROD_EAST_ENVIRONMENT = "Production East";
    /**
     * Contains all of the tasks that will be needing to be done to deploy it to a micros environment.
     */
    private static Task[] deploymentTasks(final MicrosEnvironment environment) {
        return new Task[] {
                new CleanWorkingDirectoryTask(),
                new VcsCheckoutTask()
                        .addCheckoutOfRepository(REPOSITORY),
                new ArtifactDownloaderTask()
                        .sourcePlan(new PlanIdentifier(PROJECT_KEY, BUILD_AND_TEST_PLAN_KEY))
                        .artifacts(new DownloadItem()
                        .artifact("Service descriptor")
                        .path(BUILD_OUTPUT_FOLDER)
                ),
                new ScriptTask()
                        .requirements(new Requirement("os").matchType(Requirement.MatchType.EQUALS).matchValue("Linux"))
                        .description("Deploy to micros")
                        .inlineBody("./bin/deploy-in-bamboo.sh " + environment.getName())
        };
    }

    /**
     * Configures all of the deployment environments and creates the tasks to deploy to the corresponding
     * micros environments.
     */
    private static Deployment deploymentPlan() {
    	final Deployment rootObject = new Deployment(new PlanIdentifier(PROJECT_KEY, BUILD_AND_TEST_PLAN_KEY), DEPLOY_PLAN_NAME)
                .releaseNaming(new ReleaseNaming(RELEASE_NAME));

            if(isDeploymentBambooInstance())
            {
                rootObject.environments(
                        new Environment(STG_EAST_ENVIRONMENT)
                                .tasks(deploymentTasks(STAGING_EAST)),
                        new Environment(PROD_EAST_ENVIRONMENT)
                                .tasks(deploymentTasks(PRODUCTION_EAST)));
            }
            else
            {
                rootObject.environments(
                        new Environment(DOMAIN_DEV_ENVIRONMENT)
                                .triggers(new AfterSuccessfulBuildPlanTrigger())
                                .tasks(deploymentTasks(DOMAIN_DEV)),
                        new Environment(APP_DEV_ENVIRONMENT)
                                .tasks(deploymentTasks(APPLICATION_DEV)));   
            }

        return rootObject;
    }

    /**
     * Basic permissions that will be used for the deployment project as well as each of the environments in the
     * deployment.
     */
    private static Permissions permissions() {
        return new Permissions()
                .anonymousUserPermissionView()
                .loggedInUserPermissions(PermissionType.VIEW, PermissionType.BUILD);
    }

    private static DeploymentPermissions deploymentPermissions() {
        return new DeploymentPermissions(DEPLOY_PLAN_NAME)
                .permissions(new Permissions()
                        .anonymousUserPermissionView()
                        .loggedInUserPermissions(PermissionType.VIEW,PermissionType.EDIT));
    }

    /**
     * We need to assign permissions for each environment otherwise when you view the deployment there will be no
     * environments listed in the list even though though they have been created.
     */
    private static List<EnvironmentPermissions> environmentPermissions() {
        if(isDeploymentBambooInstance())
        {
            return ImmutableList.of(
                    new EnvironmentPermissions(DEPLOY_PLAN_NAME)
                            .environmentName(STG_EAST_ENVIRONMENT)
                            .permissions(permissions()),
                    new EnvironmentPermissions(DEPLOY_PLAN_NAME)
                            .environmentName(PROD_EAST_ENVIRONMENT)
                            .permissions(permissions()));
        }
        else
        {
            return ImmutableList.of(
                    new EnvironmentPermissions(DEPLOY_PLAN_NAME)
                            .environmentName(DOMAIN_DEV_ENVIRONMENT)
                            .permissions(permissions()),
                    new EnvironmentPermissions(DEPLOY_PLAN_NAME)
                            .environmentName(APP_DEV_ENVIRONMENT)
                            .permissions(permissions()));
        }
    }

    /**
     * Will publish this spec to the provided {@link BambooServer}.
     *
     * @param bambooServer the server to publish to
     */
    public void publishToBamboo(final BambooServer bambooServer) {
        final boolean enableDeployment = isDeploymentBambooInstance() || !isSOXEnabled();

        if (!enableDeployment) {
            LOG.info("Not a deployment instance, ignoring.");
            return;
        }

        bambooServer.publish(DeploymentSpec.deploymentPlan());
        bambooServer.publish(DeploymentSpec.deploymentPermissions());

        for (final EnvironmentPermissions environmentPermissions : DeploymentSpec.environmentPermissions()) {
            bambooServer.publish(environmentPermissions);
        }
    }
}
