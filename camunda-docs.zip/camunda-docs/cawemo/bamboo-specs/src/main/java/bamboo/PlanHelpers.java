package bamboo;

import com.google.common.collect.ImmutableSet;
import lombok.experimental.UtilityClass;

import javax.annotation.Nullable;
import java.util.Set;
import com.atlassian.bamboo.specs.api.context.RssRuntimeContext;

/**
 * Some helper functions that are used across all of the plans.
 */
@UtilityClass
final class PlanHelpers {
    private static final String DEPLOYMENT_BAMBOO_INSTANCE_NAME = "deployment-bamboo";
    //private static final String SANDBOX_BAMBOO_INSTANCE_NAME = "sandbox-bamboo";
    //private static final String BAMBOO_SPECS_INSTANCE_NAME_SYS_PROP = "specs.bamboo.instanceName";
    private static final String BAMBOO_SERVER_URL_SYS_PROP = "bambooServerUrl";

    // These are some example bamboo instances where we should allow the deployment of microservices/artifacts.
    // Note that SANDBOX_BAMBOO_INSTANCE_NAME is included for testing.
    /*private static final Set<String> DEPLOYMENT_INSTANCES = ImmutableSet.of(
            DEPLOYMENT_BAMBOO_INSTANCE_NAME, SANDBOX_BAMBOO_INSTANCE_NAME
    );*/

    /**
     * Determine if the instance we are adding the specs to is an instance that should be able to deploy
     * the service.
     */
    static boolean isDeploymentBambooInstance() {
        final String instanceName = RssRuntimeContext.getServerName().get();

        return instanceName != null && DEPLOYMENT_BAMBOO_INSTANCE_NAME.contains(instanceName);
    }

    /**
     * Get the server url for the bamboo instance, this is only useful for local development as this value should
     * be null when running on an actual bamboo instance.
     */
    @Nullable
    static String bambooServerUrl() {
        return System.getProperty(BAMBOO_SERVER_URL_SYS_PROP);
    }

    /**
     * Determine if SOX is enabled. If not we can deploy from any instance.
     */
    static boolean isSOXEnabled() {
        return false;
    }
}
