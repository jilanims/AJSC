package io.atlassian.camunda.rest.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.math.BigInteger;

import org.junit.jupiter.api.Test;

import com.tngtech.archunit.junit.AnalyzeClasses;

@AnalyzeClasses(packages = "io.atlassian.camunda.rest.controller")
public class RestTests {
	
	

    @Test
    public void multiplicationOfZeroIntegersShouldReturnZero() {
    	// create 3 BigInteger objects
        BigInteger bi1, bi2, bi3;

        bi1 = new BigInteger("7");
        bi2 = new BigInteger("20");

        // multiply bi1 with bi2 and assign result to bi3
        bi3 = bi1.multiply(bi2);

        // assert statements
        assertEquals(BigInteger.valueOf(140), bi3, "7 x 20 must be 140");
    }
}
