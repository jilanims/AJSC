package com.atlassian.camunda.config;

import java.io.IOException;
import java.text.MessageFormat;
import java.time.Duration;
import java.util.logging.Logger;

import javax.servlet.DispatcherType;

import org.camunda.bpm.webapp.impl.security.auth.ContainerBasedAuthenticationFilter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import com.atlassian.camunda.groups.AdminGroupCLR;
import com.atlassian.camunda.license.LicenseFileCLR;
import com.atlassian.camunda.rest.auth.KeyValue;
import com.atlassian.camunda.slauth.ssam.CamundaSSAMRoleInfo;
import com.atlassian.camunda.slauth.ssam.SLAuthAuthenticationProvider;
import com.fasterxml.jackson.databind.ObjectMapper;

@Configuration
public class CamundaConfiguration {
	
	private final static Logger LOGGER = Logger.getLogger(CamundaConfiguration.class.getName());
	

    private String restUsername;
    private String restPWD;
    
    @Value("${REST_CREDENTIALS}")
    String credsJsonText;
    KeyValue[] creds;

    @SuppressWarnings({"unchecked","rawtypes"})
	@Bean
    public FilterRegistrationBean processEngineAuthenticationFilter() {

        //https://docs.camunda.org/manual/7.10/webapps/shared-options/container-based-authentication/
    	
		FilterRegistrationBean registration = new FilterRegistrationBean();
        registration.setName("Container Based Authentication Filter");
        registration.setFilter(new ContainerBasedAuthenticationFilter());
        registration.addInitParameter("authentication-provider",
                SLAuthAuthenticationProvider.class.getName());
        registration.addUrlPatterns("/camunda/app/*");
        registration.setDispatcherTypes(DispatcherType.REQUEST);
        return registration;
    }



    @Bean("camunda-rest-api")
    public RestTemplate restTemplate(RestTemplateBuilder builder) {
    	clean();
    	init();
        return builder
                .basicAuthentication(restUsername,restPWD)
                .setConnectTimeout(Duration.ofMillis(120000))
                .setReadTimeout(Duration.ofMillis(120000))
                .build();
    }

    @Bean
    @ConditionalOnMissingBean(RestTemplate.class)
    public RestTemplate restTemplateForZipKin() {
        return new RestTemplate();
    }


    @Bean("camunda-ssam")
    @ConfigurationProperties(prefix = "camunda.ssam.roles")
    public CamundaSSAMRoleInfo camundaSSAMRoleInfo(){
        return  new CamundaSSAMRoleInfo();
    }

    @Bean
    public AdminGroupCLR adminGroupCLR() {return  new AdminGroupCLR(); }
    
    @Bean
    public LicenseFileCLR licenseFileCLR() {return  new LicenseFileCLR(); }
    
    
    private void init(){
        ObjectMapper mapper = new ObjectMapper();
        try {
            creds = mapper.readValue(credsJsonText, KeyValue[].class);
        } catch (IOException e) {
        	LOGGER.info("The Login failed due to stash key/jvm argument credsJsonText is wrong");
            e.printStackTrace();
        }
        if (creds!=null) {
        	for (KeyValue kv :creds) {
        		restUsername= kv.getSecretKey();
            	restPWD= kv.getSecretValue();
            	break;
        	}
        	
        }
    }
    private void clean(){
    	restUsername=null;
    	restPWD=null;
    	creds=null;
    }
    
}
