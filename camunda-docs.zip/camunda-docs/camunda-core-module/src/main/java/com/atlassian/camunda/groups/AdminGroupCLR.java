package com.atlassian.camunda.groups;

import org.camunda.bpm.engine.AuthorizationService;
import org.camunda.bpm.engine.IdentityService;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.authorization.Permissions;
import org.camunda.bpm.engine.authorization.Resource;
import org.camunda.bpm.engine.authorization.Resources;
import org.camunda.bpm.engine.identity.Group;
import org.camunda.bpm.engine.impl.persistence.entity.AuthorizationEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;

import com.atlassian.camunda.utils.CamundaCoreConstants;

import java.util.logging.Logger;

public class AdminGroupCLR  implements CommandLineRunner {

    private final static Logger LOGGER = Logger.getLogger(AdminGroupCLR.class.getName());

    @Autowired
    ProcessEngine processEngine;

    @Override
    public void run(String... args) throws Exception {

//        copied from org.camunda.bpm.spring.boot.starter.configuration.impl.custom.CreateAdminUserConfiguration
        IdentityService identityService = processEngine.getIdentityService();
        AuthorizationService authorizationService = processEngine.getAuthorizationService();

        if (identityService.createGroupQuery().groupId(CamundaCoreConstants.CAMUNDA_ADMIN).count() == 0L) {
            Group camundaAdminGroup = identityService.newGroup(CamundaCoreConstants.CAMUNDA_ADMIN);
            camundaAdminGroup.setName("camunda BPM Administrators");
            camundaAdminGroup.setType(CamundaCoreConstants.SYSTEM);
            identityService.saveGroup(camundaAdminGroup);
            LOGGER.info("Created Camunda Admin Group.");

        }else{
            LOGGER.info("Camunda Admin Group already exists.");
        }
        Resources[] var9 = Resources.values();
        int var5 = var9.length;

        for(int var6 = 0; var6 < var5; ++var6) {
            Resource resource = var9[var6];
            if (authorizationService.createAuthorizationQuery().groupIdIn(new String[]{CamundaCoreConstants.CAMUNDA_ADMIN}).resourceType(resource).resourceId(CamundaCoreConstants.ASTERISK).count() == 0L) {
                AuthorizationEntity userAdminAuth = new AuthorizationEntity(1);
                userAdminAuth.setGroupId(CamundaCoreConstants.CAMUNDA_ADMIN);
                userAdminAuth.setResource(resource);
                userAdminAuth.setResourceId(CamundaCoreConstants.ASTERISK);
                userAdminAuth.addPermission(Permissions.ALL);
                authorizationService.saveAuthorization(userAdminAuth);
            }
        }
    }
}
