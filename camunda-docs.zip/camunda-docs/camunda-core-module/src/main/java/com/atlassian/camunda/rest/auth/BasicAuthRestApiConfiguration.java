package com.atlassian.camunda.rest.auth;



import java.io.IOException;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.crypto.password.StandardPasswordEncoder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import com.atlassian.asap.core.server.springsecurity.AsapAuthenticationProvider;
import com.atlassian.asap.core.server.springsecurity.BearerTokenAuthenticationProcessingFilter;
import com.atlassian.asap.core.validator.JwtValidator;
import com.fasterxml.jackson.databind.ObjectMapper;

@SuppressWarnings("deprecation")
@Configuration
@EnableWebSecurity
public class BasicAuthRestApiConfiguration extends WebSecurityConfigurerAdapter {
	
	private final static Logger LOGGER = Logger.getLogger(BasicAuthRestApiConfiguration.class.getName());
	
    @Autowired
    JwtValidator jwtValidator;
    @Value("${REST_CREDENTIALS}")
    String credsJsonText;
    KeyValue[] creds;

    @Value("${rest.auth.url.patterns:/engine-rest/**}")
	private String[] customRestUrlPatterns;
    

    @PostConstruct
    public void init(){
    	
        ObjectMapper mapper = new ObjectMapper();
        try {
        	//LOGGER.info("credsJsonText:"+credsJsonText);
            creds = mapper.readValue(credsJsonText, KeyValue[].class);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        // Yes, I know it's deprecated but it's a better fit than BCrypt for this application - can write our own later
        PasswordEncoder passwordEncoder = new StandardPasswordEncoder();

        for (KeyValue kv :creds) {
            auth
                    .authenticationProvider(new AsapAuthenticationProvider(jwtValidator))
                    .inMemoryAuthentication()
                    .passwordEncoder(passwordEncoder)
                    .withUser(kv.getSecretKey())
                    .password(passwordEncoder.encode(kv.getSecretValue()))
                    .roles("BAUTH_USER");
        }
    }
    
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.csrf().disable()
                .httpBasic()
                .and()
                .addFilterBefore(new BearerTokenAuthenticationProcessingFilter(authenticationManager()), BasicAuthenticationFilter.class)
                .authorizeRequests()
                .antMatchers(customRestUrlPatterns).authenticated()
                .and()
                .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS);
        ;
    }
    
}
