package com.atlassian.camunda.slauth.ssam;


import java.util.Collections;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.LdapContext;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service("ldapService")
public class SsamLdapService {
	private final static Logger LOGGER = Logger.getLogger(SsamLdapService.class.getName());
    static final String GROUPS_SEARCH_BASE = "ou=groups,dc=office,dc=atlassian,dc=com";
    static final String CANONICAL_NAME_ATTR = "cn";
    static final String LDAP_SEARCH_GROUP_RECURSION_PATTERN = ":1.2.840.113556.1.4.1941:";

    @Value("${ldap.providerUrl}")
    private String providerUrl;
    @Value("${ldap.username}")
    private String username;
    @Value("${ldap.pwd}")
    private String pwd;



    private static String extractValues(Attributes attributes) {
        try {
            String canonicalName = String.valueOf(attributes.get(CANONICAL_NAME_ATTR).get());
            return canonicalName;
        } catch (NamingException e) {
            e.printStackTrace();
        }
        return null;
    }

    DirContext connectToAtlassianLdap() throws NamingException {
        Hashtable<String, String> environment = new Hashtable<>();

        environment.put(LdapContext.CONTROL_FACTORIES, "com.sun.jndi.ldap.ControlFactory");
        environment.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        environment.put(Context.PROVIDER_URL, providerUrl);
        environment.put(Context.SECURITY_PRINCIPAL, "ATLASSIAN\\" + username);
        environment.put(Context.SECURITY_CREDENTIALS, pwd);

        return new InitialDirContext(environment);
    }

    public Set<String> findSSAMGroupsByUserNameAndContainerName(String userName,CamundaSSAMRoleInfo ssamRoleInfo) throws Exception {
    	    LOGGER.info("ssamRoleInfo:"+ssamRoleInfo);
            String searchFilter = String.format("(&"
                        + "  (objectClass=group)"
                        + "  (description=*SSAM Managed*)"
                        + "  (&(cn=%s-dl-*)(!(cn=%s)))"
                        + "  (|"
                        + "    (member%s=cn=%s,OU=bots,OU=people,DC=office,DC=atlassian,DC=com)"
                        + "    (member%s=cn=%s,OU=people,DC=office,DC=atlassian,DC=com)"
                        + "  )"
                        + ")",
                    ssamRoleInfo.getAccessContainer(),
                ssamRoleInfo.getMicrosAdminGroup(),
                LDAP_SEARCH_GROUP_RECURSION_PATTERN ,
                userName,
                LDAP_SEARCH_GROUP_RECURSION_PATTERN ,
                userName);

        return queryLdapGroups(searchFilter);
    }

    public Set<String> findSSAMGroupsByContainerName(CamundaSSAMRoleInfo ssamRoleInfo) throws Exception {

        String searchFilter = String.format("(&"
                        + "  (objectClass=group)"
                        + "  (description=*SSAM Managed*)"
                        + "  (&(cn=%s-dl-*)(!(cn=%s)))"
                        + ")",
                ssamRoleInfo.getAccessContainer(),ssamRoleInfo.getMicrosAdminGroup());

        return queryLdapGroups( searchFilter);
    }

    private Set<String> queryLdapGroups(String searchFilter) throws NamingException {
    	LOGGER.info("searchFilter:"+searchFilter);
        DirContext context = connectToAtlassianLdap();

        SearchControls searchControls = new SearchControls();
        searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
        searchControls.setReturningAttributes(new String[]{ CANONICAL_NAME_ATTR});


        NamingEnumeration<SearchResult> results = context.search(GROUPS_SEARCH_BASE, searchFilter, searchControls);
        List<SearchResult> resultsList = Collections.list(results);

        Set<String> groups = resultsList.stream()
                .map(SearchResult::getAttributes)
                .map(SsamLdapService::extractValues)
                .collect(Collectors.toSet());

        return groups;
    }

}
