package com.atlassian.camunda.groups;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.atlassian.camunda.groups.entity.Group;
import com.atlassian.camunda.groups.entity.GroupRequest;
import com.atlassian.camunda.groups.entity.UserRequest;

@Service("camundaService")
public class CamundaUserRestService {

    private final static Logger LOGGER = Logger.getLogger(CamundaUserRestService.class.getName());

    @Autowired
    @Qualifier("camunda-rest-api")
    RestTemplate camundaRest;
    @Value("${camunda.rest.api.engine:default}")
    private String defaultEngine;
    @Value("${camunda.rest.api.user.get:http://localhost:8080/engine-rest/engine/{0}/user/{1}/profile}")
    private String urlUserGet;
    @Value("${camunda.rest.api.user.create:http://localhost:8080/engine-rest/engine/{0}/user/create}")
    private String urlUserCreate;
    @Value("${camunda.rest.api.user.group.member:http://localhost:8080/engine-rest/engine/{0}/group/{1}/members/{2}}")
    private String urlGroupMember;
    @Value("${camunda.rest.api.group.get:http://localhost:8080/engine-rest/engine/{0}/group}")
    private String urlGroupGet;
    @Value("${spring.profiles.active:prod}")
    private String activeProfile;
    @Value("${camunda.flag.promote.user2admin:false}")
    private Boolean promoteDevtoAdminFlag;

    public void createUser(String userID, String fname, String lname, String email){

        try {
            UserRequest request = new UserRequest();
            request.build(userID,fname,lname,email);

            ResponseEntity<String> response = camundaRest.postForEntity(MessageFormat.format(urlUserCreate,defaultEngine),request,String.class);

            if (HttpStatus.NO_CONTENT == response.getStatusCode()){
                LOGGER.info(MessageFormat.format("User {0} has been successfully created.",userID));
            }

        }catch (Exception e){
            e.printStackTrace();
            LOGGER.info(MessageFormat.format("Internal Errror when creating User : {0} .",userID));
        }

    }

    public Boolean isExistingUser(String userName){

        try {
            ResponseEntity<String> response = camundaRest.exchange(MessageFormat.format(urlUserGet,defaultEngine,userName), HttpMethod.GET, null, String.class);

            if (HttpStatus.OK == response.getStatusCode()){
                LOGGER.fine(MessageFormat.format("User {0} is an existing user.",userName));
                return Boolean.TRUE;
            }
        }catch (Exception e){
            LOGGER.fine(MessageFormat.format("User {0} is NOT an existing user.",userName));
            return Boolean.FALSE;
        }

        return Boolean.FALSE;

    }
    
    @SuppressWarnings("unused")
    public void addUserToGroup(String userid, String groupid){

        try {
            ResponseEntity<String> response = camundaRest.exchange(MessageFormat.format(urlGroupMember,defaultEngine,groupid,userid), HttpMethod.PUT, null, String.class);
            LOGGER.info(MessageFormat.format("User : {0} added to group : {1}",userid,groupid));
        }catch (Exception e){
            LOGGER.warning(MessageFormat.format("Error when adding User : {0} added to group : {1}, might be because user might be already part of the group.",userid,groupid));
            LOGGER.warning(e.getMessage());
        }

    }

    @SuppressWarnings("unused")
    public void removeUserFromGroup(String userid, String groupid){

        try {
            ResponseEntity<String> response = camundaRest.exchange(MessageFormat.format(urlGroupMember,defaultEngine,groupid,userid), HttpMethod.DELETE, null, String.class);
            LOGGER.info(MessageFormat.format("User {0} removed from group {1}",userid,groupid));
        }catch (Exception e){
            LOGGER.warning(MessageFormat.format("Error when removing User : {0} from group : {1}, might be because user might not be part of the group.",userid,groupid));
            LOGGER.warning(e.getMessage());
        }

    }

    public List<String > getAllGroups(){

        ResponseEntity<Group[]> response = camundaRest.exchange(MessageFormat.format(urlGroupGet,defaultEngine), HttpMethod.GET, null, Group[].class);
        List<String> groupList = new ArrayList<>(response.getBody().length);
        for (Group grp: response.getBody()) {
            groupList.add(grp.getId());
        }
        return groupList;
    }



    public  List<String > getAllGroupsForUser(String userID){

        try {
            GroupRequest request = new GroupRequest();
            request.setMember(userID);

            ResponseEntity<Group[]> response = camundaRest.postForEntity(MessageFormat.format(urlGroupGet,defaultEngine),request, Group[].class);
            List<String> groupList = new ArrayList<>(response.getBody().length);
            if (HttpStatus.OK == response.getStatusCode()){
                for (Group grp: response.getBody()) {
                    groupList.add(grp.getId());
                }
            }
            return groupList;
        }catch (Exception e){
            LOGGER.warning(MessageFormat.format("Error when reading list of groups for the user : {0}, Error message : {1}",userID, e.getMessage()));
            return null;
        }

    }

    /**
     * method to promote a developer to admin in non-prod based on a flag.
     *
     * @param userID
     */
    public void promoteDeveloperToAdmin(String userID, String grpID){

        if ((promoteDevtoAdminFlag) && (!(activeProfile.contains("prod")))){
            LOGGER.info(MessageFormat.format("User {0} is promoted to Admin as the promote admin flag is set to true and it is not a Non-PROD ( {1} ) environment",userID,activeProfile));
            List<String>  userGroupList = getAllGroupsForUser(userID);
            if(!userGroupList.contains(grpID)) // add the user to camunda admin, if he is not part of the user group.
                addUserToGroup(userID,grpID);
        }

    }
}


