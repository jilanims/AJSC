package com.atlassian.camunda.slauth.ssam;



import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.rest.security.auth.AuthenticationProvider;
import org.camunda.bpm.engine.rest.security.auth.AuthenticationResult;
import org.camunda.bpm.webapp.impl.security.auth.Authentication;
import org.camunda.bpm.webapp.impl.security.auth.Authentications;
import org.springframework.core.env.Environment;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.support.RequestContextUtils;

import com.atlassian.camunda.groups.CamundaUserRestService;
import com.atlassian.camunda.utils.CamundaCoreConstants;

public class SLAuthAuthenticationProvider implements AuthenticationProvider {
	
    private final static Logger LOGGER = Logger.getLogger(SLAuthAuthenticationProvider.class.getName());

    final String TEXT_SSAM_DL = "-dl-";
    CamundaUserRestService camundaService;
    SsamLdapService ldapService;
    CamundaSSAMRoleInfo ssamInfo;
    Environment env;

    private void init(HttpServletRequest request){
        WebApplicationContext springContext = RequestContextUtils.findWebApplicationContext(request);
        this.camundaService = (CamundaUserRestService) springContext.getBean("camundaService");
        this.ldapService = (SsamLdapService) springContext.getBean("ldapService");
        this.ssamInfo= (CamundaSSAMRoleInfo) springContext.getBean("camunda-ssam");
        this.env= (Environment) springContext.getEnvironment();
    }

    @Override
    public AuthenticationResult extractAuthenticatedUser(HttpServletRequest request, ProcessEngine processEngine) {
    	//autowiring is not working as this code will be called from within a Filter Bean.
        if (this.camundaService == null || this.ldapService == null || this.ssamInfo == null)
            this.init(request);
        
        String userID = request.getHeader("X-Slauth-Subject");
        String userFN = request.getHeader("X-Slauth-User-Firstname");
        String userLN = request.getHeader("X-Slauth-User-Lastname");
        String userEmail = request.getHeader("X-Slauth-User-Email");
        String sessionId = null;
        
        if(null!=request.getSession(false)) {
        	sessionId = request.getSession(false).getId();
        }
        LOGGER.info(MessageFormat.format("Logged in User : {0} with Session ID : {1}",userID,sessionId) );
        userID = getUserId(userID);


        if (checkAuthDetailsFromSession(request, userID))
            return AuthenticationResult.successful(userID);

        

        List<String> camuGrpAvailForUserFromSSAM=getFilteredUserAccessGroupDLForSSAMContainer(userID);
        List<String> camuGrpNotAvailForUserFromSSAM = getFilteredUserNonAccessGroupDLForSSAMContainer(camuGrpAvailForUserFromSSAM);

        // from here , it means the logged in user has the neccessary access rights.
        if(camundaService.isExistingUser(userID)){
            processExistingUser(userID, camuGrpAvailForUserFromSSAM,camuGrpNotAvailForUserFromSSAM);
        }else{
            processNewUser(userID, userFN, userLN, userEmail, camuGrpAvailForUserFromSSAM);
        }

        camundaService.promoteDeveloperToAdmin(userID, CamundaCoreConstants.CAMUNDA_ADMIN);

        camuGrpAvailForUserFromSSAM=null;
        camuGrpNotAvailForUserFromSSAM=null;


        return AuthenticationResult.successful(userID);
    }

    /**
     * This method invokes the ssam to get the list of all dl groups available for a given container.
     * After that, the SSAM DL name will be converted into Camunda Group Name and will collect the access group which the user is not part of.
     *
     * @param accessGroups
     * @return
     */
    private List<String> getFilteredUserNonAccessGroupDLForSSAMContainer(List<String> accessGroups) {
        try {//group will not be empty, as it retrives all the groups available in the container.
            Set<String> allAccesSSAMGroups =ldapService.findSSAMGroupsByContainerName(ssamInfo);
            List<String> camundaAllGroups=getCamundaGroupNameFromSSAMGroups(allAccesSSAMGroups,ssamInfo);
            List<String> camundaNonAccessGroups= new ArrayList<String>();

            for (String name: camundaAllGroups) {
                if (!accessGroups.contains(name)){
                    camundaNonAccessGroups.add(name);
                }
            }

            return  camundaNonAccessGroups;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * This method invokes the ssam to get the list of dl groups for which the user has access to for a given container.
     * After that, the SSAM DL name will be converted into Camunda Group Name.
     *
     * @param userID
     * @return
     */
    private List<String> getFilteredUserAccessGroupDLForSSAMContainer(String userID) {
        Set<String> userAccesSSAMGroups=null;
        List<String> camundaGroups=null;
        try {
            userAccesSSAMGroups = ldapService.findSSAMGroupsByUserNameAndContainerName(userID, ssamInfo);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if ( null == userAccesSSAMGroups || userAccesSSAMGroups.isEmpty()){
            throw new IllegalStateException(MessageFormat.format("The USER {0}, Login failed because the User : {0} does not have the required container access. Check this SSAM for access-> https://ssam.prod.atl-paas.net/access/containers/{1}/",userID,ssamInfo.getAccessContainer()));
        }
        // when user might be part of the configured container but not part of the approved DL's
        camundaGroups = getCamundaGroupNameFromSSAMGroups(userAccesSSAMGroups,ssamInfo);
        if (camundaGroups.isEmpty()){
            throw new IllegalStateException(MessageFormat.format("The USER {0}, Login failed because the User : {0} does not have the required container access. Check this SSAM for access-> https://ssam.prod.atl-paas.net/access/containers/{1}/",userID,ssamInfo.getAccessContainer()));
        }

        return camundaGroups;
    }

    private boolean checkAuthDetailsFromSession(HttpServletRequest request, String userID) {

        //this filter is being called everytime for the clicks in UI.
        Authentications authentications = Authentications.getFromSession(request.getSession());
        if(!authentications.getAuthentications().isEmpty()){
            for (Authentication auth: authentications.getAuthentications()) {
                if (userID.equals(auth.getIdentityId())){
                    LOGGER.info(MessageFormat.format("The USER {0} is already authenticated already. Reading the Auth details from HTTPSession",userID));
                    return true;
                }
            }
        }else{
            LOGGER.info(MessageFormat.format("The USER {0} is not authenticated already. going through the authentication process.",userID));
        }
        return false;
    }


    @Override
    public void augmentResponseByAuthenticationChallenge(HttpServletResponse httpServletResponse, ProcessEngine processEngine) {

    }

    private List<String> getCamundaGroupNameFromSSAMGroups(Set<String> userSSAMContainers, CamundaSSAMRoleInfo ssamInfo){

        List<String> containerList = new ArrayList<String>();
        for (String userContainer: userSSAMContainers) {

                String temp = ssamInfo.getAccessContainer()+ TEXT_SSAM_DL;
                if (userContainer.contains(temp)){
                    containerList.add(userContainer.substring(temp.length(), userContainer.length()));
                }else{
                    containerList.add(userContainer);
                }
        }

        return containerList;
    }
    private void processNewUser(String userID, String userFN, String userLN, String userEmail, List<String> containerList) {
        camundaService.createUser(userID,userFN,userLN,userEmail);
        for (String dlName: containerList) {
            camundaService.addUserToGroup(userID,dlName);
        }
    }
    private void processExistingUser( String userID, List<String> camuGrpAvailForUserFromSSAM, List<String> camuGrpNotAvailForUserFromSSAM){

        LOGGER.info("Access DL's for the USER "+userID+" from SSAM : "+camuGrpAvailForUserFromSSAM);
        List<String > userGroupsFromCamunda = camundaService.getAllGroupsForUser(userID);

        addUserToCamundaGroup(userID, camuGrpAvailForUserFromSSAM, userGroupsFromCamunda);
        removeUserToCamundaGroup(userID, camuGrpNotAvailForUserFromSSAM, userGroupsFromCamunda);
    }

    private void removeUserToCamundaGroup(String userID, List<String> camuGrpNotAvailForUserFromSSAM, List<String> userGroupsFromCamunda) {
        for (String grpName: camuGrpNotAvailForUserFromSSAM) {

            if (userGroupsFromCamunda.contains(grpName)){
                LOGGER.info(MessageFormat.format("User {0} is part of the UserGroup : {1}, but not part of the corresponding SSAM. Going to remove the user.", userID,grpName ));
                camundaService.removeUserFromGroup(userID, grpName);
            }else{
                LOGGER.fine(MessageFormat.format("User {0} is already not part of the UserGroup : {1}.", userID,grpName ));
            }
        }
    }

    // this method will add user to camunda groups which the user is not already part off.
    private void addUserToCamundaGroup(String userID, List<String> camuGrpAvailForUserFromSSAM, List<String> userGroupsFromCamunda) {
        for (String grpName: camuGrpAvailForUserFromSSAM) {
            if (!userGroupsFromCamunda.contains(grpName)){
                LOGGER.info(MessageFormat.format("User {0} is not part of the UserGroup : {1}. Going to add the user.", userID,grpName ));
                camundaService.addUserToGroup(userID, grpName);
            }else{
                LOGGER.fine(MessageFormat.format("User {0} is already part of the UserGroup : {1}.", userID,grpName ));
            }
        }
    }
    
  //slauth does not work in non-micros, so for developer pc read from jvm arguments
    private String getUserId(String userID) {
    	String username = env.getProperty("slauth_local_username");
    	LOGGER.info(MessageFormat.format("slauth_local_username username {0}", username ));
        if(userID==null && username!=null) {
        	userID=username;
        	LOGGER.info(MessageFormat.format("slauth_local_username User {0}", userID ));
        }
        return userID;
    }

}
