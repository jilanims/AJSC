package com.atlassian.camunda.license;

import java.util.Date;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.camunda.bpm.engine.ManagementService;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.licensecheck.LicenseKey;
import org.camunda.bpm.licensecheck.LicenseKeyImpl;
//import org.camunda.bpm.licensecheck.LicenseKey;
//import org.camunda.bpm.licensecheck.LicenseKeyImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.STSAssumeRoleSessionCredentialsProvider;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.securitytoken.AWSSecurityTokenService;
import com.amazonaws.services.securitytoken.AWSSecurityTokenServiceClientBuilder;

public class LicenseFileCLR implements CommandLineRunner {

    private final static Logger LOGGER = Logger.getLogger(LicenseFileCLR.class.getName());

    @Autowired
    ProcessEngine processEngine;

    @Value("${camunda.s3.license.check.disabled:false}")
    String disableLicenseCheck;
    @Value("${camunda.s3.license.bucketname:atl-camunda-license}")
    String bucketName;
    @Value("${camunda.s3.license.filename:license.txt}")
    String fileName;
    @Value("${camunda.s3.license.roleARN:arn:aws:iam::644971318052:role/camunda-license}")
    String licenseRoleArn;
    @Value("${camunda.s3.region:us-east-1}")
    String s3Region;

    @Override
    public void run(String... args) throws Exception {

        // if the license check has been explicitly disabled - exit
        if (Boolean.parseBoolean(disableLicenseCheck)) {
            LOGGER.info("Skipped fetching license key as camunda.s3.license.check.disabled = true");
            return;
        }

        //code copied from org.camunda.bpm.engine.impl.cmd.SetLicenseKeyCmd & org.camunda.bpm.engine.impl.cmd.GetLicenseKeyCmd
        ManagementService managementService = processEngine.getManagementService();
        String licenseKey = null;

        Boolean isExpiredKey = Boolean.FALSE;

        try{
            licenseKey = managementService.getLicenseKey();
            LicenseKey license = new LicenseKeyImpl(licenseKey);
            isExpiredKey = license.getValidUntil().before(new Date());
        }catch(Exception e){
            LOGGER.warning("No License Key found in DB");
        }

        if (licenseKey == null || isExpiredKey ){
            String licenseKeyString = getContentFromS3();

            if (null != licenseKeyString){
                LicenseKey lkey = new LicenseKeyImpl(licenseKeyString);
                lkey.validate();
                managementService.setLicenseKey(lkey.getLicenseString());
                LOGGER.info("License Key has been fetched from S3 and updated to Camunda.");
            }else
                LOGGER.info("Unable to fetch the licese key from S3.");
        }else
            LOGGER.info("License Key is the latest. No need to do update check.");
    }

    private String getContentFromS3(){

        AmazonS3 s3Client = null;

        try {

            AWSSecurityTokenService stsClient = AWSSecurityTokenServiceClientBuilder.defaultClient();
            String roleSessionName = "camunda-"+ UUID.randomUUID().toString();
            STSAssumeRoleSessionCredentialsProvider.Builder stsBuilder = new STSAssumeRoleSessionCredentialsProvider.Builder(licenseRoleArn,roleSessionName);
            STSAssumeRoleSessionCredentialsProvider stsProvider = stsBuilder
                    .withRoleSessionDurationSeconds(1200)
                    .withStsClient(stsClient)
                    .build();
            stsProvider.refresh();
            ClientConfiguration cc = new ClientConfiguration();
            s3Client = AmazonS3ClientBuilder
                    .standard()
                    .withCredentials(stsProvider)
                    .withRegion(Regions.fromName(s3Region))
                    .withClientConfiguration(cc)
                    .build();

            return s3Client.getObjectAsString(bucketName, fileName);

        } catch (Exception e) {
            LOGGER.log(Level.SEVERE,e.getMessage());
        }
        return null;
    }
}
