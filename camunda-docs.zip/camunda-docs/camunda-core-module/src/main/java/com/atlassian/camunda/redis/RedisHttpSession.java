package com.atlassian.camunda.redis;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisClientConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.session.data.redis.config.ConfigureRedisAction;
import org.springframework.session.data.redis.config.annotation.web.http.EnableRedisHttpSession;
import org.springframework.session.web.context.AbstractHttpSessionApplicationInitializer;


@Configuration
//maxInactiveIntervalInSeconds is the expiration time of SpringSession (unit: seconds) 
@EnableRedisHttpSession ( maxInactiveIntervalInSeconds =  1800 )
public class RedisHttpSession extends AbstractHttpSessionApplicationInitializer {

    @Value("${spring.application.name:local}")
    private String clientName;
    @Value("${REDIS3_RCACHE_PRIMARYENDPOINTADDRESS:localhost}")
    private String redisHost;
    @Value("${REDIS3_RCACHE_PRIMARYENDPOINTPORT:6379}")
    private Integer redisPort;

    @SuppressWarnings("rawtypes")
    @Bean
    public JedisConnectionFactory connectionFactory() {

        RedisStandaloneConfiguration redisStandaloneConfiguration = new RedisStandaloneConfiguration(redisHost,redisPort);
		JedisClientConfiguration.JedisPoolingClientConfigurationBuilder configurationBuilder = (JedisClientConfiguration.JedisPoolingClientConfigurationBuilder) JedisClientConfiguration
				.builder();
		GenericObjectPoolConfig genericObjectPoolConfig = new GenericObjectPoolConfig();
        configurationBuilder.poolConfig(genericObjectPoolConfig);

        JedisConnectionFactory connectionFactory = new JedisConnectionFactory(redisStandaloneConfiguration,configurationBuilder.build());
        return connectionFactory;
    }

    @Bean
    public static ConfigureRedisAction configureRedisAction() {
        return ConfigureRedisAction.NO_OP;
    }
}
//Spring Boot 2.x Redis multi data source configuration (jedis, lettuce)
//https://www.programmersought.com/article/7091749080/
	