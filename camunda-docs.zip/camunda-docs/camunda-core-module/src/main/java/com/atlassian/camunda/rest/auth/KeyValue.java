
package com.atlassian.camunda.rest.auth;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "secretKey",
        "secretValue"
})
public class KeyValue {

    @JsonProperty("secretKey")
    private String secretKey;
    @JsonProperty("secretValue")
    private String secretValue;

    @JsonProperty("secretKey")
    public String getSecretKey() {
        return secretKey;
    }

    @JsonProperty("secretKey")
    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }

    @JsonProperty("secretValue")
    public String getSecretValue() {
        return secretValue;
    }

    @JsonProperty("secretValue")
    public void setSecretValue(String secretValue) {
        this.secretValue = secretValue;
    }


}
