package com.atlassian.camunda.slauth.ssam;

public class CamundaSSAMRoleInfo {

    private String accessContainer;
    private String microsAdminGroup;

    public String getAccessContainer() {
        return accessContainer;
    }

    public void setAccessContainer(String accessContainer) {
        this.accessContainer = accessContainer;
    }

    public String getMicrosAdminGroup() {
        return microsAdminGroup;
    }

    public void setMicrosAdminGroup(String microsAdminGroup) {
        this.microsAdminGroup = microsAdminGroup;
    }


}
