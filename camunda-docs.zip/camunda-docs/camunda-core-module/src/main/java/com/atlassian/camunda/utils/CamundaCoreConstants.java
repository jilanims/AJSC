package com.atlassian.camunda.utils;

public class CamundaCoreConstants {
	static final public String CAMUNDA_ADMIN = "camunda-admin";
	static final public String SYSTEM = "SYSTEM";
	static final public String  ASTERISK = "*";
}
