#https://hello.atlassian.net/wiki/spaces/CAM/pages/746411490/How-To+Integrate+Camunda+as+dependency+to+Spring+Boot+App

This page will walk you through the steps of Integrating camunda to your spring boot service and build and run in local and also deploy to Micros environment
	Overview:
		Camunda-core-module has below integrations by default:
		Camunda BPM (Enterprise Edition)
		SAML/SLauth/Centrify Login
		Default H2 DB
		Redis for ServerSide Session Management
		SSAM Container for Camunda User Group Authorization Mapping


Steps: 
1. Go to http://go/instant-micros, create a Spring Boot based application. Select the relevant options which are required for your project including (but not limited to) bamboo option. Once the application is created in the stash repository of your choice, clone the repo to your laptop, create your branch, import the project into your favorite Java IDE. 

2. Please add 'camunda-core-module' dependency to pom.xml and @EnableAutoConfiguration to Application.java
		a. Please add below dependency to your pom.xml
			<dependency>
			     <groupId>com.atlassian.camunda</groupId> 		 
			     <artifactId>camunda-core-module</artifactId>
			     <version>0.0.1</version>
			</dependency>
		
		
		b. Please add below @EnableAutoConfiguration to your Application.java
		@EnableAutoConfiguration(exclude={AsapSpringMvcAutoConfiguration.class}) 


3. application.yml changes:

	camunda.ssam.role:*for configuring the SSAM container associated with this service, which will be used for role mapping.
	ldap:* for making LDAP calls to get the access levels in which the User is part.
	camunda.bpm.authorization: for enabling role-based authorizations or else anybody who is authentication will have full access.
	
	 application.yml:
		ldap:
		## provide LDAP_USERNAME, LDAP_PWD , this should be bot username and password
		  providerUrl: ${LDAP_PROVIDER_URL:ldaps://us-ad-cluster.office.atlassian.com}
		  username: ${LDAP_USERNAME}
		  pwd: ${LDAP_PWD}
		
		camunda.ssam.roles:
		  accessContainer: micros-sv--<replace-with-your-service-name>
		  microsAdminGroup: micros-sv--replace-with-your-service-name>-dl-admins
		camunda.bpm:
		  authorization:
		    enabled: true
		  filter:
		    create: All tasks
		
		#we have to let spring boot know that, the session store type is going to be Redis
		spring:
		    session:
		      store-type: redis
		      timeout: 600

4. Micros supporting Changes:

	Please create a bot user account by raising a request here, the bot should be able to access Atlassian’s LDAP, the username and password of this need to be set as Stash variables LDAP_USERNAME, LDAP_PWD.
	We need to set the following Key and Values in Micros Stash for each deployment environment. 
	LDAP_USERNAME  
	LDAP_PWD
	REST_CREDENTIALS
	
	Below is a sample stash command to store the values to Micros Stash, change the values according to your project needs.
	  	atlas micros stash:set -s camundaserver -e ddev LDAP_USERNAME Your_LDAP_username
		atlas micros stash:set -s camundaserver -e ddev LDAP_PWD your_LDAP_password
		atlas micros stash:set -s camundaserver -e ddev REST_CREDENTIALS "[
		  {
		    \"secretKey\": \"<your-secret-key>\",
		    \"secretValue\": \"<your-secret-value>\"
		  },
		  {
		    \"secretKey": "<your-secret-key>\",
		    \"secretValue": "<your-secret-value>\"
		  },
		  {
		    \"secretKey\": \"<your-secret-key>\",
		    \"secretValue\": \"<your-secret-value>\"
		  }
		]"

5. *.sd.yml changes

	In the *.sd.yml file, We will add the below code snippet (or overriding the existing compose), feel free to change the values which are in sync to your project. 
	The way it works, any incoming requests will be front-ended by the slauth-sidecar ( internally the declared plugins will come into play) and on successful authentication, the request will be handed over to the declared URL address on the property SLAUTH_BACKEND.
	Make sure you enter the correct value at the URL attribute ( don't do cross-environment you might get acl related error), as the request after SSO will be redirected here.
	Note: Centrify is a resource type provisioned by Micros. For more details, you can check here Centrify (Resource Type)  
	Declare your project-specific redis3 resource type in the *.sd.yml file, so that micros will provision this resource (below sample snippet). After provisioning this resource, micros provides the resource-specific environmental variables to be used by the app, for more details related redis3 resource refer to this page → Redis3 (Resource Type) 
	please refer to https://hello.atlassian.net/wiki/spaces/MICROS/pages/169249734/Centrify+Resource+Type for more info.
	
	*.sd.yml:
		compose:
		  slauth:
		    image: docker.atl-paas.net/sox/micros/slauth-sidecar
		    tag: stable
		    ports:
		      - 8080:8080
		    links:
		      - camunda
		  camunda:
		    image: docker.atl-paas.net/@docker.namespace@/@project.artifactId@
		    tag:  "@git.commit.id@@docker.tag.suffix@"
		
		
		config:
		  environmentVariables:
		    SLAUTH_LISTEN: ":8080"
		    SLAUTH_BACKEND: "http://camunda:8080"
		    SLAUTH_PLUGINS: "bypass,saml"
		    SLAUTH_LOG_LEVEL: "info"
		    SLAUTH_BYPASS_ROUTES: "/heartbeat,/rest/*"
		    SLAUTH_SAML_CENTRIFY: "centrify"
		    SLAUTH_SAML_TIMEOUT: "8h"
		    # See the per environment section below as well to specify memory options for each env based on instance size overrides
		    MEMORY_OPTS: "-Xmx1024M" # 25% of system memory for a t3.small (set above)
		resources:
		  - type: redis3
		    name: rcache
		    attributes:
		      size: 1024
		      replicas: 1
		      failover: true
		
		environmentOverrides:
		  staging:
		    resources:
		      - type: centrify
		        name: centrify
		        attributes:
		          name: <your-micros-serivce-name>.ddev
		          description: <your-micros-serivce-name> ddev environment
		          ##make sure you give the corrent service's correct environment url or else you will get error after successful SAML Authenticatoin
		          url: "https://<your-micros-serivce-name>.us-east-1.staging.atl-paas.net"
		          generateCert: true

6. Add camunda-admin as access level to SSAM
	To access Camunda’s cockpit/tasklist/admin pages users need to have access to Camunda User Group authentication. So at-least one administrator should be added to ‘camunda-admin’ group as a member

	For example: 
	
	In SSAM https://ssam.prod.atl-paas.net/access/containers/micros-sv--<your-project-name>/, kindly please add ‘camunda-admin’ access level for the first time and assign the members based on the permissions. (Login SSAM → Edit → add access level → 
	
	(Name: Camunda Admin, short-name: camunda-admin, members: add your Atlassian userid)

	Once application is deployed to micros, navigate to https://<your-micros-env-hostname>/ to see if your service is up. 

7. Developer(Local) PC Testing: 

	compile: mvn clean install
	
	Run APP: Right click on Application.java and run as spring boot app and add below JVM arguments
	
	-Dasap.audience=camunda-core-moduleexample
	-DLDAP_USERNAME=jpatan
	-DLDAP_PWD=SandySpring@12
	-DREST_CREDENTIALS=[{"secretKey":"<replace with secret-key>","secretValue":"<replace with secret-password>"}]
	-DX-Local-username=<your Atlassian userid>
	
	Test:
	
	REST API: GET Method: https://localhost:8080/rest/process-definition/
	
	Camunda Welcome Page: http://localhost:8080/