package io.atlassian.camunda.plugin;

import org.camunda.optimize.plugin.security.authentication.AuthenticationExtractor;
import org.camunda.optimize.plugin.security.authentication.AuthenticationResult;

import javax.servlet.http.HttpServletRequest;
import java.util.logging.Logger;

public class SLAuthOptimizeAuthenticationProvider implements AuthenticationExtractor {

    private final static Logger LOGGER = Logger.getLogger(SLAuthOptimizeAuthenticationProvider.class.getName());


    @Override
    public AuthenticationResult extractAuthenticatedUser(HttpServletRequest request) {

        AuthenticationResult result = new AuthenticationResult();
        String user = request.getHeader("X-Slauth-Subject");
//        String user = "vpatnaik";

        if (user == null || user.isEmpty()) {
            LOGGER.info("Did not find user.");
            result.setAuthenticated(false);
            return result;
        } else {
            LOGGER.info("User logged info "+ user);
            result.setAuthenticatedUser(user);
            result.setAuthenticated(true);
            return result;
        }
    }
}
