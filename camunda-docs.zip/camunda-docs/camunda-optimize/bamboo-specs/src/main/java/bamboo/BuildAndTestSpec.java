package bamboo;

import com.atlassian.bamboo.specs.api.builders.notification.Notification;
import com.atlassian.bamboo.specs.api.builders.owner.PlanOwner;
import com.atlassian.bamboo.specs.api.builders.pbc.ContainerSize;
import com.atlassian.bamboo.specs.api.builders.pbc.ExtraContainer;
import com.atlassian.bamboo.specs.api.builders.pbc.ExtraContainerSize;
import com.atlassian.bamboo.specs.api.builders.pbc.PerBuildContainerForJob;
import com.atlassian.bamboo.specs.api.builders.permission.PermissionType;
import com.atlassian.bamboo.specs.api.builders.permission.Permissions;
import com.atlassian.bamboo.specs.api.builders.permission.PlanPermissions;
import com.atlassian.bamboo.specs.api.builders.plan.Job;
import com.atlassian.bamboo.specs.api.builders.plan.Plan;
import com.atlassian.bamboo.specs.api.builders.plan.PlanIdentifier;
import com.atlassian.bamboo.specs.api.builders.plan.Stage;
import com.atlassian.bamboo.specs.api.builders.plan.artifact.Artifact;
import com.atlassian.bamboo.specs.api.builders.plan.branches.BranchCleanup;
import com.atlassian.bamboo.specs.api.builders.plan.branches.PlanBranchManagement;
import com.atlassian.bamboo.specs.api.builders.task.Task;
import com.atlassian.bamboo.specs.builders.notification.CommittersRecipient;
import com.atlassian.bamboo.specs.builders.notification.JobFailedNotification;
import com.atlassian.bamboo.specs.builders.task.CheckoutItem;
import com.atlassian.bamboo.specs.builders.task.InjectVariablesTask;
import com.atlassian.bamboo.specs.builders.task.ScriptTask;
import com.atlassian.bamboo.specs.builders.task.TestParserTask;
import com.atlassian.bamboo.specs.builders.task.VcsCheckoutTask;
import com.atlassian.bamboo.specs.builders.trigger.RepositoryPollingTrigger;
import com.atlassian.bamboo.specs.model.task.InjectVariablesScope;
import com.atlassian.bamboo.specs.model.task.ScriptTaskProperties;
import com.atlassian.bamboo.specs.util.BambooServer;

import static bamboo.Constants.BUILD_AND_TEST_PLAN_KEY;
import static bamboo.Constants.BUILD_AND_TEST_PLAN_NAME;
import static bamboo.Constants.BUILD_OUTPUT_FOLDER;
import static bamboo.Constants.JUNIT_RESULTS_PATTERN;
import static bamboo.Constants.PLAN_OWNER;
import static bamboo.Constants.PROJECT;
import static bamboo.Constants.PROJECT_KEY;
import static bamboo.Constants.REPOSITORY;
import static bamboo.Constants.VARIABLES_PROPERTIES_FILE;
import static bamboo.PlanHelpers.isDeploymentBambooInstance;
import static com.atlassian.bamboo.specs.model.task.TestParserTaskProperties.TestType.JUNIT;

/**
 * Plan for running tests against the repository.
 *
 * <p>Note that this is shared across all bamboo instances, with some modifications for a deployment bamboo instance.
 */
public class BuildAndTestSpec {

    private static final PerBuildContainerForJob PER_BUILD_CONTAINER = new PerBuildContainerForJob()
            .image("docker.atl-paas.net/sox/buildeng/agent-baseagent")
            .size(ContainerSize.REGULAR)
            // This microservice relies on building a docker image so we need docker to be available.
            .extraContainers(new ExtraContainer()
                    .name("docker")
                    .image("docker:18.04-dind")
                    .size(ExtraContainerSize.SMALL)
            );

    private static Task checkoutCode() {
        return new VcsCheckoutTask()
                .description("Checkout Default Repository")
                .checkoutItems(new CheckoutItem().defaultRepository());
    }

    /**
     * Used to run all of the tests in bamboo.
     */
    private static Task runInBamboo() {
        return new ScriptTask()
                .description("Run tests: ./bin/run-in-bamboo.sh")
                .inlineBody("./bin/run-in-bamboo.sh");
    }
	
	/**
     * Used to run source clear task.
     */
    private static Task runSourceClear() {
        return new ScriptTask()
                .description("Source Clear Scan")
                .interpreter(ScriptTaskProperties.Interpreter.BINSH_OR_CMDEXE)
                .location(ScriptTaskProperties.Location.FILE)
                .fileFromPath("./bin/sourceclear.sh");
    }
    
    /**
     * Used to clean up after the tests in bamboo have run.
     */
    private static Task stopInBamboo() {
        return new ScriptTask()
                .description("Cleanup bamboo environment: ./bin/stop-in-bamboo.sh")
                .inlineBody("./bin/stop-in-bamboo.sh");
    }

    /**
     * This injects all of the variables from {@link Constants#VARIABLES_PROPERTIES_FILE} into a bamboo variable. This is used in our
     * deployment plan where we can reference the variables by doing <pre>{bamboo.inject.variable}</pre>.
     */
    private static Task injectBambooVariables() {
        return new InjectVariablesTask()
                .description("Inject version variable")
                .namespace("inject")
                .scope(InjectVariablesScope.RESULT)
                .path(VARIABLES_PROPERTIES_FILE);
    }

    private static Task junitParser() {
        return new TestParserTask(JUNIT)
                .description("JUnit Parser")
                .resultDirectories(JUNIT_RESULTS_PATTERN);
    }

    /**
     * The actual stage that completes the testing of the application.
     */
    private static Stage buildAndTestStage() {
        return new Stage("Build and Test")
                .jobs(new Job("Build and Test Job", "JOB1")
                        .pluginConfigurations(PER_BUILD_CONTAINER)
                        .artifacts(new Artifact()
                                .name("Service descriptor")
                                .location(BUILD_OUTPUT_FOLDER)
                                .copyPattern("*.sd.yml")
                                .shared(true)
                        )
                        .tasks(checkoutCode(), runInBamboo(), injectBambooVariables(), runSourceClear())
                        .finalTasks( stopInBamboo())
//                        .finalTasks(junitParser(), stopInBamboo()) TODO revert this back.
                );
    }

    private static Notification jobFailedNotifyCommitter() {
        return new Notification()
                .type(new JobFailedNotification())
                .recipients(new CommittersRecipient());
    }

    /**
     * Builds the plan for testing the application.
     *
     * <p>Note that in a deployment environment branch builds are not automatically generated and notifications are
     * altered.
     *
     * @param isDeploymentBamboo whether the bamboo environment is a deployment environment
     * @return the build and test plan for this bamboo instance
     */
    private static Plan buildAndTestPlan(final boolean isDeploymentBamboo) {
        final Plan plan = new Plan(PROJECT, BUILD_AND_TEST_PLAN_NAME, BUILD_AND_TEST_PLAN_KEY)
                .pluginConfigurations(
                        new PlanOwner(PLAN_OWNER)
                )
                .linkedRepositories(REPOSITORY)
                .triggers(new RepositoryPollingTrigger())
                .forceStopHungBuilds()
                .stages(buildAndTestStage())
                .notifications(jobFailedNotifyCommitter());
        if (!isDeploymentBamboo) {
            plan.planBranchManagement(new PlanBranchManagement()
                    .notificationLikeParentPlan()
                    .createForVcsBranch()
                    .delete(new BranchCleanup()
                            .whenInactiveInRepositoryAfterDays(10)
                            .whenRemovedFromRepositoryAfterDays(1)
                    )
                    .notificationForCommitters());
        }

        return plan;
    }

    private static PlanPermissions buildAndTestPlanPermissions() {
        return new PlanPermissions(new PlanIdentifier(PROJECT_KEY, BUILD_AND_TEST_PLAN_KEY))
                .permissions(new Permissions()
                        .loggedInUserPermissions(PermissionType.VIEW, PermissionType.BUILD)
                );
    }

    /**
     * Will publish this spec to the provided {@link BambooServer}.
     *
     * @param bambooServer the server to publish to
     */
    public void publishToBamboo(final BambooServer bambooServer) {
        final boolean isDeploymentBamboo = isDeploymentBambooInstance();

        bambooServer.publish(BuildAndTestSpec.buildAndTestPlan(isDeploymentBamboo));
        bambooServer.publish(BuildAndTestSpec.buildAndTestPlanPermissions());
    }
}
