package com.atlassian.bamboo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.atlassian.bamboo.specs.api.builders.task.Task;
import com.atlassian.bamboo.specs.builders.task.ScriptTask;



public final class SourceClear {
	
	private static Logger LOGGER = LoggerFactory.getLogger(SourceClear.class);

    //Method to run sourceclear scan
	@SuppressWarnings("rawtypes")
    public static Task runSourceClear() {
		LOGGER.info("******************************* RUN SOURCE CLEAR *******************************");
        return new ScriptTask()
                                    .description("Run SourceClear")
                                    .inlineBody("curl -sSL https://download.sourceclear.com/ci.sh | sh")
                                    .environmentVariables("SRCCLR_API_TOKEN=${bamboo.IPAAS_SRCCLR_API_TOKEN_PASSWORD}");
    }
}