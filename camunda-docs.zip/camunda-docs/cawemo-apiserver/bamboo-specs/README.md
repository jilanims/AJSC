Bamboo specs configuration for mulesoft. 

## Introduction

We use java specs to manage our Bamboo configuration.
https://hello.atlassian.net/wiki/spaces/MULE/pages/660057754/How+To+-+Migrate+from+existing+bamboo+templates+to+bamboo+java+specs+for+mule+applications

**You will need to do some manual setup.**

1) Configure the mule application 
2) Configure the bamboo java specs
3) Configure Bamboo 
4) Configure global config 


Use the below snippets to prep your app HTTPS Port: 

<http:listener-config name="HTTP_Listener_config" doc:name="HTTP Listener config"> <http:listener-connection port="${https.private.port}" host="0.0.0.0" protocol="HTTPS"> <tls:context > <tls:key-store type="jks" path="sample.jks" keyPassword="${secure::keystore.pass}" password="${secure::keystore.pass}" /> </tls:context> </http:listener-connection> </http:listener-config>

## Environment

**Secure Property File:** 

<secure-properties:config name="Secure_Properties_Config" doc:name="Secure Properties Config" file="settings-${env}.properties" key="${key}" >

**Secure Property Encryption Key:**

1) Create property files for each environment (ddev, adev, stage and prod).

2) Update mule-artifact.json, to secure the key on the CloudHub UI "secureProperties": ["key"].

3) Configure the pom.xml Either use the MuleSoft Parent POM or use the Atlassian Parent POM. 
Example snippet for MuleSoft Parent POM below: 

```
<groupId>com.atlassian.pom</groupId>
<artifactId>mulesoft4-parent-pom</artifactId>
<version>SELECT_YOUR_VERSION</version>
```


4) Add scm details with your repo information. 

Example snippet below:

```
<connection>scm:git:ssh://git@stash.atlassian.com:7997/MOE/hi-world-mule-4.git</connection>
<developerConnection>scm:git:ssh://git@stash.atlassian.com:7997/MOE/hi-world-mule-4.git</developerConnection> 
<url>https://stash.atlassian.com/projects/MOE/repos/hi-world-mule-4/</url>
<tag>HEAD</tag> 
```

If you are using the MuleSoft Parent POM, it already has the mule-maven-plugin configured. But if you are using the Atlassian Parent POM, you will need to configure the mule-maven-plugin in you app pom.xml. 

Example snippet for CloudHub config below:

```
<groupId>org.mule.tools.maven</groupId> 
<artifactId>mule-maven-plugin</artifactId>
<mule.maven.plugin.version>SELECT_YOUR_VERSION</mule.maven.plugin.version>
```

5) Configure the bamboo specs. Copy the bamboo-specs to the mulesoft project folder.

Update the args variable in BambooSpecVariables.java: 

- bambooPlanKey = Unique key for your new service. eg: 'HWIM3'
- serviceReadableName = Integration project name. eg: 'Hi World Integration Mule 3'
- bambooRepositoryName = Bamboo display name of the linked repository. eg: 'MOE Hi World Integration Mule 3' 
- bambooProjectKey = Bamboo project/team id, where the plan will be created. eg: 'IPAAS' 
- bambooProjectName = Bamboo project/team name in Bamboo, where the plan will be created. eg: 'iPaaS' 
- cloudHubAppName = Name of your app in mulesoft eg: 'atl-hiworld-mule3-app' 
- encryptkey = Bamboo global variable, which the plan will use to fetch encryption secret used for securing the property files. Four global variables are needed for each environment (ddev, adev, stage, prod). The bamboo template looks for bamboo..encryptkey Do not put your plain text password in here, instead configure bamboo global variables. Also make sure the key ends with either 'pass' or 'password' to secure the value. eg: 'ipaas.hiworld3.encrypt.key.password' will need 4 variables ddev.ipaas.hiworld3.encrypt.key.password, adev.ipaas.hiworld3.encrypt.key.password, stage.ipaas.hiworld3.encrypt.key.password and prod.ipaas.hiworld3.encrypt.key.password. 
- emailForNotifications = Email for notifications in case of deploy failures in PROD. eg: 'vvarma@atlassian.com' 
- planOwner = User id of the person responsible for plan. eg: 'vvarma' 
- groupNameForPermission = Team's AD group for access to the plan & deployment. eg: 'ipaas-dl-all' 
- cloudHubBusinessGroup = Business group where the application will be deployed. eg: 'iPaaS' 
- enableAdvancedMonitoring = Use this argument to enable advanced monitoring for mule application. eg:'true' 
- persistentQueue = Used to enable persistent queue for mule API. eg: 'true' for enable and 'false' for disable. 
- objectStoreV2 = Used to enable object store v2. eg:'false' 
- cloudhubLogsDisabled = Used to disable cloudhub logs for mule application. eg: disable for 'true' and enable for 'false'.
- automateAPIInstance = Used to enable api automation. Eg.true
- enableReleaseNotes = Used to enable release notes creation. Eg. True
- cloudHubEnvName = The business group environment where the applciation will be dpeloyed. eg: 'DDEV' 
- workerSize - The vCore size used for the application, possible values can be found here under workerType. eg: 'Micro' 
- workerCount - The number of workers/instaces for the application. eg: 1 
- awsRegion - Refers to the was region eg. Us-east-1
- microsAppUrl - Refers to the micros app url for logging

6) Configure MicroScope Entry For the changes related to microscope entry for a mule service, make the following changes in sd.yml available at the root folder of the mulesoft application. If not available already, create one. A sample reference file is available here.

Below is the file/field defination which could be used to send it across to service central api. **Note:** Service Dependencies (eg. Mulesoft) needs to be set manually as the service central api is not exposing this field for an api call.

- name: ${Mulesoft_ApplicationName} ## Name of the mulesoft application (optional). Type: String 
- description: ${Mulesoft_Application_Description} ## Description about the service entry. Type: String 
- admins: ## List of admins for the service entry. Type: List
- service_owner: ${service_owner} ## Service Owner for this service entry. Type: String 
- service_tier: ${service_tier} ## Service Tier of the service. Type: Integer 
- stateless: ${stateless} ## Is it a stateless service. Type: Boolean 
- platform: ${platform} ## The platform on which the service is deployed, eg Mulesoft. Type: String 
- ssam_container_name: ${ssam_container_name} ## The SSAM container name associated to the business group. Type: String 
- team: ${team} ## Team name to availble in the service entry. Type: String 
- business_unit: ${business_unit} ## Business unit name of the service entry. Type: String - hipchat_room_name: ${hipchat_room_name} ## Hipchat/stride room http url link. Type: String 
- availability_objective: ${availability_objective} ## Availability Objective of the service. Type: Integer 
- public_facing: ${public_facing} ## Whether the service is public facing, boolean value. Type: Boolean 
- zero_downtime_upgrades: ${zero_downtime_upgrades} ## Whether the service is having a zero downtime upgrades during deployment. Type: Boolean 
- location: ${location} ## Location of the service/team. Type: String 
- pagerduty_service_id: ${pagerduty_service_id} ## Pager Duty Service ID created for this service. Type: String 
- tags: ## The list of tags for this service entry in microscope. Type: List
${tag_1}
${tag_2} 

7) Configure Bamboo global variables Instances other than deployment-bamboo, the users can configure the global variables. 

For deployment-bamboo, raise a ticket with the variable names and share the values via LastPass secure note. eg: BUILDENG-14614 The variables needed: ddev.encryptkey adev.encryptkey stage.encryptkey prod.encryptkey 

8) Microscope configuration
The project template comes with a sd.yml file at the project root level, this file is used to create an entry in the Microscope. 

9) AWS Resource Provisioning
 In order to provision AWS resources through bamboo pipeline, set enableTerraform = true in bamboo template and follow the steps in 
 https://hello.atlassian.net/wiki/spaces/MULE/pages/443144597/How-To+Automate+AWS+resources+using+Terraform

10) Release Notes Update In Confluence

	*Release Notes gets Created/Updated in confluence based on if it's already existing or not under below link using release notes script:
	 https://hello.atlassian.net/wiki/spaces/MULE/pages/645858687/Template-Atlassian-Starter

11) ApiManagerAutomation

	* Set automateAPIInstamce = true in BambooSpecVariables.java. To automate API manager entries check out https://hello.atlassian.net/wiki/spaces/MULE/pages/605843705/How+to+Automate+API+Manager+Entries

12) SourceClear

	To know more  on source clear check out https://hello.atlassian.net/wiki/spaces/SECURITY/pages/157984514/SourceClear 

13) Autoscaling:

	* Set enableAutoScaling = true to enable autoscaling and set to false to disable.
	* Set enableAutoScalingAlerts = true to enable autoscaling alerts and set to false to disable.

	Check out on below page to know more. https://hello.atlassian.net/wiki/spaces/MULE/pages/608198596/Autoscaling+and+Alerting+in+cloudhub

## Need Help? 

Use @distrubed in #help-ipaas slack channel or Raise a request at go/mulehelp Check out the MuleSoft space go/mulesoft