package com.att.api.framework.ajsc.camunda.utils;

public class CamundaConstants {
	// public static final String[] APPS = new String[] { "cockpit", "tasklist",
	// "admin" };
	public static final String[] APPS = new String[] { "cockpit", "tasklist", "admin", "welcome" };
	public static final String DEFAULT_APP_WELCOME = "welcome";
	public static final String APP_MARK = "/app/";
	public static final String APP_CAMUNDA = "/CAMUNDA";
	public static final String AAF_PERM_SPLIT = "\\|";
	public static final String COMMA_SPLIT = ",";
	public static final String SLASH_SPLIT = "/";
	public static final String CAMUNDA_GROUP_RESOURCE_TYPE = "AJSCCamundaGroup7";
	public static final String APP_EMPTY = "";
	public static final String APP_CSP_ATT_COM = "@csp.att.com";
	public static final String ANY = "*";
	public static final String AAF_PERMISSION_FORMAT = "%s|%s|%s";
	public static final String PERMISSION_ALL = "ALL";
	public static final String PERMISSION_NONE = "NONE";

	public static final String AUTHENTICATION_FILTER = "Authentication Filter";

	// AJSC-Camunda-AAF.Yaml file loading properties
	public static final String YAML_FILE_NOT_FOUND = "AJSCCAMU0000";
	public static final String YAML_FILE_READ_ERROR = "AJSCCAMU0000 Error reading yaml file ";
	public static final String YAML_RESOURCES_ERROR = "AJSCCAMU0001 Error reading resourceName: ";
	public static final String YAML_PERMISSIONS_ERROR = "AJSCCAMU0002 Error reading permission: ";
	public static final String YAML_PERMISSIONS_NULL = "AJSCCAMU0003 Error reading permission is Empty for ";
	public static final String YAML_RECOURCES_NULL = "AJSCCAMU0004 Error reading resourceName is Empty for ";
	public static final String CAMUNDA_CREATE_ADMIN_DEFAULT_ACCESS_FAILED = "AJSCCAMU0011";
	public static final String CAMUNDA_CREATE_GROUP_FAILED = "AJSCCAMU0012";
	public static final String YAML_GROUP_ASSOCIATION_INVALID = "AJSCCAMU0013 Error reading yaml file for GroupAssociation";
	
	public static final String YAML_CAMUNDA_GROUP_DEFINITION_EMPTY = "CAMUNDA GROUP DEFINITION IS EMPTY IN AJSC-AAF-CAMUNDA.YAML FILE";
	public static final String YAML_CAMUNDA_GLOBAL_AUTHORIZATION_EMPTY = "CAMUNDA GLOBAL AUTHORIZATION IS EMPTY IN AJSC-AAF-CAMUNDA.YAML FILE";
	
	// Camundai AAF Cadi Filter
	public static final String AAF_PRINCIPAL_NULL = "AJSCCAMU0005";
	public static final String AAF_PRINCIPAL_USER_ID_EMPTY = "AJSCCAMU0006";
	public static final String AAF_IDENTITY_IS_EMPTY = "AJSCCAMU0007";
	public static final String AAF_PERMISSION_IS_EMPTY = "AJSCCAMU0008";
	public static final String CREATE_CAMUNDA_GROUP_IS_EMPTY = "AJSCCAMU0009";
	public static final String CAMUNDA_APP_INVALID_AAF_PERMISSION = "AJSCCAMU0010";
	
}
