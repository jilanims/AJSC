package com.att.api.framework.ajsc.camunda.yaml.beans;

import java.util.List;

import org.camunda.bpm.engine.authorization.Permission;
import org.camunda.bpm.engine.authorization.Resource;
import org.camunda.bpm.engine.authorization.Resources;
import com.att.api.framework.ajsc.camunda.utils.AttCamundaAuthorizationUtil;
import com.att.api.framework.ajsc.camunda.utils.CamundaConstants;

public class CamundaResourcePermission {

	private Resource resource;
	private List<Permission> permissionList;
	private String resourceId; // default to ANY = *
	private String resourceName;
	private String permissions; // default ALL

	public String getResourceId() {
		return AttCamundaAuthorizationUtil.getDefaultValue(resourceId);
	}

	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}

	public String getResourceName() {
		return resourceName;
	}

	public void setResourceName(String resourceName) throws Exception {
		this.resourceName = resourceName;
		Resource resource = AttCamundaAuthorizationUtil.getResources(resourceName);
		this.resource = resource;
	}

	public String getPermissions() {
		return permissions;
	}

	public void setPermissions(String permissions) throws Exception {
		this.permissions = permissions;
		this.permissionList = AttCamundaAuthorizationUtil.getPermissions(permissions);
	}

	public Resource getResource() {
		return resource;
	}

	public void setResource(Resource resource) {
		this.resource = resource;
	}

	public List<Permission> getPermissionList() {
		return permissionList;
	}

	public void setPermissionList(List<Permission> permissionList) {
		this.permissionList = permissionList;
	}
}
