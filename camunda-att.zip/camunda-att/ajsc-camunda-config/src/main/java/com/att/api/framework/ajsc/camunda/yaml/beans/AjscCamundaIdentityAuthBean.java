package com.att.api.framework.ajsc.camunda.yaml.beans;

import java.util.ArrayList;
import java.util.List;

/*import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;*/

//@Configuration
//@EnableConfigurationProperties
//@PropertySource("file:opt/att/ajsc/config/ajsc-aaf-camunda.yaml")
//@ConfigurationProperties
public class AjscCamundaIdentityAuthBean {

	private DefaultConfig defaults;
	private List<AuthorizationGrant> authorizationGrant = new ArrayList<AuthorizationGrant>();
	private List<GroupDefinition> groupDefinitions = new ArrayList<GroupDefinition>();
	private List<GroupAssociation> groupAssociation = new ArrayList<GroupAssociation>();
	private AuthorizationGlobal authorizationGlobal;

	public List<AuthorizationGrant> getAuthorizationGrant() {
		return authorizationGrant;
	}

	public void setAuthorizationGrant(List<AuthorizationGrant> authorizationGrant) {
		this.authorizationGrant = authorizationGrant;
	}

	public List<GroupAssociation> getGroupAssociation() {
		return groupAssociation;
	}

	public void setGroupAssociation(List<GroupAssociation> groupAssociation) {
		this.groupAssociation = groupAssociation;
	}

	public AuthorizationGlobal getAuthorizationGlobal() {
		return authorizationGlobal;
	}

	public void setAuthorizationGlobal(AuthorizationGlobal authorizationGlobal) {
		this.authorizationGlobal = authorizationGlobal;
	}

	public DefaultConfig getDefaults() {
		return defaults;
	}

	public void setDefaults(DefaultConfig defaults) {
		this.defaults = defaults;
	}

	public List<GroupDefinition> getGroupDefinitions() {
		return groupDefinitions;
	}

	public void setGroupDefinitions(List<GroupDefinition> groupDefinitions) {
		this.groupDefinitions = groupDefinitions;
	}
}
