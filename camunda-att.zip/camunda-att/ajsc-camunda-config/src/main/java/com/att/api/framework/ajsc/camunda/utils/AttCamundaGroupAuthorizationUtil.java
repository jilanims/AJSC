package com.att.api.framework.ajsc.camunda.utils;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import static java.util.Objects.requireNonNull;
import org.camunda.bpm.engine.AuthorizationService;
import org.camunda.bpm.engine.IdentityService;
import org.camunda.bpm.engine.authorization.Authorization;
import org.camunda.bpm.engine.authorization.Permission;
import org.camunda.bpm.engine.authorization.Resource;
import org.camunda.bpm.engine.identity.Group;
import org.camunda.bpm.engine.impl.persistence.entity.AuthorizationEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import com.att.api.framework.ajsc.camunda.yaml.beans.CamundaResourcePermission;

/**
 * @author jp931e
 *
 */
public class AttCamundaGroupAuthorizationUtil {
	private static final Logger logger = LoggerFactory.getLogger(AttCamundaGroupAuthorizationUtil.class);

	public static Group createGroup(final IdentityService identityService, final Group group) {
		Group newGroup = identityService.newGroup(group.getId());
		BeanUtils.copyProperties(group, newGroup);
		identityService.saveGroup(newGroup);
		return newGroup;
	}

	public static boolean groupAlreadyExists(IdentityService identityService, Group group) {
		final Group existingGroup = identityService.createGroupQuery().groupId(group.getId()).singleResult();
		if (existingGroup != null) {
			logger.info("011", "skip creating initital Group, group does exist: {}", existingGroup);
			return true;
		}
		return false;
	}

	/*
	 * Create Group Authorization
	 */
	public static void createGroupAuthorization(List<CamundaResourcePermission> camResPermList,
			AuthorizationService authorizationService, String groupId, Integer authorizationType) throws Exception {
		Map<Integer, Resource> deleteResourcesMap = AttCamundaAuthorizationUtil.getResourcesMap();

		if (camResPermList != null && camResPermList.size() > 0) {

			for (CamundaResourcePermission camResPerm : camResPermList) {

				requireNonNull(camResPerm);

				// Already existed resource will be removed from default
				// resourcesMap
				Resource resource = camResPerm.getResource();
				deleteResourcesMap.remove(resource.resourceType());

				createGroupAuthorationPerms(authorizationService, groupId, resource, camResPerm.getPermissionList(),
						camResPerm.getResourceId(), authorizationType);
			}
		}

		// Delete revoked Resources
		if (deleteResourcesMap.size() > 0) {
			deleteGroupResources(authorizationService, deleteResourcesMap, groupId, authorizationType);
		}
	}

	// Delete previous resources like
	// USER/GROUP/GROUP_MEMBERSHIP/etc...
	public static void deleteGroupResources(AuthorizationService authorizationService,
			Map<Integer, Resource> deleteResourcesMap, String groupId, Integer authorizationType) {

		for (Entry<Integer, Resource> entry : deleteResourcesMap.entrySet()) {
			List<Authorization> authorizationList = authorizationService.createAuthorizationQuery().groupIdIn(groupId)
					.resourceType(entry.getValue()).authorizationType(authorizationType).list();
			if (authorizationList.size() > 0) {
				Iterator<Authorization> it = authorizationList.iterator();
				while (it.hasNext()) {
					Authorization auth = it.next();
					logger.info("Deleted Authoriation Resource {}", entry.getValue());
					authorizationService.deleteAuthorization(auth.getId());
				}
			}
		}

	}

	private static void createGroupAuthorationPerms(AuthorizationService authorizationService, String groupId,
			Resource resource, List<Permission> permsList, String resourceId, Integer authorizationType)
			throws Exception {

		Authorization au = authorizationService.createAuthorizationQuery().groupIdIn(groupId).resourceType(resource)
				.resourceId(resourceId).authorizationType(authorizationType).singleResult();

		if (au != null) {
			// check for revoked permissions and delete/adjust then save
			// finally.
			AttCamundaAuthorizationUtil.deletePermission(authorizationService, au, permsList);
		} else {
			createGroupAuthorization(authorizationService, groupId, resource, resourceId, permsList, authorizationType);
		}
	}

	private static void createGroupAuthorization(AuthorizationService authorizationService, String groupId,
			Resource resource, String resourceId, List<Permission> permsList, Integer authorizationType)
			throws Exception {
		AuthorizationEntity groupAuth = new AuthorizationEntity(authorizationType);
		groupAuth.setGroupId(groupId);
		groupAuth.setResource(resource);
		groupAuth.setResourceId(resourceId);
		for (Permission currPerm : permsList) {
			groupAuth.addPermission(currPerm);
		}
		authorizationService.saveAuthorization(groupAuth);
		logger.debug("Granted Access to GroupId :" + groupId + " and Resource Name:" + resource.resourceName());
	}

}
