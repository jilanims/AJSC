package com.att.api.framework.ajsc.camunda.utils;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import static java.util.Objects.requireNonNull;

import java.security.Principal;

import org.camunda.bpm.engine.AuthorizationService;
import org.camunda.bpm.engine.IdentityService;
import org.camunda.bpm.engine.authorization.Authorization;
import org.camunda.bpm.engine.authorization.Permission;
import org.camunda.bpm.engine.authorization.Resource;
import org.camunda.bpm.engine.identity.User;
import org.camunda.bpm.engine.impl.persistence.entity.AuthorizationEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;

import com.att.api.framework.ajsc.camunda.yaml.beans.AafPermission;
import com.att.api.framework.ajsc.camunda.yaml.beans.CamundaGroup;
import com.att.api.framework.ajsc.camunda.yaml.beans.CamundaResourcePermission;
import com.att.api.framework.common.security.utils.SanitizeUtils;

/**
 * @author jp931e
 *
 */
public class AttCamundaUserAuthorizationUtil {
	private static final Logger logger = LoggerFactory.getLogger(AttCamundaUserAuthorizationUtil.class);

	/*
	 * 1. create user if not exists
	 */
	public static void createUser(IdentityService identityService, Principal principal, String userName, User user)
			throws Exception {
		if (identityService == null) {
			throw new Exception(CamundaConstants.AAF_IDENTITY_IS_EMPTY + " IDENTITY SERVICE IS EMPTY");
		}
		// user creation
		if (identityService.createUserQuery().userId(userName).count() == 0) {
			User newUser = identityService.newUser(userName);
			BeanUtils.copyProperties(user, newUser);
			identityService.saveUser(newUser);
		}
	}

	/*
	 * Create User Authorization
	 */
	public static void createUserAuthorization(List<CamundaResourcePermission> camResPermList,
			AuthorizationService authorizationService, String userId, Integer authorizationType) throws Exception {
		Map<Integer, Resource> deleteResourcesMap = AttCamundaAuthorizationUtil.getResourcesMap();

		if (camResPermList != null && camResPermList.size() > 0) {

			for (CamundaResourcePermission camResPerm : camResPermList) {

				requireNonNull(camResPerm);

				// Already existed resource will be removed from default
				// resourcesMap
				Resource resource = camResPerm.getResource();
				deleteResourcesMap.remove(resource.resourceType());

				createUserAuthorationPerms(authorizationService, userId, resource, camResPerm.getPermissionList(),
						camResPerm.getResourceId(), authorizationType);
			}
		}

		// Delete revoked Resources
		if (deleteResourcesMap.size() > 0) {
			deleteUserResources(authorizationService, deleteResourcesMap, userId, authorizationType);
		}
	}

	// Delete previous resources like
	// USER/GROUP/GROUP_MEMBERSHIP/etc...
	private static void deleteUserResources(AuthorizationService authorizationService,
			Map<Integer, Resource> deleteResourcesMap, String userId, Integer authorizationType) {

		for (Entry<Integer, Resource> entry : deleteResourcesMap.entrySet()) {
			List<Authorization> authorizationList = authorizationService.createAuthorizationQuery().userIdIn(userId)
					.resourceType(entry.getValue()).authorizationType(authorizationType).list();
			if (authorizationList.size() > 0) {
				Iterator<Authorization> it = authorizationList.iterator();
				while (it.hasNext()) {
					Authorization auth = it.next();
					logger.info("Deleted Authoriation Resource {}", entry.getValue());
					authorizationService.deleteAuthorization(auth.getId());
				}
			}
		}

	}

	private static void createUserAuthorationPerms(AuthorizationService authorizationService, String userId,
			Resource resource, List<Permission> permsList, String resourceId, Integer authorizationType)
			throws Exception {

		Authorization au = authorizationService.createAuthorizationQuery().userIdIn(userId).resourceType(resource)
				.resourceId(resourceId).authorizationType(authorizationType).singleResult();

		if (au != null) {
			// check for revoked permissions and delete/adjust then save
			// finally.
			AttCamundaAuthorizationUtil.deletePermission(authorizationService, au, permsList);
		} else {
			createUserAuthorization(authorizationService, userId, resource, resourceId, permsList, authorizationType);
		}
	}

	private static void createUserAuthorization(AuthorizationService authorizationService, String userId,
			Resource resource, String resourceId, List<Permission> permsList, Integer authorizationType)
			throws Exception {
		AuthorizationEntity userAuth = new AuthorizationEntity(authorizationType);
		userAuth.setUserId(userId);
		userAuth.setResource(resource);
		userAuth.setResourceId(resourceId);
		for (Permission currPerm : permsList) {
			userAuth.addPermission(currPerm);
		}
		authorizationService.saveAuthorization(userAuth);
		logger.debug("Granted Access to UserId :" + SanitizeUtils.sanitizeLogData(userId) + " and Resource Name:" + resource.resourceName());
	}

	public static AafPermission aafPermissionNotEmpty(AafPermission aafPermission) throws Exception {
		if (aafPermission == null) {
			throw new Exception(CamundaConstants.AAF_PERMISSION_IS_EMPTY);
		}
		return aafPermission;
	}

	public static CamundaGroup camundaGroupNotEmpty(CamundaGroup grp) throws Exception {
		if (grp == null) {
			throw new Exception(CamundaConstants.CREATE_CAMUNDA_GROUP_IS_EMPTY);
		}
		return grp;
	}

}
