package com.att.api.framework.ajsc.camunda.yaml.beans;

public class DefaultConfig {

	private AafPermission aafPermission;
	private CamundaResourcePermission camAuthorization;
	private CamundaGroup camGroup;

	public AafPermission getAafPermission() {
		return aafPermission;
	}

	public void setAafPermission(AafPermission aafPermission) {
		this.aafPermission = aafPermission;
	}

	public CamundaResourcePermission getCamAuthorization() {
		return camAuthorization;
	}

	public void setCamAuthorization(CamundaResourcePermission camAuthorization) {
		this.camAuthorization = camAuthorization;
	}

	public CamundaGroup getCamGroup() {
		return camGroup;
	}

	public void setCamGroup(CamundaGroup camGroup) {
		this.camGroup = camGroup;
	}

	

}
