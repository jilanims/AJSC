package com.att.api.framework.ajsc.camunda.yaml.beans;

import java.util.ArrayList;
import java.util.List;

public class GroupDefinition {
	private CamundaGroup camGroup;
	private List<CamundaResourcePermission> camAuthorizations = new ArrayList<CamundaResourcePermission>();

	
	public CamundaGroup getCamGroup() {
		return camGroup;
	}

	public void setCamGroup(CamundaGroup camGroup) {
		this.camGroup = camGroup;
	}

	public List<CamundaResourcePermission> getCamAuthorizations() {
		return camAuthorizations;
	}

	public void setCamAuthorizations(List<CamundaResourcePermission> camAuthorizations) {
		this.camAuthorizations = camAuthorizations;
	}

}
