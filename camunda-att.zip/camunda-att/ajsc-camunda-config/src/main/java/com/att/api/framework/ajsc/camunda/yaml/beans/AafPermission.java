package com.att.api.framework.ajsc.camunda.yaml.beans;

import com.att.api.framework.ajsc.camunda.utils.AttCamundaAuthorizationUtil;
import com.att.api.framework.ajsc.camunda.utils.CamundaConstants;

public class AafPermission {

	// private String typePrefix;
	private String instance;
	private String type;
	private String action;

	public String getInstance() {
		return AttCamundaAuthorizationUtil.getDefaultValue(instance);
	}

	public void setInstance(String instance) {
		this.instance = instance;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getAction() {
		return AttCamundaAuthorizationUtil.getDefaultValue(action);
	}

	public void setAction(String action) {
		this.action = action;
	}

	@Override
	public String toString() {
		String str = String.format(CamundaConstants.AAF_PERMISSION_FORMAT, getType(), getInstance(), getAction());
		return str;
	}
}
