package com.att.api.framework.ajsc.camunda.yaml.beans;

public class GroupAssociation {

	public GroupAssociation() {
	}

	private AafPermission aafPermission;
	private CamundaGroup camGroup;

	public AafPermission getAafPermission() {
		return aafPermission;
	}

	public void setAafPermission(AafPermission aafPermission) {
		this.aafPermission = aafPermission;
	}

	public CamundaGroup getCamGroup() {
		return camGroup;
	}

	public void setCamGroup(CamundaGroup camGroup) {
		this.camGroup = camGroup;
	}

}
