package com.att.api.framework.ajsc.camunda.yaml.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import com.att.api.framework.ajsc.camunda.utils.AttCamundaAuthorizationUtil;
import com.att.api.framework.ajsc.camunda.yaml.beans.AjscCamundaIdentityAuthBean;
import com.att.api.framework.ajsc.camunda.yaml.beans.AuthorizationGlobal;
import com.att.api.framework.ajsc.camunda.yaml.beans.GroupDefinitions;
//import com.att.api.framework.ajsc.camunda.yaml.beans.AuthorizationGrants;
//import com.att.api.framework.ajsc.camunda.yaml.beans.DefaultConfig;
//import com.att.api.framework.ajsc.camunda.yaml.beans.GroupAssociations;



@Configuration
public class AjscCamundaAuthConfig {

	@Value("${camunda.aaf.permission.yaml:opt/att/ajsc/config/ajsc-aaf-camunda.yaml}")
	private String aafYamlFile;

	// @Autowired
	private AjscCamundaIdentityAuthBean ajscCamundaIdentityAuthBean;

	@Bean(name = "ajscCamundaIdentityAuthBean")
	// @Conditional(ConditionalYamlFileBean.class)
	public AjscCamundaIdentityAuthBean getCamundaAuthBean() throws Exception {
		ajscCamundaIdentityAuthBean = (AjscCamundaIdentityAuthBean) AttCamundaAuthorizationUtil
				.loadYamlFile(aafYamlFile, AjscCamundaIdentityAuthBean.class);
		return ajscCamundaIdentityAuthBean;
	}
	
	@Bean(name = "groupDefinitions")
	@Conditional(ConditionalYamlFileBean.class)
	public GroupDefinitions getGroupDefinitions() {
		GroupDefinitions groupDefinitions = new GroupDefinitions();
		groupDefinitions.setGroupDefinitions(ajscCamundaIdentityAuthBean.getGroupDefinitions());
		return groupDefinitions;
	}
	
	@Bean(name = "authorizationGlobal")
	@Conditional(ConditionalYamlFileBean.class)
	public AuthorizationGlobal getGlobalAuthBean() {
		AuthorizationGlobal authorizationGlobal = ajscCamundaIdentityAuthBean.getAuthorizationGlobal();
		return authorizationGlobal;
	}

	/*@Bean(name = "defaultConfig")
	@Conditional(ConditionalYamlFileBean.class)
	public DefaultConfig getDefaultConfig() {
		return ajscCamundaIdentityAuthBean.getDefaults();
	}*/

	/*@Bean(name = "authorizationGrants")
	@Conditional(ConditionalYamlFileBean.class)
	public AuthorizationGrants getAuthorizationGrants() {
		AuthorizationGrants authorizationGrants = new AuthorizationGrants();
		authorizationGrants.setAuthorizationGrant(ajscCamundaIdentityAuthBean.getAuthorizationGrant());
		return authorizationGrants;
	}*/

		
	/*@Bean(name = "groupAssociations")
	@Conditional(ConditionalYamlFileBean.class)
	public GroupAssociations getGroupAssociationsAuthBean() throws Exception{
		GroupAssociations groupAssociations = new GroupAssociations();
		groupAssociations.setGroupAssociation(ajscCamundaIdentityAuthBean.getGroupAssociation());
		return groupAssociations;
	}*/
	
	/*@Bean
	@Conditional(ConditionalYamlFileBean.class)
	public CreateGroupAuthorization createGroupConfiguration() {
		return new CreateGroupAuthorization();
	}
*/
}
