package com.att.api.framework.ajsc.camunda.yaml.config;

import org.camunda.bpm.engine.AuthorizationService;
import org.camunda.bpm.engine.IdentityService;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.spring.boot.starter.configuration.impl.AbstractCamundaConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import com.att.api.framework.ajsc.camunda.utils.AttCamundaGroupAuthorizationUtil;
import com.att.api.framework.ajsc.camunda.utils.AttCamundaUserAuthorizationUtil;
import com.att.api.framework.ajsc.camunda.utils.CamundaConstants;
import com.att.api.framework.ajsc.camunda.yaml.beans.AuthorizationGlobal;
import com.att.api.framework.ajsc.camunda.yaml.beans.GroupDefinition;
import com.att.api.framework.ajsc.camunda.yaml.beans.GroupDefinitions;
import com.att.api.framework.ajsc.utils.logging.LoggingRecordHelper;
import com.att.api.framework.common.logging.Markers;
import com.att.api.framework.common.utils.CommonNames;

import static org.camunda.bpm.engine.authorization.Authorization.AUTH_TYPE_GRANT;
import static org.camunda.bpm.engine.authorization.Authorization.AUTH_TYPE_GLOBAL;
import static org.camunda.bpm.engine.authorization.Authorization.ANY;
import javax.annotation.PostConstruct;
import static java.util.Objects.requireNonNull;
import java.util.List;

// extends AbstractCamundaConfiguration
public class CreateGroupAuthorization extends AbstractCamundaConfiguration {

	private static final Logger logger = LoggerFactory.getLogger(CreateGroupAuthorization.class);
	private static final Logger tExceptionLogger = LoggerFactory.getLogger(CommonNames.EXCEPTION_LOGGER);

	@Autowired(required = false)
	private GroupDefinitions groupDefinitions;

	@Autowired(required = false)
	private AuthorizationGlobal authorizationGlobal;

	@PostConstruct
	void init() {
	}

	@Override
	public void postProcessEngineBuild(final ProcessEngine processEngine) {

		// requireNonNull(groupDefinitions);

		final IdentityService identityService = processEngine.getIdentityService();
		final AuthorizationService authorizationService = processEngine.getAuthorizationService();
		logger.debug("000", "creating initital Group Definition: {}", groupDefinitions);
		if (groupDefinitions != null) {
			List<GroupDefinition> groupDefinitionList = groupDefinitions.getGroupDefinitions();
			if (groupDefinitionList != null && groupDefinitionList.size() > 0) {

				for (GroupDefinition grpDef : groupDefinitionList) {

					requireNonNull(grpDef);

					requireNonNull(grpDef.getCamGroup());

					if (!AttCamundaGroupAuthorizationUtil.groupAlreadyExists(identityService, grpDef.getCamGroup())) {
						AttCamundaGroupAuthorizationUtil.createGroup(identityService, grpDef.getCamGroup());
					}

					requireNonNull(grpDef.getCamAuthorizations());

					// Created Group and Group Authorization
					try {
						AttCamundaGroupAuthorizationUtil.createGroupAuthorization(grpDef.getCamAuthorizations(),
								authorizationService, grpDef.getCamGroup().getId(), AUTH_TYPE_GRANT);
					} catch (Exception e) {
						tExceptionLogger.error(Markers.EXCEPTION, "Exception", LoggingRecordHelper.createExceptionInfo(
								CamundaConstants.CAMUNDA_CREATE_GROUP_FAILED, e.getStackTrace().toString()));
					}

				}
			}
		} else {
			logger.debug(CamundaConstants.YAML_CAMUNDA_GROUP_DEFINITION_EMPTY);
		}

		// Create Global Authorization for a Group
		// global userId = * (ANY)
		if (authorizationGlobal != null) {
			try {
				AttCamundaUserAuthorizationUtil.createUserAuthorization(authorizationGlobal.getCamAuthorizations(),
						authorizationService, ANY, AUTH_TYPE_GLOBAL);
			} catch (Exception e) {
				tExceptionLogger.error(Markers.EXCEPTION, "Exception", LoggingRecordHelper.createExceptionInfo(
						CamundaConstants.CAMUNDA_CREATE_ADMIN_DEFAULT_ACCESS_FAILED, e.getStackTrace().toString()));
			}
		} else {
			logger.debug(CamundaConstants.YAML_CAMUNDA_GROUP_DEFINITION_EMPTY);
		}

	}

}
