package com.att.api.framework.ajsc.camunda.yaml.beans;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//import com.att.api.framework.ajsc.camunda.utils.AttCamundaAuthorizationUtil;
import com.att.api.framework.ajsc.camunda.utils.CamundaConstants;
import com.att.api.framework.ajsc.utils.logging.LoggingRecordHelper;
import com.att.api.framework.common.logging.Markers;
import com.att.api.framework.common.utils.CommonNames;


public class GroupAssociations {
	
	//private static final Logger logger = LoggerFactory.getLogger(GroupAssociations.class);
	private static final Logger tExceptionLogger = LoggerFactory.getLogger(CommonNames.EXCEPTION_LOGGER);
	
	private List<GroupAssociation> groupAssociation = new ArrayList<GroupAssociation>();

	public List<GroupAssociation> getGroupAssociation() {
		return groupAssociation;
	}

	public void setGroupAssociation(List<GroupAssociation> groupAssociation) throws Exception{
		try{
		this.groupAssociation = groupAssociation;
		}catch(Exception e){
			tExceptionLogger.error(Markers.EXCEPTION, "Exception", LoggingRecordHelper.createExceptionInfo(
					CamundaConstants.YAML_GROUP_ASSOCIATION_INVALID, e.getStackTrace().toString()));
			throw new Exception(CamundaConstants.YAML_GROUP_ASSOCIATION_INVALID, e);
		}
	}

}
