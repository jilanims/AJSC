package com.att.api.framework.ajsc.camunda.yaml.config;

import java.io.FileNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.env.Environment;
import org.springframework.core.type.AnnotatedTypeMetadata;

import com.att.api.framework.ajsc.camunda.utils.AttCamundaAuthorizationUtil;
import com.att.api.framework.ajsc.camunda.yaml.beans.AjscCamundaIdentityAuthBean;

public class ConditionalYamlFileBean implements Condition {

	@Autowired
	private AjscCamundaIdentityAuthBean ajscCamundaIdentityAuthBean;
	// private static final Logger logger =
	// LoggerFactory.getLogger(ConditionalYamlFileBean.class);

	// @Override
	public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
		String yamlFile = null;
		boolean fileExists = false;
		try {
			Environment env = context.getEnvironment();
			yamlFile = env.getProperty("camunda.aaf.permission.yaml");
			fileExists = AttCamundaAuthorizationUtil.fileExists(yamlFile);
			if (!fileExists) {
				// logger.info("********************** FILE NOT EXISTS IN THE
				// LOCATION {} **********************************", yamlFile);
			}
		} catch (FileNotFoundException e) {
			// logger.info("********************** FILE NOT EXISTS IN THE
			// LOCATION {} **********************************", yamlFile);
			fileExists = false;
		}
		return fileExists;
	}

}
