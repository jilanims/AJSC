package com.att.api.framework.ajsc.camunda.yaml.beans;

import org.camunda.bpm.engine.identity.User;

public class AttCamundaUser implements User {

	private static final long serialVersionUID = -5513173628388285084L;
	private String id;
	private String firstName;
	private String lastName;
	private String email;
	private String password;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password != null ? password : id;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
