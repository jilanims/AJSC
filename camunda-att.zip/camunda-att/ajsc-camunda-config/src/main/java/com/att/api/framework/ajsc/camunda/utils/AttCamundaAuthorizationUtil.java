package com.att.api.framework.ajsc.camunda.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.camunda.bpm.engine.AuthorizationService;
import org.camunda.bpm.engine.authorization.Authorization;
import org.camunda.bpm.engine.authorization.Permission;
import org.camunda.bpm.engine.authorization.Permissions;
import org.camunda.bpm.engine.authorization.Resource;
import org.camunda.bpm.engine.authorization.Resources;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.yaml.snakeyaml.Yaml;
import com.att.api.framework.ajsc.utils.logging.LoggingRecordHelper;
import com.att.api.framework.common.logging.Markers;
import com.att.api.framework.common.utils.CommonNames;

/**
 * @author jp931e
 *
 */
public class AttCamundaAuthorizationUtil {
	private static final Logger logger = LoggerFactory.getLogger(AttCamundaAuthorizationUtil.class);
	private static final Logger tExceptionLogger = LoggerFactory.getLogger(CommonNames.EXCEPTION_LOGGER);

	public static void deletePermission(AuthorizationService authorizationService, Authorization au,
			List<Permission> permsList) throws Exception {
		logger.debug("deletePermission method start");
		// Set<Permission> deletePreviousPerm = null;
		Permission[] permsArray = au.getPermissions(Permissions.values());
		List<Permission> curPermList = new ArrayList<Permission>();
		curPermList = Arrays.asList(permsArray);
		Boolean saveAuth = false;
		if (curPermList != null && curPermList.size() > 0) {
			// deletePreviousPerm = new HashSet<Permission>();

			for (Permission perm : curPermList) {
				if (!permsList.contains(perm) && !perm.getName().equals("NONE")) {
					// deletePreviousPerm.add(perm);
					au.removePermission(perm);
					if (!saveAuth) {
						saveAuth = true;
					}
				}
			}
		}
		for (Permission perm : permsList) {
			if (!curPermList.contains(perm)) {
				au.addPermission(perm);
				if (!saveAuth) {
					saveAuth = true;
				}
			}
		}
		if (saveAuth) {
			authorizationService.saveAuthorization(au);
		}

	}

	public static boolean fileExists(String fileName) throws FileNotFoundException {
		return new File(fileName).isFile();
	}

	public static <T> Object loadYamlFile(String filePath, Class<T> type) throws Exception {
		Object config = null;
		File camundaAafFile = null;
		try {
			if (fileExists(filePath)) {
			Yaml yaml = new Yaml();
			camundaAafFile = new File(filePath);
			InputStream in = new FileInputStream(camundaAafFile);
			config = yaml.loadAs(in, type);
			}

		} catch (Exception e) {
			if (e instanceof FileNotFoundException) {
				tExceptionLogger.error(Markers.EXCEPTION, "Exception", LoggingRecordHelper.createExceptionInfo(
						CamundaConstants.YAML_FILE_NOT_FOUND + "File '" + filePath + "' does not exist "));
			} else {
				tExceptionLogger.error(Markers.EXCEPTION, "Exception",
						LoggingRecordHelper.createExceptionInfo(CamundaConstants.YAML_FILE_READ_ERROR, e.getMessage()));
			}
			throw new Exception(CamundaConstants.YAML_FILE_READ_ERROR);
		}
		return config;
	}

	public static List<Permission> getPermissions(String permsStr) throws Exception {
		logger.debug("getPermissions method start");
		List<Permission> permsList = new ArrayList<Permission>();
		if (permsStr != null) {
			String[] permsStrArray = permsStr.split(CamundaConstants.COMMA_SPLIT);
			for (int i = 0; i < permsStrArray.length; i++) {
				if (!StringUtils.isNotBlank(permsStrArray[i])) {
					tExceptionLogger.error(Markers.EXCEPTION, "Exception", LoggingRecordHelper
							.createExceptionInfo(CamundaConstants.YAML_PERMISSIONS_NULL + permsStrArray));
					throw new Exception(CamundaConstants.YAML_PERMISSIONS_NULL + permsStrArray);
				}
				Permission perm = loadPermissions(permsStrArray[i].toUpperCase());
				permsList.add(perm);
			}
		} else {
			// Default Permission All
			Permission perm = Permissions.forName(CamundaConstants.PERMISSION_ALL.toUpperCase());
			permsList.add(perm);
		}
		return permsList;
	}

	private static Permission loadPermissions(String permissionaName) throws Exception {
		Permission perm = null;
		try {
			perm = Permissions.forName(permissionaName);
		} catch (Exception e) {
			tExceptionLogger.error(Markers.EXCEPTION, "Exception", LoggingRecordHelper.createExceptionInfo(
					CamundaConstants.YAML_PERMISSIONS_ERROR + permissionaName, e.getStackTrace().toString()));
			throw new Exception(CamundaConstants.YAML_PERMISSIONS_ERROR + permissionaName, e);
		}
		return perm;
	}

	public static Resource getResources(String resourceName) throws Exception {
		Resource resource = null;
		try {
			if (!StringUtils.isNotBlank(resourceName)) {
				tExceptionLogger.error(Markers.EXCEPTION, "Exception",
						LoggingRecordHelper.createExceptionInfo(CamundaConstants.YAML_RECOURCES_NULL + resourceName));
				throw new Exception(CamundaConstants.YAML_RECOURCES_NULL + resourceName);
			}
			resource = Resources.valueOf(resourceName.toUpperCase());
		} catch (Exception e) {
			tExceptionLogger.error(Markers.EXCEPTION, "Exception", LoggingRecordHelper.createExceptionInfo(
					CamundaConstants.YAML_PERMISSIONS_ERROR + resourceName, e.getStackTrace().toString()));
			throw new Exception(CamundaConstants.YAML_PERMISSIONS_ERROR + resourceName, e);
		}
		return resource;
	}

	public static String getDefaultValue(String action) {
		if (action == null) {
			action = CamundaConstants.ANY;
		}
		return action;
	}

	public static String getDefaultType(String type) {
		if (type == null) {
			type = CamundaConstants.CAMUNDA_GROUP_RESOURCE_TYPE;
		}
		return type;
	}

	public static Map<Integer, Resource> getResourcesMap() {
		Map<Integer, Resource> map = new HashMap<Integer, Resource>();
		for (Resource resource : Resources.values()) {
			map.put(resource.resourceType(), resource);
		}
		return map;
	}
}
