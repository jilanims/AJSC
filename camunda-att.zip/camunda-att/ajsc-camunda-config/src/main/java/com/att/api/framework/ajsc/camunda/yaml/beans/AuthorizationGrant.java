package com.att.api.framework.ajsc.camunda.yaml.beans;

import java.util.ArrayList;
import java.util.List;

public class AuthorizationGrant {

	private AafPermission aafPermission;

	private List<CamundaResourcePermission> camAuthorizations = new ArrayList<CamundaResourcePermission>();

	public List<CamundaResourcePermission> getCamAuthorizations() {
		return camAuthorizations;
	}

	public void setCamAuthorizations(List<CamundaResourcePermission> camAuthorizations) {
		this.camAuthorizations = camAuthorizations;
	}

	public AafPermission getAafPermission() {
		return aafPermission;
	}

	public void setAafPermission(AafPermission aafPermission) {
		this.aafPermission = aafPermission;
	}
}
