package com.att.api.framework.ajsc.camunda.yaml.beans;

import java.util.ArrayList;
import java.util.List;

public class AuthorizationGrants {

	private List<AuthorizationGrant> authorizationGrant = new ArrayList<AuthorizationGrant>();

	public List<AuthorizationGrant> getAuthorizationGrant() {
		return authorizationGrant;
	}

	public void setAuthorizationGrant(List<AuthorizationGrant> authorizationGrant) {
		this.authorizationGrant = authorizationGrant;
	}

}
