package com.att.api.framework.ajsc.adapter;


import java.util.HashMap;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
//import org.slf4j.Logger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
//import org.slf4j.LoggerFactory;

//import com.att.api.framework.ajsc.csi.framework.service.ServiceCommonNames;
import com.att.api.framework.ajsc.csi.util.XMLUtilities;
import com.att.api.framework.ajsc.fault.exception.UtilLib;
import com.att.api.framework.ajsc.trace.Trace;
import com.att.api.framework.common.utils.CommonNames;
//import com.att.eelf.configuration.EELFLogger;
/**
 * @author jp931e
 *
 */
public class InvokeAdapterDelegate <T> implements JavaDelegate {
	
	//private static EELFLogger LOGGER = AjscEelfManager.getInstance().getLogger(InvokeAdapterDelegate.class);
	private static Logger LOGGER = LoggerFactory.getLogger(InvokeAdapterDelegate.class);
	
	@Trace(message="Call InvokeAdapterDelegate")
	public void execute(DelegateExecution delegate) throws Exception {
		
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("********Start InvokeAdapterDelegate**********");
		}
		
		delegate.setVariable(AdapterCommonNames.CSI_INVOKEADAPTER_PRVRESPONSE, "");
		
		InvokeAdapter invokeAdapter = new InvokeAdapter();
		HashMap<String,Object> mapVars = this.convertDelegateToMap(delegate);
		mapVars = invokeAdapter.invoke(mapVars);
		String prvResponse = (String) mapVars.get(AdapterCommonNames.CSI_INVOKEADAPTER_PRVRESPONSE);		
		
		
		LOGGER.info("Invoke Adapter Response xml:{}",prvResponse);
		//delegate.setVariable(AdapterCommonNames.CSI_INVOKEADAPTER_PRVRESPONSE, XMLUtilities.convLargeXMLtoObj(prvResponse));
		delegate.setVariable(AdapterCommonNames.CSI_INVOKEADAPTER_PRVRESPONSE, XMLUtilities.convStringLargeXMLtoByteArray(prvResponse));
  	    
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("********End InvokeAdapterDelegate**********");
		}
	}
	
	private HashMap<String,Object> convertDelegateToMap(DelegateExecution delegate) throws Exception{
		HashMap<String,Object> mapVars = new HashMap<String,Object>();
		mapVars.put(CommonNames.TRANSACTION_STATE, UtilLib.getTransactionState(delegate));
		mapVars.put(CommonNames.HEADER_ATT_SERVICE_NAME, (String)delegate.getVariable(AdapterCommonNames.INVOKE_SERVICE_NAME));
		mapVars.put(AdapterCommonNames.PARTNER_PROFILE_CLIENT, "ajscUser");
		//mapVars.put(AdapterCommonNames.CSI_INVOKEADAPTER_PRVREQUEST, (String)delegate.getVariable(AdapterCommonNames.CSI_INVOKEADAPTER_PRVREQUEST));
		mapVars.put(AdapterCommonNames.CSI_INVOKEADAPTER_PRVREQUEST, XMLUtilities.convObjToXMLString(delegate, AdapterCommonNames.CSI_INVOKEADAPTER_PRVREQUEST));
		mapVars.put(AdapterCommonNames.CSI_INVOKEADAPTER_MESSAGEHEADER, (String)delegate.getVariable(AdapterCommonNames.CSI_INVOKEADAPTER_MESSAGEHEADER));
		mapVars.put(AdapterCommonNames.CSI_INVOKEADAPTER_MODE, (String)delegate.getVariable(AdapterCommonNames.CSI_INVOKEADAPTER_MODE));
		mapVars.put(AdapterCommonNames.CSI_ADAPTER_NAME, (String)delegate.getVariable(AdapterCommonNames.CSI_ADAPTER_NAME));
		mapVars.put(AdapterCommonNames.CSI_ADAPTER_METHOD, (String)delegate.getVariable(AdapterCommonNames.CSI_ADAPTER_METHOD));
		mapVars.put(AdapterCommonNames.CSI_INVOKEADAPTER_SUBSCRIBER, (String)delegate.getVariable(AdapterCommonNames.CSI_INVOKEADAPTER_SUBSCRIBER));
		//mapVars.put(CommonNames.HEADER_ATT_CONVERSATION_ID, (String)delegate.getVariable(CommonNames.HEADER_ATT_CONVERSATION_ID));		
		mapVars.put(AdapterCommonNames.CSI_INVOKEADAPTER_TIMEOUT, (String)delegate.getVariable(AdapterCommonNames.CSI_INVOKEADAPTER_TIMEOUT));
		mapVars.put(CommonNames.HEADER_ATT_CONVERSATION_ID, (String)delegate.getVariable(CommonNames.HEADER_ATT_CONVERSATION_ID));
		mapVars.put(CommonNames.HEADER_ATT_UNIQUE_TXN_ID, (String)delegate.getVariable(CommonNames.HEADER_ATT_UNIQUE_TXN_ID));
		return mapVars;
	}

}
