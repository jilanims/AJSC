package com.att.api.framework.ajsc.util;

import java.io.Reader;
import java.io.StringReader;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamReader;
import com.att.api.framework.common.security.utils.XXESettingUtils;

/**
 * This is a simple parsing example that illustrates
 * the XMLStreamReader class.
 */

public class XMLParseUtil {


  public static boolean checkForFaultNode(String args) throws Exception {
	  XMLStreamReader xmlr = null;
	  boolean faultCodeFlag = false;
  try{
    XMLInputFactory xmlif = XMLInputFactory.newInstance();
    XXESettingUtils.setXMLInputFactoryXXE(xmlif);
    Reader reader = new StringReader(args);
    xmlr = xmlif.createXMLStreamReader(reader);
    while(xmlr.hasNext()){    	
    	 if (XMLStreamConstants.START_ELEMENT == xmlr.getEventType()) { 	    	     
	 	    	if(xmlr.getLocalName().contains("Fault")){	  
	 	  	      String localName = xmlr.getLocalName();
	 	  	      System.out.println("localName:"+localName);
	 	  	      faultCodeFlag = true;
	 	  	      break;
	 	  	    }   
 	     }
      xmlr.next();
    }  
  }finally{
	  xmlr.close(); 
  }    
  return faultCodeFlag;
  }

 }
