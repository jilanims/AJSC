package com.att.api.framework.ajsc.csi.framework.service;


import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.api.framework.ajsc.csi.framework.service.ServiceCommonNames;
import com.att.api.framework.common.logging.APITransactionLogger;
import com.att.api.framework.common.logging.PerformanceTrackingRecord;
import com.att.api.framework.common.logging.PerformanceTrackingTrailMark;
import com.att.api.framework.common.logging.TransactionLogger;
import com.att.api.framework.common.service.InvokeServiceParams;
import com.att.api.framework.common.state.api.AJSCTransactionStateImpl;
import com.att.api.framework.common.utils.CommonNames;
import com.att.api.framework.common.utils.CommonUtil;
import com.att.api.framework.jaxb.requestparameters.RequestParameters;
import com.att.env.APIException;

/**
 * @author jp931e
 *
 */
public class InvokeService2 {

	private String service;
	private String version;
	private String callingServiceName = null, targetService = null, convId = null, userName =null;
	private long minTimeout = 2000;
	
	private static final String DEFAULT_AJSC_INSTANCE_NAME = "UNSPECIFIED_AJSC_INSTANCE";
	
	private static final Logger logger = LoggerFactory.getLogger(InvokeService2.class);

	
	public final HashMap<String, Object> invoke(HashMap<String, Object> mapVariables) throws Exception{
		
		resetFields();
		
		String prvResponse = null;
		
		AJSCTransactionStateImpl state = (AJSCTransactionStateImpl)mapVariables.get(CommonNames.TRANSACTION_STATE);
		PerformanceTrackingRecord tracking = state.getTrackingRecord();
		
		String message = (String)mapVariables.get(ServiceCommonNames.CSI_INVOKESERVICE_SERVICEREQUEST);
		logger.info("Invoke Service Requqest message:"+message);
		
		if (message == null || message.isEmpty()) {
			throw new Exception("Empty Request");
		}
		
		callingServiceName = (String)mapVariables.get(CommonNames.HEADER_ATT_SERVICE_NAME);
		if(callingServiceName == null){
			callingServiceName = (String)mapVariables.get(CommonNames.HEADER_ATT_METHOD_NAME);
		}
		
		String uniqueID = (String)mapVariables.get(CommonNames.HEADER_ATT_UNIQUE_TXN_ID);
		
		PerformanceTrackingTrailMark trailMark = tracking.addTrailMark("InvokeService");
		
		try {
			// Grab a new AjscServiceTrans
			InvokeServiceParams params = createServiceParams(mapVariables, state, callingServiceName, uniqueID);	

			//Introscope instrumentation call before the downstream call
			AjscIntroscopeService.callIntroscopeSyncMethod(uniqueID, convId, callingServiceName, userName, AjscIntroscopeService.CallType.ENTRY, AjscIntroscopeService.INVOKE_SERVICE);
			
			logger.info("Invoke Service Request:"+message);
			
			if(message instanceof String){					
				Future<String> responseFutureObject =  com.att.api.framework.common.service.InvokeService.invokeService(params,  message.toString()); 
				prvResponse = responseFutureObject.get();
			} else {
				throw new APIException("Input request message is not an String");
			}

		} catch (APIException apie) {// Anand : TODO : Need to do the necessary changes when AJSC error / exception handling stories are completed.				
			throw apie;				
		}catch (Exception e) {			
			throw new APIException(e);				
		} finally {
			//Introscope instrumentation call after the downstream call
			AjscIntroscopeService.callIntroscopeSyncMethod(uniqueID, convId, callingServiceName, userName, AjscIntroscopeService.CallType.EXIT, AjscIntroscopeService.INVOKE_SERVICE);
			
		}
		logger.info("Invoke Service Response:"+prvResponse);
		mapVariables.put(ServiceCommonNames.CSI_INVOKESERVICE_SERVICERESPONSE, prvResponse);
		
		return mapVariables;

	}	
	
	/**
	 * @param exchange
	 * @param perfTrackerBean
	 * @param callingServiceName
	 * @return InvokeServiceParams
	 * @throws Exception
	 */
	private InvokeServiceParams createServiceParams(HashMap mapVariables, AJSCTransactionStateImpl transState, String callingServiceName,  String uniqueTxId)
			throws Exception {

		long timeLeft = 0L;
		long timeToLive = 0L;

		TransactionLogger logger = new APITransactionLogger(callingServiceName);		
		RequestParameters reqParam = ((AJSCTransactionStateImpl)transState).getRequestParameters();

		targetService = (String)mapVariables.get(ServiceCommonNames.CSI_INVOKESERVICE_NAME);
		if (targetService == null || targetService.isEmpty()) {
			targetService = service;
		}
		if(callingServiceName==null){
			callingServiceName = targetService;
		}

		String targetVersion = (String)mapVariables.get(ServiceCommonNames.CSI_INVOKESERVICE_VERSION);
		if (targetVersion == null || targetVersion.isEmpty()) {
			targetVersion = version;
		}
		if (targetVersion == null || targetVersion.isEmpty()) {
			throw new Exception("Request version not set");
		}

		String key, ttl = null, guid = "", mhMessageId = "",mhVersion = "", gsmSessionKey = null, crossReleaseSupport = null, timeStamp=null;
		ttl = (String)mapVariables.get(CommonNames.HEADER_ATT_TIME_TO_LIVE);
		String mode = "", clientApp = null, targetVoltageStateStr = null, serviceKeyData1 = "", serviceKeyData2 = "", jmsIgnoreAck = "";
		String	calculateTargetGSMSessionKeyStr = null;
		
		if(reqParam!=null && reqParam.getHeader()!=null){
		for (int i=0; i<reqParam.getHeader().getPair().size(); i++) {
			key = reqParam.getHeader().getPair().get(i).getKey();
			if (key.equalsIgnoreCase(CommonNames.MODE))
				mode = reqParam.getHeader().getPair().get(i).getValue();
			else if (key.equalsIgnoreCase(CommonNames.CLIENT_APP))
				clientApp = reqParam.getHeader().getPair().get(i).getValue();
			else if (key.equalsIgnoreCase(CommonNames.VOLTAGE_ENABLED_INDICATOR))
				targetVoltageStateStr = reqParam.getHeader().getPair().get(i).getValue();
			else if (key.equalsIgnoreCase(CommonNames.SERVICE_KEY_DATA1))
				serviceKeyData1 = reqParam.getHeader().getPair().get(i).getValue();
			else if (key.equalsIgnoreCase(CommonNames.SERVICE_KEY_DATA2))
				serviceKeyData2 = reqParam.getHeader().getPair().get(i).getValue();
			else if (key.equalsIgnoreCase(CommonNames.HEADER_ATT_SERVICE_NAME) && targetService == null)
				targetService = reqParam.getHeader().getPair().get(i).getValue();
			else if (key.equalsIgnoreCase(CommonNames.HEADER_ATT_TIME_TO_LIVE))
				ttl = reqParam.getHeader().getPair().get(i).getValue();
			else if (key.equalsIgnoreCase(CommonNames.HEADER_ATT_CONVERSATION_ID))
				convId = reqParam.getHeader().getPair().get(i).getValue();
			else if (key.equalsIgnoreCase(CommonNames.GUID))
				guid = reqParam.getHeader().getPair().get(i).getValue();
			else if (key.equalsIgnoreCase(CommonNames.CSI_JMSIGNORE_ACK))
				jmsIgnoreAck = reqParam.getHeader().getPair().get(i).getValue();
			else if (key.equalsIgnoreCase(CommonNames.CSI_CALTARGETGSMSESSIONKEY))
				calculateTargetGSMSessionKeyStr = reqParam.getHeader().getPair().get(i).getValue();
			else if (key.equalsIgnoreCase(CommonNames.HEADER_ATT_MESSAGE_ID))
				mhMessageId = reqParam.getHeader().getPair().get(i).getValue();
			else if (key.equalsIgnoreCase(CommonNames.HEADER_ATT_INFRASTRUCTURE_VERSION))
				mhVersion = reqParam.getHeader().getPair().get(i).getValue();
			else if (key.equalsIgnoreCase(CommonNames.GSM_SESSION_KEY))
				gsmSessionKey = reqParam.getHeader().getPair().get(i).getValue();
			else if (key.equalsIgnoreCase(CommonNames.CROSS_RELEASE_SUPPORT))
				crossReleaseSupport = reqParam.getHeader().getPair().get(i).getValue();
			else if (key.equalsIgnoreCase(CommonNames.HEADER_ATT_DATE_TIME_STAMP))
				timeStamp = reqParam.getHeader().getPair().get(i).getValue();
			else if (key.equalsIgnoreCase(CommonNames.HEADER_ATT_VERSION) && targetVersion == null)
				targetVersion = reqParam.getHeader().getPair().get(i).getValue();
			else if (key.equalsIgnoreCase(CommonNames.HEADER_ATT_UNIQUE_TXN_ID))
				uniqueTxId = reqParam.getHeader().getPair().get(i).getValue();
			else if (key.equalsIgnoreCase(CommonNames.CSI_USER_NAME))
				userName = reqParam.getHeader().getPair().get(i).getValue(); 
			else if (key.equalsIgnoreCase(CommonNames.HTTP_AUTHORIZATION)) {
				String authHeader = reqParam.getHeader().getPair().get(i).getValue();
				if (authHeader != null) {
					userName = CommonUtil.extractUserNameFromHeader(authHeader);
				}
			}
		}
		}
		// if the converstionid is not available in the header then get it from exchange....
		if(userName == null) {
			userName = (String)mapVariables.get(ServiceCommonNames.PARTNER_PROFILE_CLIENT);
		}
		if(convId == null) {
			convId = (String)mapVariables.get(CommonNames.HEADER_ATT_CONVERSATION_ID);
		}
		if(uniqueTxId == null) {
			uniqueTxId = (String)mapVariables.get(CommonNames.HEADER_ATT_UNIQUE_TXN_ID);
		}
		

		Object tempTimeLeft = mapVariables.get(ServiceCommonNames.CSI_INVOKESERVICE_TIMEOUT);
		if (tempTimeLeft == null) {
			timeLeft = 0L;
		} else {
			timeLeft = Long.valueOf(tempTimeLeft.toString());
		}
		if (timeLeft < minTimeout) {			
			long stime = 0;
			if(timeStamp!=null){
				stime = Long.parseLong(timeStamp);
			}
			timeLeft = Long.parseLong(ttl) - (System.nanoTime()/1000000 - stime);
		}

		timeToLive = timeLeft + System.currentTimeMillis();

		String instanceName = DEFAULT_AJSC_INSTANCE_NAME;

		boolean targetVoltageState = false;
		if (targetVoltageStateStr != null  &&  targetVoltageStateStr.equalsIgnoreCase("true"))
		{
			targetVoltageState = true;
		}

		boolean calculateTargetGSMSessionKey = false;
		if (calculateTargetGSMSessionKeyStr != null  &&  calculateTargetGSMSessionKeyStr.equalsIgnoreCase("true"))
		{
			calculateTargetGSMSessionKey = true;
		}

		//String versionApplEnv = System.getProperty(CommonNames.VERSION_ROUTEOFFER_ENVCONTEXT);
		String versionApplEnv = System.getProperty("SERVICE_VERSION_ROUTEOFFER_ENVCONTEXT");		
		String[] splitInstance = versionApplEnv.split("\\/");
		String defaultEnvContext = splitInstance[2];
		String stickySelectorKey = splitInstance[1];


		logger.setConversationId(convId);
		logger.setEngine(instanceName);
		logger.setServiceName(callingServiceName);	
		logger.setGuid(guid);

		InvokeServiceParams serviceParams = new InvokeServiceParams(logger);
		serviceParams.setTimeToLive(timeToLive);		
		serviceParams.setMode(mode);
		serviceParams.setServiceKeyData1(serviceKeyData1);
		serviceParams.setServiceKeyData2(serviceKeyData2);
		serviceParams.setClientApp("AJSC-CSI~"+instanceName +"~"+callingServiceName);
		serviceParams.setServiceName(callingServiceName);
		serviceParams.setPartner(userName);
		serviceParams.setGuid(guid);
		serviceParams.setInvokeServiceName(targetService);			
		serviceParams.setTargetVersion(targetVersion);
		serviceParams.setCalculateTargetGSMSessionKey(calculateTargetGSMSessionKey);
		serviceParams.setCrossReleaseSupport(crossReleaseSupport);
		serviceParams.setGsmSessionKey(gsmSessionKey);
		serviceParams.setMhMessageId(mhMessageId);
		serviceParams.setMhVersion(mhVersion);
		serviceParams.setJmsIgnoreAck(jmsIgnoreAck);
		serviceParams.setTargetVoltageState(targetVoltageState);
		serviceParams.setOverridedLastMoment(timeToLive);
		serviceParams.setApplEnvContext(defaultEnvContext);
		serviceParams.setApplEnvVersion(targetVersion);
		serviceParams.setStickySelector(stickySelectorKey);
		serviceParams.setConversationId(convId);
		
		// Added to handle AJSC7 based soap mS, as GRM will not have subcontext url.
		// Source service should send it and we will set it only when it is available..
		// Source service should send this Extra / additional JMS params that needs to be added as String property in the TextMessage....
		Map<String,String> targetAdditionalProps = (Map<String,String>)mapVariables.get(ServiceCommonNames.CSI_INVOKESERVICE_ADDITIONAL_JMS_PROPS);
		if(targetAdditionalProps !=null && targetAdditionalProps.size()!=0) {
			serviceParams.setTargetAdditionalJMSProps(targetAdditionalProps);
		}
		/*String targetSubContextUrl = (String)request.getAttribute(ServiceCommonNames.CSI_INVOKESERVICE_SUBCONTEXT_URL);		
		if (targetSubContextUrl != null && !targetSubContextUrl.isEmpty()) {
			serviceParams.setSubcontextUrl(targetSubContextUrl);
		}*/

		return serviceParams;
	}
	
	private void resetFields(){
		convId = null;
		userName =null;
		callingServiceName = null;
		targetService=null;
	}
	
}
