package com.att.api.framework.ajsc.csi.util;

import java.util.Map;

/**
 * @author jn448j
 *
 */
public class XPath {

	private Map<String, String> nsMap = null;
	
	public XPath(Map<String, String> nsMap) {
		this.nsMap = nsMap;
	}
	
	public String execXpath(String xml, String xpath){
		return XMLUtilities.evaluateXPath(xml, xpath, nsMap);
	}
}
