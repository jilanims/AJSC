package com.att.api.framework.ajsc.parallel.adapter;

import java.util.ArrayList;
import java.util.HashMap;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.api.framework.ajsc.csi.framework.service.ServiceCommonNames;
import com.att.api.framework.ajsc.csi.util.XMLUtilities;
import com.att.api.framework.ajsc.fault.exception.UtilLib;
import com.att.api.framework.common.utils.CommonNames;


public class InvokeParallelAdapterDelegate implements JavaDelegate{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(InvokeParallelAdapterDelegate.class);
	
	public String callingServiceName=null, convId=null, uniqueId=null, partner=null;

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		
		resetFields();
		try{
			
		execution.setVariable(ParallelCommonNames.CSI_INVOKE_SERVICERESPONSE, null);
		
		//operations variables
		callingServiceName =(String) execution.getVariable(ServiceCommonNames.INVOKE_SERVICE_NAME);
		convId  = (String) execution.getVariable(CommonNames.HEADER_ATT_CONVERSATION_ID);
		uniqueId  = (String) execution.getVariable(CommonNames.HEADER_ATT_UNIQUE_TXN_ID);
		partner  = (String) execution.getVariable(ServiceCommonNames.PARTNER_PROFILE_CLIENT);
		
		//String elementName = (String) execution.getVariable(ParallelCommonNames.SERVICE_XML_ELEMENT_NAME);
		InvokeParallelSerialService invokeParallelService = new InvokeParallelSerialService();
		HashMap<String,Object>parallelAdapterVariables = convertDeleteToMap(execution);
		HashMap<String, Object> responseMap = invokeParallelService.invokeService(parallelAdapterVariables);
		//String internalLoopReqXML = (String)execution.getVariable(ParallelCommonNames.CSI_INVOKESERVICE_SERVICEREQUEST);
		String internalLoopReqXML = XMLUtilities.convObjToXMLString(execution, ParallelCommonNames.CSI_INVOKESERVICE_SERVICEREQUEST);
		
		ArrayList<Object> resonseXmlList = (ArrayList)responseMap.get(ParallelCommonNames.CSI_INVOKE_SERVICERESPONSE);
		String InternalLoopResponseXML = XMLUtilities.getInternalLoopResponse(internalLoopReqXML, resonseXmlList);
		LOGGER.info("InternalLoopResponseXML:"+InternalLoopResponseXML);
		
		//execution.setVariable(ParallelCommonNames.CSI_INVOKE_SERVICERESPONSE, XMLUtilities.convLargeXMLtoObj(InternalLoopResponseXML));
		execution.setVariable(ParallelCommonNames.CSI_INVOKE_SERVICERESPONSE, XMLUtilities.convStringLargeXMLtoByteArray(InternalLoopResponseXML));
		
		}catch(Exception exception){
			throw new Exception(exception.getMessage());			
		}	
	}
	
	private HashMap<String,Object> convertDeleteToMap(DelegateExecution execution) throws Exception{
		HashMap<String,Object> mapVariables = new HashMap<String, Object>();		
		//String internalLoopReqXML = (String)execution.getVariable(ParallelCommonNames.CSI_INVOKESERVICE_SERVICEREQUEST);
		String internalLoopReqXML = XMLUtilities.convObjToXMLString(execution, ParallelCommonNames.CSI_INVOKESERVICE_SERVICEREQUEST);
		mapVariables.put(ParallelCommonNames.INVOKE_SERVICE_NAME, execution.getVariable(ParallelCommonNames.INVOKE_SERVICE_NAME));
		mapVariables.put(ParallelCommonNames.CSI_TARGET_SERVICE_NAME, execution.getVariable(ParallelCommonNames.CSI_TARGET_SERVICE_NAME));
		mapVariables.put(ParallelCommonNames.CSI_TARGET_ADAPTER_METHOD, execution.getVariable(ParallelCommonNames.CSI_TARGET_ADAPTER_METHOD));
		mapVariables.put(ParallelCommonNames.CSI_ADAPTER_MESSAGEHEADER, execution.getVariable(ParallelCommonNames.CSI_ADAPTER_MESSAGEHEADER));
		mapVariables.put(ParallelCommonNames.CSI_ADAPTER_SUBSCRIBER, execution.getVariable(ParallelCommonNames.CSI_ADAPTER_SUBSCRIBER));
		mapVariables.put(ParallelCommonNames.CSI_INVOKE_TIMEOUT, execution.getVariable(ParallelCommonNames.CSI_INVOKE_TIMEOUT));
		mapVariables.put(ParallelCommonNames.ATTR_START_TIME, execution.getVariable(ParallelCommonNames.ATTR_START_TIME));
		mapVariables.put(ParallelCommonNames.CSI_TARGET_SERVICE_VERSION, execution.getVariable(ParallelCommonNames.CSI_TARGET_SERVICE_VERSION));
		mapVariables.put(CommonNames.TRANSACTION_STATE, UtilLib.getTransactionState(execution));
		//mapVariables.put(ParallelCommonNames.PERFORMANCE_TRACKER_BEAN, execution.getVariable(ParallelCommonNames.PERFORMANCE_TRACKER_BEAN));
		//mapVariables.put("CAMEL_EXCHANGE_ID", execution.getVariable("CAMEL_EXCHANGE_ID"));
		mapVariables.put(ParallelCommonNames.PARTNER_PROFILE_CLIENT, execution.getVariable(ParallelCommonNames.PARTNER_PROFILE_CLIENT));		
		mapVariables.put(ParallelCommonNames.PARALLEL_SERIAL_ADAPTER, execution.getVariable(ParallelCommonNames.PARALLEL_SERIAL_ADAPTER));
		
		mapVariables.put(CommonNames.HEADER_ATT_CONVERSATION_ID, execution.getVariable(CommonNames.HEADER_ATT_CONVERSATION_ID));
		mapVariables.put(CommonNames.HEADER_ATT_UNIQUE_TXN_ID, execution.getVariable(CommonNames.HEADER_ATT_UNIQUE_TXN_ID));		
		
		//handling large xml into array list of strings
		ArrayList<String> inputArrayList= XMLUtilities.getInternalLoopRequestList(internalLoopReqXML, (String)execution.getVariable(ParallelCommonNames.CSI_TARGET_ADAPTER_METHOD),
				(String) execution.getVariable(ParallelCommonNames.CSI_ADAPTER_MESSAGEHEADER), (String)execution.getVariable(ParallelCommonNames.CSI_TARGET_SERVICE_VERSION),
				(String)execution.getVariable(ParallelCommonNames.TARGET_NAMESPACE));
				
		mapVariables.put(ParallelCommonNames.CSI_INVOKESERVICE_SERVICEREQUEST, inputArrayList);
		return mapVariables;		
	}
	
	private void resetFields(){
		convId = null;
		uniqueId=null;
		partner=null;
		callingServiceName = null;
	}

}
