package com.att.api.framework.ajsc.util;

import java.io.File;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.ssf.filemonitor.FileMonitor;

/**
 *
 */
public class DMNRuleService {

	private boolean loadOnStartup;

	static final Logger logger = LoggerFactory.getLogger(DMNRuleService.class);
	
	private static final String dmnRulesLocation = System.getProperty("dmnRules.location");

	// do not remove the postConstruct annotation, init method will not be
	// called after constructor
	@PostConstruct
	public void init() throws Exception {
		FileMonitor fm = FileMonitor.getInstance();
		File[] files = new File(dmnRulesLocation).listFiles();
		logger.debug("Adding listners for dmn files under {}", dmnRulesLocation);
		for (int i = 0; i < files.length; i++) {
			if(files[i].getName().endsWith(".dmn")){
				fm.addFileChangedListener(files[i] ,new DMNRuleListener(), loadOnStartup);
				logger.debug("FileChangeListener added for {}", files[i].getName());
			}
		}
	}

	public void setLoadOnStartup(boolean loadOnStartup) {
		this.loadOnStartup = loadOnStartup;
	}

	public boolean getLoadOnStartup() {
		return loadOnStartup;
	}
}
