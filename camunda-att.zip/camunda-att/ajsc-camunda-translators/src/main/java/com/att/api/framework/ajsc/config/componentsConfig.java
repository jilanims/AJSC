package com.att.api.framework.ajsc.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.att.api.framework.ajsc.csi.framework.service.InvokeServiceDelegate;

@Configuration
public class componentsConfig {
	
	@Bean
	public InvokeServiceDelegate invokeDelegate(){
		return new InvokeServiceDelegate();
	}
}
