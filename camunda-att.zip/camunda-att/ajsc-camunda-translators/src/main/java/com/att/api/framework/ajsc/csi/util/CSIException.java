package com.att.api.framework.ajsc.csi.util;

/**
 * @author jn448j
 *
 */
public class CSIException extends Exception {

	private static final long serialVersionUID = 6754651116067969129L;
	
	private String code = "900";
	
	private String application = "CSI";
	
	private String faultEntity = "CSI";
	
	public CSIException(String code, String message) {
		super(isNullOrEmpty(message) ? "Unknown Error": message);
		this.code = isNullOrEmpty(code) ? "900": code;
	}
	
	public CSIException(String code, String message, String application) {
		super(isNullOrEmpty(message) ? "Unknown Error": message);
		this.code = isNullOrEmpty(code) ? "900": code;
		this.application = isNullOrEmpty(application) ? "CSI": application;
	}
	
	public CSIException(String code, String message, String application, String faultEntity) {
		super(isNullOrEmpty(message) ? "Unknown Error": message);
		this.code = isNullOrEmpty(code) ? "900": code;
		this.application = isNullOrEmpty(application) ? "CSI": application;
		this.faultEntity = isNullOrEmpty(faultEntity) ? "CSI": faultEntity;
	}
	
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getApplication() {
		return application;
	}

	public void setApplication(String application) {
		this.application = application;
	}

	public String getFaultEntity() {
		return faultEntity;
	}

	public void setFaultEntity(String faultEntity) {
		this.faultEntity = faultEntity;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CSIException [application:" + getApplication());
		builder.append("][faultEntity:" + getFaultEntity());
		builder.append("][code:" + getCode());
		builder.append("][message:" + getMessage() + "]");
		return builder.toString();
	}
	
	private static boolean isNullOrEmpty(Object obj){
		boolean isNullOrEmpty = false;
		if(obj == null){
			isNullOrEmpty = true;
		}else if(String.class.isInstance(obj) && "".equals(obj)){
			isNullOrEmpty = true;
		}
		return isNullOrEmpty;
	}

}
