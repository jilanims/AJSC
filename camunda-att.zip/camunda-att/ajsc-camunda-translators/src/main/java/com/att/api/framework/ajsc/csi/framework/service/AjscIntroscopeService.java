package com.att.api.framework.ajsc.csi.framework.service;

import com.att.api.framework.introscope.IntroscopeEventNotifierImpl;

public class AjscIntroscopeService {
	
	public enum CallType {
		ENTRY, EXIT
	};
	
	public static final String INVOKE_SERVICE ="InvokeService";
	public static final String INVOKE_ADAPTER="InvokeAdapter";
	public static final String INVOKE_CONTIVO ="InvokeContivo";
	
		
	public static void callIntroscopeSyncMethod(String uniqueID, String conversationId, String userID, String serviceName, CallType callType, String invokeServiceType) {
		
		final String hypen ="-";
		if(serviceName==null){
			serviceName="ajscCamunda";
		}
		StringBuilder serviceNameSB = new StringBuilder(serviceName);
		serviceNameSB.append(hypen);
		serviceNameSB.append(invokeServiceType);		
		
		switch (callType) {
		case ENTRY:
			IntroscopeEventNotifierImpl.instrumentIntroscopeSynchEntryPoint(serviceNameSB.toString(),
					conversationId, uniqueID, userID);

			break;
		case EXIT:
			IntroscopeEventNotifierImpl.instrumentIntroscopeSynchExitPoint(serviceNameSB.toString(),
					conversationId, uniqueID, userID);
			break;

		}

	}
}
