package com.att.api.framework.ajsc.contivo;

public class AJSCContivoCommonNames {
	  public static final String CSI_INVOKECONTVO_REQUEST_ARRAY = "CSI_INVOKECONTVO_REQUEST_ARRAY";
	  public static final String CSI_TRANSFORM_NAME = "CSI_TRANSFORM_NAME";
	  public static final String CSI_INVOKECONTIVO_INPUT_TYPE = "CSI_INVOKECONTIVO_INPUT_TYPE";
	  public static final String CSI_INVOKECONTIVO_PRVRESPONSE = "CSI_INVOKECONTIVO_PRVRESPONSE";
	  public static final String PERFORMANCE_TRACKER_BEAN = "PERFORMANCE_TRACKER_BEAN";
	  public static final String INVOKE_SERVICE_NAME = "INVOKE_SERVICE_NAME";
	  public static final String CSI_INVOKE_CONTIVO_SERVICE_NAME = "CSI_INVOKERESTSERVICE_NAME";
	  public static final String PARTNER_PROFILE_CLIENT ="PARTNER_PROFILE_CLIENT";
	  
}
