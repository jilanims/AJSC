package com.att.api.framework.ajsc.voltage;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

import org.camunda.spin.plugin.variable.SpinValues;
import org.camunda.spin.plugin.variable.value.XmlValue;

import Utils.Voltage.common.UtilLib;

/**
 * @author mc184q
 *
 */
public class InvokeVoltageDelegate<T> implements JavaDelegate {
	// Just for info for SPI Flag
	public static String differentSPI = "diff";
	public static String combinedSPI = "all";
	public static String onlySPI = "only";

	public void execute(DelegateExecution execution) throws Exception {

		String fileName = System.getProperty("VoltageServerConnection");
		System.out.println("fileName === " + fileName);

		String direction = (String) execution.getVariable(VoltageConstants.DIRECTION);
		//String payload = (String) execution.getVariable(AJSCVoltageCommonNames.PAYLOAD);
		String payload = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\"><SOAP-ENV:Header> <ns2:MessageHeader xmlns:ns2=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/MessageHeader.xsd\" xmlns=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd\"><ns2:TrackingMessageHeader><version>v104</version><messageId>CSTO_Mon_Jul_08_09-12-07_PDT_2013</messageId><originatorId>SBCWOW</originatorId><timeToLive>240000</timeToLive><conversationId>csitest~CNG-CSI~443fca48-dd07-41be-b803-83d8720fe5aa</conversationId><dateTimeStamp>2001-12-17T09:30:47.0Z</dateTimeStamp><uniqueTransactionId>ServiceGatewaynull@q24csg1c10_c02253e1-7fa9-45b6-84cb-9c0057336510</uniqueTransactionId></ns2:TrackingMessageHeader><ns2:SecurityMessageHeader><userName>csitest</userName><userPassword>testingcsi</userPassword></ns2:SecurityMessageHeader><ns2:SequenceMessageHeader><sequenceNumber>1</sequenceNumber><totalInSequence>1</totalInSequence></ns2:SequenceMessageHeader></ns2:MessageHeader></SOAP-ENV:Header> <SOAP-ENV:Body> <n2:AddFiberServiceCreditPolicyRequest xmlns:n2=\"http://csi.cingular.com/CSI/Namespaces/Container/Public/AddFiberServiceCreditPolicyRequest.xsd\" xmlns:n1=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd\" xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">      <n2:accountNumber>192329110</n2:accountNumber>      <n2:SalesCommision>        <n1:salesCode>pd9521</n1:salesCode>        <n1:userId></n1:userId>        <n1:location></n1:location>        <n1:salesChannel>COR</n1:salesChannel>        <n1:applicationName>CSI</n1:applicationName>        <n1:billingMarket>SAN</n1:billingMarket>      </n2:SalesCommision>      <n2:SecurityGuaranteeInformation>        <n2:PaymentType>          <n1:PaymentCardInformation>            <n1:creditCardType>VISA</n1:creditCardType>            <n1:creditCardNumber>4001331544181100</n1:creditCardNumber>            <n1:creditCardExpirationDate>1604</n1:creditCardExpirationDate>            <n1:creditCardCustomerName>Shanaya Sawe</n1:creditCardCustomerName>            <n1:amount>10</n1:amount>            <n1:recurringPaymentFlag>true</n1:recurringPaymentFlag>            <n1:accountType>Credit</n1:accountType>            <n1:zipCode>71105</n1:zipCode>            <n1:security>999</n1:security>          </n1:PaymentCardInformation>          <n1:debitOrCreditCard>Cr</n1:debitOrCreditCard>        </n2:PaymentType>        <n2:PaymentAcceptText>          <n1:name>0_2_18</n1:name>          <n1:description>For the Security Profile Credit Card Guarantee: You hereby authorize AT&amp;T to charge and/or place a hold on your credit card with respect to any unpaid charges for AT&amp;T U-verse Services or any related equipment. You authorize the issuer of the credit card to pay any amounts described herein without requiring a signed receipt, and you agree that these terms of service are to be accepted as authorization to the issuer of the credit card to pay all such amounts. You authorize AT&amp;T and/or any other company who bills products or services, or acts as billing agent for AT&amp;T to continue to attempt to charge and/or place holds with respect to all sums described herein, or any portion thereof, to your credit card until such amounts are paid in full</n1:description>        </n2:PaymentAcceptText>      </n2:SecurityGuaranteeInformation>      <n2:AutoPayProfile>        <n2:PaymentType>          <n1:PaymentCardInformation>            <n1:creditCardType>VISA</n1:creditCardType>            <n1:creditCardNumber>4001331544181100</n1:creditCardNumber>            <n1:creditCardExpirationDate>1604</n1:creditCardExpirationDate>            <n1:creditCardCustomerName>Shanaya Sawe</n1:creditCardCustomerName>            <n1:amount>10</n1:amount>            <n1:recurringPaymentFlag>true</n1:recurringPaymentFlag>            <n1:accountType>Credit</n1:accountType>            <n1:zipCode>71105</n1:zipCode>            <n1:security>999</n1:security>          </n1:PaymentCardInformation>          <n1:debitOrCreditCard>Cr</n1:debitOrCreditCard>        </n2:PaymentType>        <n2:PaymentAcceptText>          <n1:name>0_5_21</n1:name>          <n1:description>I authorize AT&amp;T and the specified financial institution to deduct the amount of my monthly AT&amp;T bill from the specified account. I understand my automatic payment will be deducted on the due date of each bill. I have the right to stop the recurring payment by notification to my financial institution at least five (5) business days prior to the effective date. My authorization and the AT&amp;T Direct Payment service will remain in full force and effect until revoked by me, my financial institution, or one of the AT&amp;T family of companies.</n1:description>        </n2:PaymentAcceptText>        <n2:optionalEnrollmentIndicator>false</n2:optionalEnrollmentIndicator>      </n2:AutoPayProfile>    </n2:AddFiberServiceCreditPolicyRequest></SOAP-ENV:Body> </SOAP-ENV:Envelope>";
		String serviceName = (String) execution.getVariable(VoltageConstants.INVOKE_SERVICE_NAME);
		String voltFlag = (String) execution.getVariable(VoltageConstants.VOLT_FLAG);
		String version = (String) execution.getVariable(VoltageConstants.VERSION);
		String application = (String) execution.getVariable(VoltageConstants.APPLICATION);
		String mergeFlag = (String) execution.getVariable(VoltageConstants.MERGE_FLAG);
		String currentVersion = (String) execution.getVariable(VoltageConstants.IS_CURRENT_VERSION);

		boolean volt = "true".equalsIgnoreCase(voltFlag) ? true : false;
		boolean currVersion = "true".equalsIgnoreCase(currentVersion) ? true : false;

		String result = null;
		if (mergeFlag != null) {
			if ("Request".equalsIgnoreCase(direction)) {
				if (volt) {
					result = UtilLib.voltRequestXMLByService(serviceName, payload, "", version, application,
							currVersion, mergeFlag);
				} else {
					result = UtilLib.unvoltRequestXMLByService(serviceName, payload, "", version, application,
							currVersion, mergeFlag);
				}
			} else {
				if (volt) {
					result = UtilLib.voltResponseXMLByService(serviceName, payload, "", version, application,
							currVersion, mergeFlag);
				} else {
					result = UtilLib.unvoltResponseXMLByService(serviceName, payload, "", version, application,
							currVersion, mergeFlag);
				}
			}
		}
		
		XmlValue resultXmlValue = SpinValues.xmlValue(result).create();
		execution.setVariable(VoltageConstants.PAYLOAD_WITH_ENCRYPTED_VALUES, resultXmlValue);
	}

}
