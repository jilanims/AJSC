package com.att.api.framework.ajsc.util;

import java.io.File;

import com.att.ssf.filemonitor.FileChangedListener;

/**
 *
 */
public class DMNRuleListener implements FileChangedListener {

	@Override
	public void update(File file) throws Exception {
		SimpleDMNRuleEngine.loadDMNRules(file);
	}

}
