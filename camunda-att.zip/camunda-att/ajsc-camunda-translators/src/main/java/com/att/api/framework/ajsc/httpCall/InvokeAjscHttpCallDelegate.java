package com.att.api.framework.ajsc.httpCall;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.engine.variable.Variables;

import com.att.aft.dme2.api.DME2Client;
import com.att.aft.dme2.api.DME2Exception;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.att.api.framework.ajsc.trace.Trace;
//import com.att.eelf.configuration.EELFLogger;
import com.att.masterendpoint.RefreshableServiceMasterEndPointOverrideMap;
import com.cingular.csi.csi.namespaces.types._private.implementation.masterendpointoverridemap.MasterEndpointInfo;

public class InvokeAjscHttpCallDelegate implements JavaDelegate{
	
	//private static EELFLogger LOG = AjscEelfManager.getInstance().getLogger(InvokeAjscHttpCallDelegate.class);
	private static Logger LOG = LoggerFactory.getLogger(InvokeAjscHttpCallDelegate.class);
	
	private String TTL = "36000";
	
	@Trace(message="Call invokeAjscHttpCallDelegate")
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		
		String processID = execution.getProcessInstanceId();
		
		LOG.info("process instance id is {} ",processID);
		
		Map<String, Object> requestMap = createRequestMapFromDelegateExecution(execution);
		String response = invokeHttpCall(requestMap);
		//execution.setVariable("ServiceResponse",response);
		execution.setVariable("ServiceResponse",Variables.objectValue(response).create());
	}
	
	private  String  invokeHttpCall(Map<String,Object> requestMap) throws Exception
	{
		DME2Client client;
		String response = null;
		try {
			setSystemProps();
			// As registered in GRM
			
			String pathParam = (String) requestMap.get("pathparam");
			String queryParam = (String) requestMap.get("queryparam");
			String serviceName =(String) requestMap.get("serviceName");
			String method = (String) requestMap.get("method");
			String payload = (String) requestMap.get("payload");
			String mepomLocation = System.getProperty("masterEndPointOverrideMap.location");
			File file = new File(mepomLocation);
			RefreshableServiceMasterEndPointOverrideMap.refresh(file );
			MasterEndpointInfo masterEndPointInfo = RefreshableServiceMasterEndPointOverrideMap.getMEPODMEUrlParts(serviceName);
			String envContext = masterEndPointInfo.getEnvContext();
			String routeOffer = masterEndPointInfo.getRouteOffer();
			String version = masterEndPointInfo.getVersion();
			if(envContext == null)
			{
				envContext = System.getProperty("envContext");
			}
			if(routeOffer == null)
			{
				routeOffer = System.getProperty("routeOffer");
			}
			if(version == null)
			{
				version = System.getProperty("version");
			}
			if(pathParam != null )
			{
				serviceName = serviceName + pathParam;
			}
			if(queryParam != null)
			{
				serviceName = serviceName + queryParam;
			}
			String clientUri = "http://DME2RESOLVE/service="+serviceName+"/version="+version+"/envContext="+envContext+"/routeOffer="+routeOffer;
			
			client = new DME2Client(new URI(clientUri),10000);
			
			client.setMethod(method);
			client.setPayload(payload);
			
			Map<String, String> headersMap = new HashMap<String, String>();
			headersMap.put("TTL", (String)requestMap.get("timeout"));
			client.setHeaders(headersMap);
			
			response= client.sendAndWait(10000);
			LOG.info("reply is: {}" , response);
		} catch (DME2Exception | URISyntaxException  e) {
			// TODO Auto-generated catch block
			throw e;
		}catch (Exception  e) {
			// TODO Auto-generated catch block
			throw e; 
		}
		return response;
	}
	
	private Map<String,Object> createRequestMapFromDelegateExecution(DelegateExecution execution)
	{
		Map<String,Object> requestMap = new HashMap<String,Object>();
		String serviceName = (String)execution.getVariable("serviceName");
		String version = (String)execution.getVariable("version");
		String envContext = (String)execution.getVariable("envContext");
		String routeOffer = (String) execution.getVariable("routeOffer");
		String payload = (String) execution.getVariable("payload");
		String method = (String) execution.getVariable("method");
		String timeout = (String)execution.getVariable("timeout");
		requestMap.put("serviceName",serviceName);
		requestMap.put("version",version);
		requestMap.put("envContext",envContext);
		requestMap.put("routeOffer",routeOffer);
		requestMap.put("payload",payload);
		requestMap.put("method", method);
		requestMap.put("timeout",timeout);
		requestMap.put("headers", getMapFromDelegateString((String) execution.getVariable("headers")));
		requestMap.put("pathparam",(String) execution.getVariable("pathparam"));
		requestMap.put("queryparam",(String) execution.getVariable("queryparam"));
		return requestMap;
	}
	
	private Map<String,String> getMapFromDelegateString(String delegateStringValue)
	{
		Map<String,String> delegateMap = new HashMap<String,String>();
		if(delegateStringValue != null && delegateStringValue.contains(","))
		{
			String[] splitHeader = delegateStringValue.split(",");
			if(splitHeader != null && splitHeader.length > 0)
			{
				for(int i = 0;i<splitHeader.length ;i++)
				{
					String delegatePair = splitHeader[i];
					if(delegatePair != null && delegatePair.contains("="))
					{
						String[] splitKeyValuePair = delegatePair.split("=");
						if(splitKeyValuePair != null  && splitKeyValuePair.length > 2)
						{
							delegateMap.put(splitKeyValuePair[0],splitKeyValuePair[1]);
						}
					}
				}
			}
		}
		return delegateMap;
	}
	
	
	
	private void setSystemProps() {

		System.setProperty("AFT_DME2_HTTP_EXCHANGE_TRACE_ON", "true");
		System.setProperty("AFT_LATITUDE", "20");
		System.setProperty("AFT_LONGITUDE", "30");
	}
}
