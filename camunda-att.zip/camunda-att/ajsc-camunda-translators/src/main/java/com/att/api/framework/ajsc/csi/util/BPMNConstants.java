package com.att.api.framework.ajsc.csi.util;

/**
 *
 */
public class BPMNConstants {
	
	public static final String _Parameters = "_Parameters";
	
	public static final String _Implementation = "_Implementation";
	
	public static final String _Input = "_Input";
	
	public static final String _Input_Variable1 = "_InputVarialbe1";
	
	public static final String _Input_Variable2 = "_InputVarialbe2";
	
	public static final String TIME_OUT = "TIME_OUT";
	
	public static final String _Output = "_Output";
	
	public static final String _Namespaces = "_Namespaces";
	
	public static final String _client_Partner = "_client_Partner";
	
	public static final String _service_Name = "_service_Name";
	
	public static final String _isConditionSatisfied = "_isConditionSatisfied";
	
	public static final String CONTIVO_TRANSFORM = "CONTIVO_TRANSFORM";
	
	public static final String SERVICE_NAME = "SERVICE_NAME";
	
	public static final String SERVICE_VERSION = "SERVICE_VERSION";
	
	public static final String REQUEST_QUEUE = "REQUEST_QUEUE";
	
	public static final String QUEUE_NAME = "QUEUE_NAME";
	
	public static final String MESSAGE_SELECTOR = "MESSAGE_SELECTOR";
	
	public static final String RESPONSE_QUEUE = "RESPONSE_QUEUE";
	
	public static final String ASYNC_REQUEST = "ASYNC_REQUEST";
	
	public static final String IS_FALLOUT = "IS_FALLOUT";
	
	public static final String STEP = "STEP";
	
	public static final String SUB_STEP = "SUB_STEP";
	
	public static final String PAYLOAD = "PAYLOAD";
	
	public static final String PROCESS_INSTANCE_ID = "PROCESS_INSTANCE_ID";
	
	public static final String ADAPTER_NAME = "ADAPTER_NAME";
	
	public static final String METHOD = "METHOD";
	
	public static final String CODE = "CODE";
	
	public static final String MESSAGE = "MESSAGE";
	
	public static final String FAULT_ENTITY = "FAULT_ENTITY";
	
	public static final String MESSAGE_HEADER = "MESSAGE_HEADER";
	
	public static final String PUBLIC_REQUEST = "PUBLIC_REQUEST";
	
	public static final String conversationId = "conversationId";
	
	public static final String FAULT = "FAULT";
	
	public static final String FALLOUT_RESPONSE = "FALLOUT_RESPONSE";
	
	public static final String CAMEL_EXCHANGE = "CAMEL_EXCHANGE";
	
	public static final String PERFORMANCE_TRACKER_BEAN = "PERFORMANCE_TRACKER_BEAN";
	
	public static final String FALLOUT_ACTION = "FALLOUT_ACTION";
	
	public static final String RETURN_QUEUE = "RETURN_QUEUE";
	
	public static final String GUID = "GUID";
	
	public static final String DESTINATION_ROUTEOFFER = "DESTINATION_ROUTEOFFER";
	
	public static final String PUBLIC_RESPONSE = "PUBLIC_RESPONSE";
	
	public static final String PUBLIC_EXCEPTION = "PUBLIC_EXCEPTION";
	
	public static final String XPATH = "XPATH";
	
	public static final String EXPRESSION = "EXPRESSION";
	
	public static final String VALUE = "VALUE";
	
	public static final String DMN_NAME = "DMN_NAME";
	
	public static final String DMN_RULE_HANDLER = "DMN_RULE_HANDLER";
	
	public static final String SOACLOUD_VERSION = "SOACLOUD_VERSION";
	
	public static final String STICKY_SELECTOR_KEY = "com.att.aft.dme2.jms.stickySelectorKey";
	
	public static final String defaultDME2EnvContext = "defaultDME2EnvContext";
	

}
