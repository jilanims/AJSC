package com.att.api.framework.ajsc.restService;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.engine.variable.Variables;

import com.att.aft.dme2.api.DME2Client;
import com.att.aft.dme2.api.DME2Exception;
import com.att.aft.gsm.handlers.GSMRequestHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
//import com.att.ajsc.logging.AjscEelfManager;
import com.att.api.framework.ajsc.trace.Trace;
//import com.att.eelf.configuration.EELFLogger;
import com.att.masterendpoint.RefreshableServiceMasterEndPointOverrideMap;
import com.cingular.csi.csi.namespaces.types._private.implementation.masterendpointoverridemap.MasterEndpointInfo;

public class InvokeAjscRestServiceDelegate implements JavaDelegate{
	
	//private static EELFLogger LOG = AjscEelfManager.getInstance().getLogger(InvokeAjscRestServiceDelegate.class);
	private static Logger LOG = LoggerFactory.getLogger(InvokeAjscRestServiceDelegate.class);
	public static final int DEFAULT_TIMEOUT = 240000;
	
	//private String TTL = "36000";
	private String isCrossReleaseSupported = "0"; // 1 true ; 0 false;
	
	private static final GSMRequestHandler requestHandler = new GSMRequestHandler();
	
	@Trace(message="Call invokeAjscRestServiceDelegate")
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		
		String processID = execution.getProcessInstanceId();
		
		LOG.info("process instance id is {} ",processID);
		
		Map<String, Object> requestMap = createRequestMapFromDelegateExecution(execution);
		requestMap.put("GSM_SESSION_KEY", processID);
		String response = invokeRestService(requestMap);
		//execution.setVariable("ServiceResponse",response);
		execution.setVariable("ServiceResponse",Variables.objectValue(response).create());
	}
	
	private  String  invokeRestService(Map<String,Object> requestMap) throws Exception
	{
		DME2Client client;
		String response = null;
		String envContext = null;
		String routeOffer= null;
		String version = null;
		
		try {
			//setSystemProps();
			// As registered in GRM
			
			String pathParam = (String) requestMap.get("pathparam");
			String queryParam = (String) requestMap.get("queryparam");
			String serviceName =(String) requestMap.get("serviceName");
			String method = (String) requestMap.get("method");
			String payload = (String) requestMap.get("payload");
			String subcontext = (String) requestMap.get("subContext");
			Map<String, String> headersMap = ( Map<String, String>) requestMap.get("headers");
			String mepomLocation = System.getProperty("masterEndPointOverrideMap.location");
			File file = new File(mepomLocation);
			RefreshableServiceMasterEndPointOverrideMap.refresh(file );
			MasterEndpointInfo masterEndPointInfo = RefreshableServiceMasterEndPointOverrideMap.getMEPODMEUrlParts(serviceName);
			if(masterEndPointInfo!=null) {
				envContext = masterEndPointInfo.getEnvContext();
				routeOffer = masterEndPointInfo.getRouteOffer();
				version = masterEndPointInfo.getVersion();
			}
			if(envContext == null)
			{
				envContext = System.getProperty("envContext");
			}
			if(routeOffer == null)
			{
				routeOffer = System.getProperty("routeOffer");
			}
			if(version == null)
			{
				version = System.getProperty("version");
			}
			if(pathParam != null )
			{
				serviceName = serviceName + pathParam;
			}
			if(queryParam != null)
			{
				serviceName = serviceName + queryParam;
			}
			String clientUri = "http://DME2RESOLVE/service="+serviceName+"/version="+version+"/envContext="+envContext+"/routeOffer="+routeOffer;

			client = new DME2Client(new URI(clientUri),10000);
			
			client.setMethod(method);
			
			if(subcontext != null ) {
				client.setSubContext(subcontext);
				
			}
			LOG.info("clientSubContext:" + subcontext);
			int timeoutMs = DEFAULT_TIMEOUT;
					
			if (requestMap.get("timeout") != null ) {
				timeoutMs = Integer.parseInt((String) requestMap.get("timeout"));
			}
//			headersMap.put("GSM_SESSION_KEY", sessionKey);
			
		//	headersMap.put("GSM_SESSION_KEY", (String)requestMap.get("GSM_SESSION_KEY"));
			
		//	headersMap.put("GSM_CROSS_VERSION_SUPPORT", isCrossReleaseSupported);
			headersMap.put("TTL", Integer.toString(timeoutMs));
			
		//	headersMap.put("AFT_DME2_EXCHANGE_REQUEST_HANDLERS","com.att.aft.gsm.handlers.GSMRequestHandler");
		//	headersMap.put("AFT_DME2_EXCHANGE_REPLY_HANDLERS","com.att.aft.gsm.handlers.GSMReplyHandler");
			

			
			if (("get".equalsIgnoreCase(method))
					|| ("delete".equalsIgnoreCase(method))) {
				client.setPayload("");
			} else {
				client.setPayload(payload);
				if(!headersMap.containsKey("Content-Length")) {
					headersMap.put("Content-Length", Integer.toString(payload.length()));
				}
			}
						
			client.setHeaders(headersMap);
			
			response= client.sendAndWait(timeoutMs);
			LOG.info("reply is: {}" , response);
		} catch (DME2Exception | URISyntaxException  e) {
			// TODO Auto-generated catch block
			throw e;
		}catch (Exception  e) {
			// TODO Auto-generated catch block
			throw e; 
		}
		return response;
	}
	
	private Map<String,Object> createRequestMapFromDelegateExecution(DelegateExecution execution)
	{
		Map<String,Object> requestMap = new HashMap<String,Object>();
		String serviceName = (String)execution.getVariable("serviceName");
		String version = (String)execution.getVariable("version");
		String envContext = (String)execution.getVariable("envContext");
		String routeOffer = (String) execution.getVariable("routeOffer");
		String payload = (String) execution.getVariable("payload");
		String method = (String) execution.getVariable("method");
		String timeout = (String)execution.getVariable("timeout");
		String subContext = (String)execution.getVariable("subContext");
		requestMap.put("subContext",subContext);
		requestMap.put("serviceName",serviceName);
		requestMap.put("version",version);
		requestMap.put("envContext",envContext);
		requestMap.put("routeOffer",routeOffer);
		requestMap.put("payload",payload);
		requestMap.put("method", method);
		requestMap.put("timeout",timeout);
		Map<String, String> headers = (Map<String, String>) getMapFromDelegateString((String) execution.getVariable("headers"));
		requestMap.put("headers", headers);
		requestMap.put("pathparam",(String) execution.getVariable("pathparam"));
		requestMap.put("queryparam",(String) execution.getVariable("queryparam"));
		return requestMap;
	}
	
	private Map<String,String> getMapFromDelegateString(String delegateStringValue)
	{
		Map<String,String> delegateMap = new HashMap<String,String>();
		if(delegateStringValue != null && delegateStringValue.contains(","))
		{
			String[] splitHeader = delegateStringValue.split(",");
			if(splitHeader != null && splitHeader.length > 0)
			{
				for(int i = 0;i<splitHeader.length ;i++)
				{
					String delegatePair = splitHeader[i];
					if(delegatePair != null && delegatePair.contains("="))
					{
						String[] splitKeyValuePair = delegatePair.split("=");
						if(splitKeyValuePair != null  && splitKeyValuePair.length == 2)
						{
							delegateMap.put(splitKeyValuePair[0],splitKeyValuePair[1]);
						}
					}
				}
			}
		}
		return delegateMap;
	}
	
	
	
	/*private void setSystemProps() {

		System.setProperty("AFT_DME2_HTTP_EXCHANGE_TRACE_ON", "true");
		System.setProperty("AFT_LATITUDE", "20");
		System.setProperty("AFT_LONGITUDE", "30");
	}*/
}