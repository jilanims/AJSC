package com.att.api.framework.ajsc.csi.util;


public class CamundaCommonVariableNames {
	
    public static final String MSG_CONVERSATION_ID = "ConversationID";

    public static final String MSG_UNIQUETRANSACTIONID = "UniqueTransactionID";

    public static final String MSG_USERNAME = "UserName";

    public static final String MSG_HEADER = "SoapMessageHeader";

    public static final String MSG_BODY = "SoapMsgBody";

    public static final String MSG_SERVICE_NAME = "callingServiceNamae";
    
    public static final String MSG_TIMETOLIVE = "TimeToLive";
   
    public static final String MSG_SEQUENCENUMBER = "SequenceNumber";
    
    public static final String MSG_TOTALINSEQUENCE = "TotalInSequence";
    
    public static final String MSG_VERSION = "version";
}
