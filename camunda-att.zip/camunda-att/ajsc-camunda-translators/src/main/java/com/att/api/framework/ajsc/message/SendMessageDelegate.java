package com.att.api.framework.ajsc.message;

import java.util.HashMap;
import java.util.Map;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.core.JmsTemplate;

import com.att.api.framework.ajsc.csi.util.BPMNConstants;
import com.att.api.framework.ajsc.csi.util.BPMNUtilities;
import com.att.api.framework.ajsc.csi.util.JMSSender;

/**
 *
 */
public class SendMessageDelegate implements JavaDelegate {

	
	private static final Logger logger = LoggerFactory.getLogger(SendMessageDelegate.class);
	
	private JmsTemplate jmsTemplate;
	
	public SendMessageDelegate(JmsTemplate jmsTemplate)
	{
		this.jmsTemplate = jmsTemplate;
	}
	
	
	@Override
	public void execute(DelegateExecution delegate) throws Exception
	{
		BPMNUtilities.logDelegate(delegate);
	
		String requestQueue = (String) delegate.getVariable(BPMNConstants.REQUEST_QUEUE);
		String isFallout =  (String) delegate.getVariable(BPMNConstants.IS_FALLOUT);
		String step = (String) delegate.getVariable(BPMNConstants.STEP);
		String responseQueue = (String) delegate.getVariable(BPMNConstants.RETURN_QUEUE);
		String inputVariable = (String) delegate.getVariable(BPMNConstants._Input) ;
		String request = (String)delegate.getVariable("InputRequest");

		Map<String, String> queueJmsProperties = getQueueJmsProperties(delegate);
		
		if("YES".equalsIgnoreCase(isFallout)){
			request = updateFalloutRequest(request, step, delegate.getProcessInstanceId());
			queueJmsProperties.put(BPMNConstants.GUID, delegate.getProcessInstanceId());
			JMSSender.sendToFallout(queueJmsProperties, requestQueue, responseQueue, request);
		}else{
			JMSSender.sendToJmsQueue(jmsTemplate, requestQueue,queueJmsProperties, request);
		}
		  
		BPMNUtilities.delegateCleanUp(delegate);
		logger.debug("execute():end");
		
	}
	
	private static String updateFalloutRequest(String request, String step, String conceptGUID){
		if(step != null){
			request = BPMNUtilities.setFalloutRequestVariable(request, "step", step);
		}
		return BPMNUtilities.setFalloutRequestVariable(request, "conceptGUID", conceptGUID);
	}
	
	private static Map<String, String> getQueueJmsProperties(DelegateExecution delegate){
		Map<String, String> propMap = new HashMap<String, String>();
		if(delegate != null)
		{
			if(delegate.getVariable(BPMNConstants._client_Partner) != null)
			{
				String clientPartner = (String) delegate.getVariable(BPMNConstants._client_Partner); 
				propMap.put(BPMNConstants._client_Partner, clientPartner);
			}
			if(delegate.getVariable(BPMNConstants.conversationId) != null)
			{
				String conversationId = (String) delegate.getVariable(BPMNConstants.conversationId); 
				propMap.put(BPMNConstants.conversationId, conversationId);
			}
			if(delegate.getVariable(BPMNConstants._service_Name) != null)
			{
				String callingService = (String) delegate.getVariable(BPMNConstants._service_Name); 
				propMap.put(BPMNConstants.SERVICE_NAME, callingService);
			}
			if(delegate.getVariable(BPMNConstants._Input_Variable1) != null)
			{
				String inputVariable1 = (String) delegate.getVariable(BPMNConstants._Input_Variable1); 
				propMap.put(BPMNConstants._Input_Variable1, inputVariable1);
			}
			if(delegate.getVariable(BPMNConstants._Input_Variable2) != null)
			{
				String inputVariable2 = (String) delegate.getVariable(BPMNConstants._Input_Variable2); 
				propMap.put(BPMNConstants._Input_Variable2, inputVariable2);
			}
		}
		return propMap;
	}
	
}