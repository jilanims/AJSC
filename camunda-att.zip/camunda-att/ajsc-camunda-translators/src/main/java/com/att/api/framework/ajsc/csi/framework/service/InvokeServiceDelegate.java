package com.att.api.framework.ajsc.csi.framework.service;


import java.util.HashMap;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.api.framework.ajsc.csi.util.FaultHelper;
import com.att.api.framework.ajsc.csi.util.XMLUtilities;
import com.att.api.framework.ajsc.fault.exception.UtilLib;
import com.att.api.framework.common.utils.CommonNames;

/**
 * @author jp931e
 *
 */
public class InvokeServiceDelegate implements JavaDelegate{

	public static final Long DEFAULT_TIMEOUT_MS = 1500L;
	public String callingServiceName=null, convId=null, uniqueId=null, partner=null;
	
	private static final Logger logger = LoggerFactory.getLogger(InvokeServiceDelegate.class);

	public enum CallType {
		ENTRY, EXIT
	};

	public void execute(DelegateExecution execution) throws Exception{		
		resetFields();
		
		String message =null, soapMessage= null;
		
		//set default response
		execution.setVariable(ServiceCommonNames.CSI_INVOKESERVICE_SERVICERESPONSE, "");
		
		HashMap<String,Object> invokeServiceVariables = null;
		try{
			
			message = XMLUtilities.convObjToXMLString(execution, ServiceCommonNames.CSI_INVOKESERVICE_SERVICEREQUEST);
			logger.info("CSI_INVOKESERVICE_SERVICEREQUEST:"+message);
			if (message == null || message.isEmpty()) {
				throw new Exception("Empty Request");
			}
			
			//check for JMSpayload, if yes then add the soap header	
			if(XMLUtilities.isXmlType(message, "Envelope", "http://schemas.xmlsoap.org/soap/envelope/")){
				soapMessage = message;
			}else if(!XMLUtilities.isJMSPayload(message)){
				String mhVersion = (String)execution.getVariable(ServiceCommonNames.CSI_INVOKESERVICE_VERSION);
				String mh = (String) execution.getVariable("SoapMessageHeader");				
				String updatedMh = XMLUtilities.updateVersion(mhVersion, mh);
				updatedMh.replace("/JMS/", "/");
				soapMessage = XMLUtilities.generateSoapStr(updatedMh, message);			
			}
			if(soapMessage==null){
				soapMessage = message;
			}
			
			logger.info("InvokeService request soap message:"+soapMessage);
			
			callingServiceName =(String) execution.getVariable(ServiceCommonNames.INVOKE_SERVICE_NAME);
			convId  = (String) execution.getVariable(CommonNames.HEADER_ATT_CONVERSATION_ID);
			uniqueId  = (String) execution.getVariable(CommonNames.HEADER_ATT_UNIQUE_TXN_ID);
			partner  = (String) execution.getVariable(ServiceCommonNames.PARTNER_PROFILE_CLIENT);
			
			Long timeLeft = 0L;
			String timeLeftStr = (String)execution.getVariable(ServiceCommonNames.CSI_INVOKESERVICE_TIMEOUT);
			if(!timeLeftStr.isEmpty()){
				timeLeft = Long.valueOf(timeLeftStr);
			}			
			if (timeLeft < 1500) {
				timeLeft = 1500L;
			}
			
			invokeServiceVariables = this.convertDelegateToMap(execution, soapMessage);
			
			//Invoke Service
			InvokeService2 invokeService = new InvokeService2();
			HashMap<String, Object> prvResponse = invokeService.invoke(invokeServiceVariables);
			String response = (String) prvResponse.get(ServiceCommonNames.CSI_INVOKESERVICE_SERVICERESPONSE);
			logger.info("response:"+response);			
			String fault = null;
			if("Envelope".equals(XMLUtilities.getRootElementName(response))){
				fault = FaultHelper.getFaultFromSoapFault(response);
			}else if("SoapFaultResponse".equals(XMLUtilities.getRootElementName(response))){
				fault = XMLUtilities.getContainerPayload(response);
			}else{
				//Set response xml			
				//execution.setVariable(ServiceCommonNames.CSI_INVOKESERVICE_SERVICERESPONSE, XMLUtilities.convLargeXMLtoObj(response));
				execution.setVariable(ServiceCommonNames.CSI_INVOKESERVICE_SERVICERESPONSE, XMLUtilities.convStringLargeXMLtoByteArray(response));				
				logger.info("InvokeService response message:");
				
			}
			
		}catch(Exception exception){
			throw new Exception(exception.getMessage());
		}		
		
	}
	
	private HashMap<String,Object> convertDelegateToMap(DelegateExecution delegate, String soapMessage) throws Exception{		
		HashMap<String,Object> mapVars = new HashMap<String,Object>();
		mapVars.put(CommonNames.TRANSACTION_STATE, UtilLib.getTransactionState(delegate));
		mapVars.put(CommonNames.HEADER_ATT_SERVICE_NAME, (String)delegate.getVariable(ServiceCommonNames.INVOKE_SERVICE_NAME));	
		//mapVars.put(ServiceCommonNames.INVOKE_SERVICE_NAME, (String)delegate.getVariable(ServiceCommonNames.INVOKE_SERVICE_NAME));
		mapVars.put(ServiceCommonNames.PARTNER_PROFILE_CLIENT, (String)delegate.getVariable(ServiceCommonNames.PARTNER_PROFILE_CLIENT));
		mapVars.put(ServiceCommonNames.CSI_INVOKESERVICE_SERVICEREQUEST, soapMessage);		
		mapVars.put(ServiceCommonNames.CSI_INVOKESERVICE_VERSION, (String)delegate.getVariable(ServiceCommonNames.CSI_INVOKESERVICE_VERSION));
		mapVars.put(ServiceCommonNames.CSI_INVOKESERVICE_NAME, (String)delegate.getVariable(ServiceCommonNames.CSI_INVOKESERVICE_NAME));		
		mapVars.put(ServiceCommonNames.CSI_INVOKESERVICE_TIMEOUT, (String)delegate.getVariable(ServiceCommonNames.CSI_INVOKESERVICE_TIMEOUT));
		
		mapVars.put(CommonNames.HEADER_ATT_CONVERSATION_ID, (String)delegate.getVariable(CommonNames.HEADER_ATT_CONVERSATION_ID));
		mapVars.put(CommonNames.HEADER_ATT_UNIQUE_TXN_ID, (String)delegate.getVariable(CommonNames.HEADER_ATT_UNIQUE_TXN_ID));
		return mapVars;
	}
	
	private void resetFields(){
		convId = null;
		uniqueId=null;
		partner=null;
		callingServiceName = null;
	}

}
