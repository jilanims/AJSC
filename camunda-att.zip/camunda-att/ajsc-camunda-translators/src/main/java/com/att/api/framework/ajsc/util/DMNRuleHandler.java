package com.att.api.framework.ajsc.util;

import java.util.List;
import java.util.Map;

/**
 *
 */
public interface DMNRuleHandler {
	
	public Map<String, Object> getRuleInputs(Object inputObject);
	
	public Object handleRuleOutput(Object inputObject, List<Map<String, Object>> resultList);

}
