package com.att.api.framework.ajsc.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.camunda.bpm.dmn.engine.DmnDecision;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.dmn.engine.DmnEngineConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 */
public class SimpleDMNRuleEngine {
	
	private static final Logger logger = LoggerFactory.getLogger(SimpleDMNRuleEngine.class);
	
	private	static Map<String, SimpleDMNRuleEngine> ruleEngineMap = new HashMap<String, SimpleDMNRuleEngine>();
	
	private static Object LOCK = new Object();
	
	public static List<Map<String, Object>> execute(String ruleEngineName, Map<String, Object> inputs){
		SimpleDMNRuleEngine simpleEngine = ruleEngineMap.get(ruleEngineName);
		List<Map<String, Object>> result = null;
		if(simpleEngine != null)
			result = simpleEngine.execute(inputs);
		else
			logger.debug("{} not found", ruleEngineName);
		return result;
	}
	
	public static void loadDMNRules(File file) throws FileNotFoundException{
		logger.debug("loadDMNRules():start");
		SimpleDMNRuleEngine dmnRuleEngine = new SimpleDMNRuleEngine(file);
		synchronized (LOCK) {
			ruleEngineMap.put(file.getName().replace(".dmn", ""), dmnRuleEngine);
		}
		logger.debug("loadDMNRules():end");
	}
	
	private DmnEngine dmnEngine = null;
	
	private DmnDecision decision = null;
	
	private SimpleDMNRuleEngine(File file) throws FileNotFoundException {
		InputStream inputStream = null;
		try {
			inputStream = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			logger.error(e.getMessage(), e);
			throw e;
		}
		DmnEngineConfiguration configuration = DmnEngineConfiguration.createDefaultDmnEngineConfiguration();
		this.dmnEngine = configuration.buildEngine();
		List<DmnDecision> decisions = this.dmnEngine.parseDecisions(inputStream);
		this.decision = decisions.get(0);
	}
	
	private List<Map<String, Object>> execute(Map<String, Object> inputs){
		List<Map<String, Object>> result = null;
		if (this.decision != null && this.decision.isDecisionTable()) {
			logger.debug("{} INPUT {}", decision.getName(), inputs);
			result = this.dmnEngine.evaluateDecisionTable(this.decision, inputs).getResultList();
			logger.debug("{} OUTPUT {}", decision.getName(), result);
		}
		return result;
	}

}
