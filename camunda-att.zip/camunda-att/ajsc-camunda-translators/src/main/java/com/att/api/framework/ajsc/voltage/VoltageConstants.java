package com.att.api.framework.ajsc.voltage;

public class VoltageConstants {
	public static final String DIRECTION = "DIRECTION";
	public static final String PAYLOAD = "PAYLOAD";
	public static final String VOLT_FLAG = "VOLT_FLAG";
	public static final String VERSION = "VERSION";
	public static final String APPLICATION = "APPLICATION";
	public static final String INVOKE_SERVICE_NAME = "INVOKE_SERVICE_NAME";
	public static final String MERGE_FLAG = "MERGE_FLAG";
	public static final String IS_CURRENT_VERSION = "IS_CURRENT_VERSION";
	public static final String PAYLOAD_WITH_ENCRYPTED_VALUES = "PAYLOAD_WITH_ENCRYPTED_VALUES";
}
