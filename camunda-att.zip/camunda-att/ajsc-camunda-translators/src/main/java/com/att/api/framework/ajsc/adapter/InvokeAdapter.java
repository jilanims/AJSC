package com.att.api.framework.ajsc.adapter;


import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Future;

import org.springframework.stereotype.Component;

//import com.att.ajsc.logging.AjscEelfManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.att.api.framework.ajsc.csi.framework.service.ServiceCommonNames;
import com.att.api.framework.ajsc.trace.Trace;
import com.att.api.framework.common.adapter.AdapterMap;
import  com.att.api.framework.common.adapter.LoadAdapterMap;
import com.att.api.framework.common.adapter.MAFApiTransImpl;
import com.att.api.framework.common.adapter.MAFInlineAdapter;
import com.att.api.framework.common.adapter.MAFRemoteAdapter;
import com.att.api.framework.common.logging.APITransactionLogger;
import com.att.api.framework.common.logging.PerformanceTrackingRecord;
import com.att.api.framework.common.logging.PerformanceTrackingTrailMark;
import com.att.api.framework.common.logging.TransactionLogger;
import com.att.api.framework.common.state.api.AJSCTransactionStateImpl;
import com.att.api.framework.common.utils.CommonNames;
import com.att.api.framework.common.utils.CommonUtil;
import com.att.api.framework.jaxb.requestparameters.RequestParameters;
//import com.att.eelf.configuration.EELFLogger;
import com.att.env.APIException;
import com.att.m2e.csi.common.exceptions.CSIControlException;

/**
 * @author jp931e
 *
 */

@Component(InvokeAdapter.COMPONENT_NAME)
public class InvokeAdapter{
	
	//private static EELFLogger LOGGER = AjscEelfManager.getInstance().getLogger(InvokeAdapter.class);
	private static Logger LOGGER = LoggerFactory.getLogger(InvokeAdapter.class);
	public static final String COMPONENT_NAME = "InvokeAdapter";
	private String inputAdapter;
	private String inputAdapterMethod;	
	private String adapterName;
	private String adapterMethod;
	
	private String callingServiceName = null, convId = null, userName =null;
	private long minTimeout = 2000;
	
	private static final String DEFAULT_AJSC_CAMUNDA_INSTANCE_NAME = "UNSPECIFIED_AJSC_CAMUNDA_INSTANCE";
	
	
	private static HashMap<String, AdapterMap> adapterHashMap = new HashMap<String, AdapterMap>();
	
	public enum CallType {
		ENTRY, EXIT
	};
		
	/*static {
		LoadAdapterMap loadAdapterMap = new LoadAdapterMap();
	}*/
	
	

	//@Trace(message = "Call InvokeAdapter")
	public HashMap<String,Object> invoke(HashMap<String,Object> mapVars) throws Exception {

		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("********Start InvokeAdapterDelegate**********");
		}

		resetFields();		

		AJSCTransactionStateImpl state = (AJSCTransactionStateImpl)mapVars.get(CommonNames.TRANSACTION_STATE);
		PerformanceTrackingRecord tracking = state.getTrackingRecord();

		callingServiceName = (String)mapVars.get(CommonNames.HEADER_ATT_SERVICE_NAME);
		//Operational Parameters
		userName = (String) mapVars.get(AdapterCommonNames.PARTNER_PROFILE_CLIENT);
		if(userName==null || userName==""){
			userName ="ajscUser"; //default user
		}
		//This was only being used by introscope calls , hence commented out
		//String uniqueID = (String)mapVars.get(CommonNames.HEADER_ATT_UNIQUE_TXN_ID);	
		String message = (String)mapVars.get(AdapterCommonNames.CSI_INVOKEADAPTER_PRVREQUEST);


		LOGGER.info("Invoke adapter message: {}",message);

		if (message == null) {
			throw new Exception("Empty Adapter Private Request");
		}

		String messageHeader = (String)mapVars.get(AdapterCommonNames.CSI_INVOKEADAPTER_MESSAGEHEADER);


		LOGGER.info("Invoke adapter message header:"+messageHeader);

		if (messageHeader == null || messageHeader.isEmpty()) {
			throw new Exception("Empty MessageHeader");
		}			

		Object prvResponse = null;		
		PerformanceTrackingTrailMark trailMark = tracking.addTrailMark(COMPONENT_NAME);
		try {
			// Grab a new AjscTransImpl
			MAFApiTransImpl trans = getAjscTransImpl(mapVars, state, callingServiceName);	

			String versionApplEnv = System.getProperty(CommonNames.VERSION_ROUTEOFFER_ENVCONTEXT);		
			String[] splitInstance = versionApplEnv.split("\\/");
			String version = splitInstance[0];
			String defaultEnvContext = splitInstance[2];
			String stickySelectorKey = splitInstance[1];


			// Get the adapter call mode from Adapter.map and determine inline or remote
			String handlerName = trans.logger.getDownstreamSystem() + '-' + trans.logger.getMethodName(); //adapterMethodName;
			adapterHashMap = LoadAdapterMap.getAdaptersMap();
			AdapterMap info = adapterHashMap.get(handlerName);			
			boolean isInlineMAF	= false;
			if (info != null ) {
				isInlineMAF = info.remoteCallType.equals("MAFINLINE");
			}

			if(isInlineMAF){ // Call MAFInline
				Object responseObject = MAFInlineAdapter.invokeAdapter(trans, message);				
				prvResponse = responseObject; 
			}else if(message instanceof String){ //call MAFRemote
				Future<String> responseFutureObject =  MAFRemoteAdapter.invokeAdapter(trans,  message.toString(), userName, defaultEnvContext, version, stickySelectorKey );
				prvResponse = responseFutureObject.get();				
			}else{
				throw new APIException("Input request message is not an String");
			}

		} catch (APIException apie) {	// Anand : TODO : Need to do the necessary changes when AJSC error / exception handling stories are completed.			
			throw apie;				
		}catch (Exception e) {			
			throw new APIException(e);				
		} finally {	
			trailMark.done();			
		}

		LOGGER.info("Invoke Adapter Response message:{}",prvResponse);	
		mapVars.put(AdapterCommonNames.CSI_INVOKEADAPTER_PRVRESPONSE, prvResponse); 
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("********End InvokeAdapterDelegate**********");
		}
		return mapVars;
	}
		
	/**
	 * @param exchange
	 * @param perfTrackerBean
	 * @param callingServiceName
	 * @return MAFAjscTransImpl
	 * @throws Exception
	 */
	private MAFAjscTransImpl getAjscTransImpl(HashMap<String,Object> mapVars, AJSCTransactionStateImpl transState, String callingServiceName)
	throws Exception {
		
		TransactionLogger logger = new APITransactionLogger(callingServiceName);
		RequestParameters reqParam = ((AJSCTransactionStateImpl)transState).getRequestParameters();
				
		String mode = (String)mapVars.get(AdapterCommonNames.CSI_INVOKEADAPTER_MODE);    	
    	if (mode == null  ||  mode.isEmpty())
    	{
    		mode = "";
    	};		
		/*String serviceKeyData1 = (String)mapVars.get(AJSCCommonNames.CSI_INVOKEADAPTER_SVCKEYDATA1);    	
    	if (serviceKeyData1 == null  ||  serviceKeyData1.isEmpty())
    	{
    		serviceKeyData1 = "";
    	}
    	
		String serviceKeyData2 = (String)mapVars.get(AJSCCommonNames.CSI_INVOKEADAPTER_SVCKEYDATA2);    	
    	if (serviceKeyData2 == null  ||  serviceKeyData2.isEmpty())
    	{
    		serviceKeyData2 = "";
    	}*/
    	
	    adapterName = (String)mapVars.get(AdapterCommonNames.CSI_ADAPTER_NAME);		
	    if (adapterName == null || adapterName.isEmpty()) {
			adapterName = inputAdapter;
		}
		
	    adapterMethod = (String)mapVars.get(AdapterCommonNames.CSI_ADAPTER_METHOD);		
		if (adapterMethod == null || adapterMethod.isEmpty()) {
			adapterMethod = inputAdapterMethod;
		}
		
	    String messageHeader = (String)mapVars.get(AdapterCommonNames.CSI_INVOKEADAPTER_MESSAGEHEADER);
	    String ban = (String)mapVars.get(AdapterCommonNames.CSI_INVOKEADAPTER_BAN);
		if (ban == null || ban.isEmpty()) {
			ban = "N/A";
		}
		
	    String subscriber = (String)mapVars.get(AdapterCommonNames.CSI_INVOKEADAPTER_SUBSCRIBER); // subscriber is required only for MAFRemote only
		if (subscriber == null || subscriber.isEmpty()) {
			subscriber = "N/A";
		}		
				
		String key, ttl = null, timeStamp=null, serviceKeyData1 = "", serviceKeyData2 = "";	
		if(reqParam.getHeader()!=null){
	    	for (int i=0; i<reqParam.getHeader().getPair().size(); i++) {
				key = reqParam.getHeader().getPair().get(i).getKey();
				if (key.equalsIgnoreCase(CommonNames.SERVICE_KEY_DATA1))
					serviceKeyData1 = reqParam.getHeader().getPair().get(i).getValue();
				else if (key.equalsIgnoreCase(CommonNames.SERVICE_KEY_DATA2))
					serviceKeyData2 = reqParam.getHeader().getPair().get(i).getValue();			
				else if (key.equalsIgnoreCase(CommonNames.HEADER_ATT_TIME_TO_LIVE))
					ttl = reqParam.getHeader().getPair().get(i).getValue();
				else if (key.equalsIgnoreCase(CommonNames.HEADER_ATT_CONVERSATION_ID))
					convId = reqParam.getHeader().getPair().get(i).getValue();
				else if (key.equalsIgnoreCase(CommonNames.HEADER_ATT_DATE_TIME_STAMP))
					timeStamp = reqParam.getHeader().getPair().get(i).getValue();
				else if (key.equalsIgnoreCase(CommonNames.CSI_USER_NAME))
					userName = reqParam.getHeader().getPair().get(i).getValue(); 
				else if (key.equalsIgnoreCase(CommonNames.HTTP_AUTHORIZATION)) {
					String authHeader = reqParam.getHeader().getPair().get(i).getValue();
					if (authHeader != null) {
						userName = CommonUtil.extractUserNameFromHeader(authHeader);
					}
				}
			}
		}
    	// if the converstionid is not available in the header then get it from exchange....
		if(userName==null){
			userName = (String)mapVars.get(ServiceCommonNames.PARTNER_PROFILE_CLIENT);
		}
		if(convId == null) {
			convId = (String)mapVars.get(CommonNames.HEADER_ATT_CONVERSATION_ID);
		}
	    Map<String, String> mdlProps = (Map<String, String>)mapVars.get(AdapterCommonNames.CSI_INVOKEADAPTER_MDL);
	    
	    long timeLeft;
	    long timeToLive;
	    
	    Object tempTimeLeft = (Object)mapVars.get(AdapterCommonNames.CSI_INVOKEADAPTER_TIMEOUT);
		long stime = 0L;
		
		if (tempTimeLeft == null) {
			timeLeft = 0;
		} else {
			timeLeft = Long.valueOf(tempTimeLeft.toString());
		}
		
		if (timeLeft < minTimeout) {			
			if(timeStamp!=null){
				stime = Long.parseLong(timeStamp);
			}
			timeLeft = Long.parseLong(ttl) - (System.nanoTime()/1000000 - stime);
		}	    
		timeToLive = timeLeft + System.currentTimeMillis();

		String instanceName = DEFAULT_AJSC_CAMUNDA_INSTANCE_NAME;
		logger.setConversationId(convId);
		logger.setEngine(instanceName);		
		logger.setServiceName(callingServiceName);
		logger.setMethodName(adapterMethod);
		logger.setDownstreamSystem(adapterName);	
		logger.setGuid("");
		
		try {
			
			MAFAjscTransImpl trans = new MAFAjscTransImpl(logger);		
			
			trans.setBan(ban);
			trans.setSubscriber(subscriber);
			trans.setTimeout(Long.toString(timeLeft));//Need timeleft	
			trans.setMessageHeader(messageHeader);  
			
			HashMap<String, String> mdlProperties = (HashMap<String, String>)mdlProps;
			trans.setMDLProperties(mdlProperties);
			trans.setMode(mode);
			trans.setServiceKeyData1(serviceKeyData1);
			trans.setServiceKeyData2(serviceKeyData2);
			trans.setClientApp("AJSCCAMUNDA-CSI~"+instanceName +"~"+callingServiceName);
			trans.setServiceName(callingServiceName);
			trans.setOverridedLastMoment(timeToLive); //Need timeleft+ System.currentTimeMillis();			
			return trans;
		
		}
		catch (Exception e) {
			
			CSIControlException csiex = null;				
			if (e.getCause() instanceof CSIControlException){
				csiex = (CSIControlException)e.getCause();					
			} else{
				csiex = new CSIControlException(e);
			}
			LOGGER.error(e.getMessage());
			throw csiex;
		}
	}

	
	private void resetFields(){
		convId = null;
		userName =null;
		callingServiceName = null;
	}
	
	public String getAdapter() {
		return inputAdapter;
	}

	
	public void setAdapter(String adapter) {
		this.inputAdapter = adapter;
	}
	
	public String getAdapterMethod() {
		return inputAdapterMethod;
	}
	
	public void setAdapterMethod(String adapterMethod) {
		this.inputAdapterMethod = adapterMethod;
	}

}
