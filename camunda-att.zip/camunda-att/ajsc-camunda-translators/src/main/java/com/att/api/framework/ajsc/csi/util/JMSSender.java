package com.att.api.framework.ajsc.csi.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import com.att.api.framework.ajsc.csi.util.BPMNConstants;
//import com.att.ajsc.csi.framework.adapter.RefreshableAdapterDME2UrlMap;
//import com.att.ajsc.csi.logging.PerformanceTrackingBean;
//import com.att.ajsc.csi.util.PerformanceTrackerUtil.CallType;
import com.att.masterendpoint.RefreshableServiceMasterEndPointOverrideMap;

/**
 *
 */
public class JMSSender {
	
	private static final Logger logger = LoggerFactory.getLogger(JMSSender.class);
	
	
	@Autowired
	private static JmsTemplate jmsTemplate;
	
	public static Map<String, String> getDme2JmsDynamicProperties(String instanceName,
			String sourceService, 
			String[] dme2Url,
			String partner, 
			String uniqueTransactionId,
			long timeLeft){
		partner = dme2Url[1] != null ? dme2Url[1]: partner;
		Map<String, String> propMap = new HashMap<String, String>();
		propMap.put("GUID", uniqueTransactionId);
		propMap.put("ClientDME2Lookup", dme2Url[0] + "?Partner=" + partner + "&StickyKey=" + System.getProperty(BPMNConstants.STICKY_SELECTOR_KEY));
		propMap.put("com.att.aft.dme2.jms.partner", partner); 
		propMap.put("ClientApp", "AJSC-CSI~" + instanceName + "~" + sourceService);
		propMap.put("TimeToLive", Long.toString(timeLeft));
		return propMap;
	}
	
	public static Map<String, String> getDme2JmsProperties(String instanceName,
			String sourceService, 
			String[] dme2Url,
			String partner, 
			String uniqueTransactionId,
			long timeLeft){
		Map<String, String> propMap = getDme2JmsStaticProperties();
		propMap.putAll(getDme2JmsDynamicProperties(instanceName, sourceService, dme2Url, partner, uniqueTransactionId, timeLeft));
		return propMap;
	}
	
	public static Map<String, String> getDme2JmsStaticProperties(){
		Map<String, String> propMap = new HashMap<String, String>();
		propMap.put("com.att.aft.dme2.jms.stickySelectorKey",System.getProperty(BPMNConstants.STICKY_SELECTOR_KEY));
		propMap.put("VoltageEnabledIndicator","false");
		propMap.put("com.att.aft.dme2.jms.matchVersionRange","true");
		propMap.put("accept-encoding","gzip");
		propMap.put("SoapVersion", "NA");
		return propMap;
	}

	
	private static Map<String, String> getFomJmsProperties(String conversationId,
			String callingServiceName,
			String responseQueue,
			String processId) {
		Map<String, String> propMap = new HashMap<String, String>();
		propMap.put(BPMNConstants.RETURN_QUEUE, responseQueue);
		propMap.put(BPMNConstants.GUID, processId);
		propMap.put(BPMNConstants.DESTINATION_ROUTEOFFER, System.getProperty(BPMNConstants.SOACLOUD_VERSION));
		propMap.put(BPMNConstants.SERVICE_NAME, callingServiceName);
		propMap.put(BPMNConstants.conversationId, conversationId);
		return propMap;
	}
	
	private static Map<String, String> getWmqJmsProperties(String conversationId,
			String callingServiceName, 
			String partner){
		Map<String, String> propMap = new HashMap<String, String>();
		propMap.put(BPMNConstants.conversationId, conversationId);
		return propMap;
	}
	
//	private static boolean isAdapterRequest(String requestXml){
//		return XMLUtilities.isXmlType(requestXml, "AdapterRequest", "http://csi.cingular.com/CSI/Namespaces/Types/Private/AdapterRequest.xsd");
//	}

	public static String receive(JmsTemplate jmsTemplate, final String queueName, final String messageSelector) throws JMSException{
		jmsTemplate.setReceiveTimeout(120);
		Message response = jmsTemplate.receiveSelected(queueName, messageSelector);
		String respXML = TextMessage.class.isInstance(response) ? ((TextMessage) response).getText(): null;
		logger.debug("Queue {} MessageSelector {} MessagePicked {}", queueName, messageSelector, respXML);
		return respXML;
	}

	private static void send(JmsTemplate jmsTemplate, final String queueName, final Map<String, String> propMap, final String payload){
		jmsTemplate.send(queueName, new MessageCreator() {
			@Override
			public Message createMessage(Session session) throws JMSException {
				TextMessage message = session.createTextMessage(payload);
				message.setJMSCorrelationID(propMap.get(BPMNConstants.conversationId));
				message.setJMSMessageID(propMap.get(BPMNConstants.conversationId));
				setMessageProperties(message, propMap);
				logger.debug("Sending One-way message over {}  using payload {}", queueName, payload);
				return message;
			}
		});
	}
	
	private static String sendAndReceive(JmsTemplate jmsTemplate, final String queueName, final Map<String, String> propMap, final String payload) throws JMSException{
		Message response = jmsTemplate.sendAndReceive(queueName, new MessageCreator() {
			@Override
			public Message createMessage(Session session) throws JMSException {
				TextMessage message = session.createTextMessage(payload);
				message.setJMSReplyTo(session.createTemporaryQueue());
				setMessageProperties(message, propMap);
				logger.debug("Sending message over {}  using payload {}", queueName, message.getText());
				return message;
			}
		});
		String respXML = TextMessage.class.isInstance(response) ? ((TextMessage) response).getText(): null;
		logger.debug("Queue {} Response {}", queueName, respXML);
		return respXML;
	}
	
	private static TextMessage setMessageProperties(TextMessage message, Map<String, String> propMap){
		Set<Entry<String, String>> entrySet = propMap.entrySet();
		for (Iterator<Entry<String, String>> iterator = entrySet.iterator(); iterator.hasNext();) {
			Entry<String, String> entry = iterator.next();
			try {
				if(entry.getKey() != null && entry.getValue() != null)
					message.setStringProperty(entry.getKey(), entry.getValue());
			} catch (JMSException exception) {
				logger.error(exception.getMessage(), exception);
			}
		}
		return message;
	}
	
	private static JmsTemplate fomJmsTemplate = null;

	public static void sendToFallout(Map<String, String> jmsProps ,
			String requestQueue,
			String responseQueue,
			String payload) {
		send(fomJmsTemplate, requestQueue, jmsProps, payload);
	}
	
	public static void sendToJmsQueue(JmsTemplate tempJmsTemplate,
			String requestQueue, 
			Map<String, String> jmsProps,
			String payload) {
		jmsTemplate = tempJmsTemplate;
		send(tempJmsTemplate, requestQueue, jmsProps, payload);
	}

}
