package com.att.api.framework.ajsc.fault.exception;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.att.api.framework.ajsc.csi.framework.service.ServiceCommonNames;
import com.att.api.framework.common.logging.PerformanceTrackingRecord;
import com.att.api.framework.common.state.api.AJSCTransactionStateImpl;
import com.att.api.framework.jaxb.requestparameters.RequestParameters;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.ResponseInfo;
import com.cingular.csi.csi.namespaces.types._public.errorresponse.CSIApplicationException;
import com.cingular.csi.csi.namespaces.types._public.errorresponse.ServiceEntityFaultInfo;
import com.cingular.csi.csi.namespaces.types._public.messageheader.MessageHeaderInfo;
import com.cingular.csi.csi.namespaces.types._public.soapfault.FaultInfo;
import com.cingular.csi.csi.namespaces.types._public.soapfault.ObjectFactory;
import com.att.api.framework.common.security.utils.XXESettingUtils;
import groovy.lang.GroovyClassLoader;
import groovy.lang.GroovyObject;

public class UtilLib {
	
	private static GroovyObject groovyObj = null;

	public static GroovyObject getInstance() {
		
		if (groovyObj == null) {
			try {
				//String AJSC_HOME = System.getProperty("AJSC_HOME");
				//File caetGroovyFile = new File(AJSC_HOME+"/etc/ErrorMessageParse.groovy");
				File caetGroovyFile = new File("etc/config/ErrorMessageParse.groovy");
				Class scriptClass = new GroovyClassLoader().parseClass(caetGroovyFile) ;
				groovyObj = (GroovyObject) scriptClass.newInstance();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}		
		return groovyObj;
	}
	
	public static String getClientApp (String serviceName) {
		String instanceName = "UNSPECIFIED_AJSC_INSTANCE";
		return "AJSC-CSI~"+instanceName+"~"+serviceName;
	}	
	
	// Generate Invoke Service Fault Standard Response xml
	public static String generateRespFaultRequest(DelegateExecution execution, String orgSoapMessage)throws Exception{
	 	//String message = (String)execution.getVariable(ServiceCommonNames.CSI_INVOKESERVICE_SERVICEREQUEST);
	 	String orgSoapHeader = UtilLib.getSOAPHeader(orgSoapMessage);
		
		Object[] args = new Object[] {orgSoapHeader};
		return getInstance().invokeMethod("appendHeaderToSoapFaultFile", args).toString();					    
	}
	
	public static String generateCAETRequest(Object[] args)throws Exception{	 		
		/*String AJSC_HOME = System.getProperty("AJSC_HOME");
		File caetGroovyFile = new File(AJSC_HOME+"/etc/ErrorMessageParse.groovy");
		Class scriptClass = new GroovyClassLoader().parseClass(caetGroovyFile) ;
		GroovyObject groovyObj = (GroovyObject) scriptClass.newInstance();*/
		//Object[] args = new Object[] {"CSI","Echo",caetErrorCode,caetErrorDesc,"N","AJSC",perfTrackerBean.getConversationId()};		
		return getInstance().invokeMethod("parseRequestTemplateFile", args).toString();	
	}
	
	public static HashMap<String,Object> setCAETMapVariables(String callingServiceName, String caetRequestxml){
		
		Long timeoutMs = 0L;
		try {
			timeoutMs= Long.valueOf(System.getProperty("caet.service.timeout"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		
		if (timeoutMs.equals(0L)){
			timeoutMs = 1500L;
		}		
		
		HashMap<String,Object> caetVariables = new HashMap<String,Object>();
		//caetVariables.put(ServiceCommonNames.PERFORMANCE_TRACKER_BEAN, perfTrackerBean);
		caetVariables.put(ServiceCommonNames.INVOKE_SERVICE_NAME, callingServiceName);
		caetVariables.put(ServiceCommonNames.CSI_INVOKESERVICE_TIMEOUT, timeoutMs);
		caetVariables.put(ServiceCommonNames.CSI_INVOKESERVICE_NAME, System.getProperty("caet.service.name"));
		caetVariables.put(ServiceCommonNames.CSI_INVOKESERVICE_VERSION, System.getProperty("caet.service.version"));
		caetVariables.put(ServiceCommonNames.CSI_INVOKESERVICE_SERVICEREQUEST, caetRequestxml);
		return caetVariables;
	}
	
	@SuppressWarnings("unchecked")
	public static String getFaultResponseCode(String xml) throws IOException, SOAPException {
		String faultResponseCode = null;
		if(xml!=null && xml.trim().length()>0){
			
			MessageFactory factory = MessageFactory.newInstance();
			SOAPMessage msg = null;
			try{
		     msg = factory.createMessage(new MimeHeaders(), new ByteArrayInputStream(xml.getBytes(Charset.forName("UTF-8"))));
			}catch(Exception e){
				e.printStackTrace();
			}
		    msg.saveChanges();
		    SOAPBody soapBody = msg.getSOAPBody();
		   
		    for (Element response : elements(soapBody.getElementsByTagNameNS("http://schemas.xmlsoap.org/soap/envelope/", "Fault"))) {
		      for (Element result : elements(response.getElementsByTagName("detail"))) {
		    	  for (Element result1 : elements(response.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/SoapFaultDetails.xsd", "CSIApplicationException"))) {
		    	        
		    		  for (Element result2 : elements(response.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/ErrorResponse.xsd","Response"))) {
		    			  
		      	        List<Element> resultDataChildren = elements(result2.getChildNodes());
		      	        faultResponseCode = named(resultDataChildren.get(0), "code").getTextContent();		      	         
		      	        System.out.println("code:"+faultResponseCode);
		      	        String description =named(resultDataChildren.get(1), "description").getTextContent();
		      	        System.out.println("description:"+description);
		      	        break;
		    		  }
		    	  }
		      	}
		      }			
		}
		return faultResponseCode;
	}
	
	/*public static boolean checkFaultCode(String xml){
		
		while (xmlStreamReader.hasNext()) {
		    int event = xmlStreamReader.next();

		    if (event == XMLStreamConstants.START_ELEMENT) {
		        try {
		            String text = xmlStreamReader.getElementText();
		            System.out.println("Element Local Name:" + xmlStreamReader.getLocalName());
		            System.out.println("Text:" + text);
		        } catch (XMLStreamException e) {

		        }
		    }

		}
	}*/
	private static List<Element> elements(NodeList nodes) {
	    List<Element> result = new ArrayList<Element>(nodes.getLength());
	    for (int i = 0; i < nodes.getLength(); i++) {
	      Node node = nodes.item(i);
	      if (node instanceof Element)
	        result.add((Element)node);
	    }
	    return result;
	  }

	  private static Element named(Element elem, String name) {
	    if (!elem.getNodeName().equals(name))
	      throw new IllegalArgumentException("Expected " + name + ", got " + elem.getNodeName());
	    return elem;
	  }
	  
	  
	  public static String getSOAPHeader(String soapXml){
			return getSOAPHeader(getSOAPMessage(soapXml));
		}
		
		public static SOAPMessage getSOAPMessage(String soapXml){
			SOAPMessage message = null;
			try {
				message = MessageFactory.newInstance().createMessage(null, new ByteArrayInputStream(soapXml.getBytes()));
			} catch (IOException | SOAPException e) {
				e.printStackTrace();
			}
			return message;
		}
		
		public static String getSOAPHeader(SOAPMessage message){
			String header = null;
			try {
				header =   getChildString(message.getSOAPHeader().getChildElements());
			} catch (SOAPException e) {
				e.printStackTrace();
			}
			return header;
		}
		
		private static String getChildString(Iterator<?> iterator)
		{
			StringWriter sw = new StringWriter();
			try {
				while (iterator.hasNext()) {
					Node node = (Node) iterator.next();
					if (node.getNodeType() == Node.ELEMENT_NODE) {
						Element ele = (Element) node;
						TransformerFactory tf = TransformerFactory.newInstance();
						XXESettingUtils.setTransformerFactoryXXE(tf);
						tf.newTransformer().transform(new DOMSource(ele), new StreamResult(sw));
						break;
					}
				}
			} catch (TransformerException | TransformerFactoryConfigurationError e) {
				e.printStackTrace();
			}
			sw.flush();
			return sw.toString();
		}
		
		public static final String UTF8_BOM = "\uFEFF";
		
		private static String trim(String xml){
			if (xml.startsWith(UTF8_BOM)) {
				xml = xml.substring(1);
	        }
			return xml;
		}
	
		public static String generateSoapFaultResponseXML(String code, String desc, String serviceFaultCode, 
				 String serviceFaultDesc ) throws JAXBException, DatatypeConfigurationException
	    {	 
	    	ObjectFactory factory = new ObjectFactory();
	    	FaultInfo faultInfo = new FaultInfo();    	
	    	FaultInfo.Detail detail = new FaultInfo.Detail();
	    	CSIApplicationException csiApplicationException = new CSIApplicationException();
	    	ResponseInfo csiAppExcResponse = new ResponseInfo();
	    	csiAppExcResponse.setCode(code); //100,200,900 as codes
	    	csiAppExcResponse.setDescription(desc);
	    	csiApplicationException.setResponse(csiAppExcResponse);
	    	detail.setCSIApplicationException(csiApplicationException);
	    	
	    	ServiceEntityFaultInfo serviceEntityFaultInfo = new ServiceEntityFaultInfo();	    	
	    	serviceEntityFaultInfo.setFaultCode(serviceFaultCode); //10000000005 
	    	serviceEntityFaultInfo.setFaultDescription(serviceFaultDesc);
	    	serviceEntityFaultInfo.setFaultLevel("ERROR");
	    	
	    	GregorianCalendar c = new GregorianCalendar();    	
	    	c.setTime(new Date());
	    	XMLGregorianCalendar date2 = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
	    	serviceEntityFaultInfo.setFaultDate(date2);
	    	
	    	serviceEntityFaultInfo.setFaultSequenceNumber("1");
	    	serviceEntityFaultInfo.setReportingServiceEntity("CSI");
	    	detail.setCSIInternalException(serviceEntityFaultInfo);
	    	
	    	faultInfo.setDetail(detail);
	    	faultInfo.setFaultactor("soap-env:http://www.csi.cingular.com");
	    	faultInfo.setFaultcode(new QName(code));
	    	faultInfo.setFaultstring(desc);
	    
	    	StringWriter writer = new StringWriter();
	        JAXBContext context = JAXBContext.newInstance(FaultInfo.class);
	        JAXBElement<FaultInfo> element = factory.createFault(faultInfo);
	        Marshaller marshaller = context.createMarshaller();
	        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,Boolean.TRUE);
	        marshaller.marshal(element,writer);
	        System.out.println(writer.toString());
	        return writer.toString();
	    }
		
		public static AJSCTransactionStateImpl getTransactionState(DelegateExecution delegate) throws Exception{
			RequestParameters requestParameters = new RequestParameters();
			MessageHeaderInfo messageHeaderInfo = new MessageHeaderInfo();		
			
			AJSCTransactionStateImpl state = new AJSCTransactionStateImpl(requestParameters, messageHeaderInfo);
			PerformanceTrackingRecord trackingRecord = new PerformanceTrackingRecord();
			state.setTrackingRecord(trackingRecord);		
			//Header<String, Object> headers = {}
			//CommonNames.SERVICE_KEY_DATA1
			//CommonNames.SERVICE_KEY_DATA2
			//CommonNames.HEADER_ATT_TIME_TO_LIVE
			//CommonNames.HEADER_ATT_CONVERSATION_ID
			//CommonNames.HEADER_ATT_DATE_TIME_STAMP
			//CommonNames.CSI_USER_NAME
			//CommonNames.HTTP_AUTHORIZATION		
			//state.setHeaders(headers);
			//mapVars.put(AJSCCommonNames.CSI_INVOKEADAPTER_MDL, (Map<String, String>)delegate.getVariable(AJSCCommonNames.CSI_INVOKEADAPTER_MDL));
			return state;
		}
}
