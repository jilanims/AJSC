package com.att.api.framework.ajsc.upgrade.restService;


import java.util.HashMap;
import java.util.Map;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.api.framework.ajsc.fault.exception.UtilLib;
import com.att.api.framework.common.utils.CommonNames;

/**
 * @author jp931e
 *
 */
public class InvokeRestServiceDelegate implements JavaDelegate{

	public static final Long DEFAULT_TIMEOUT_MS = 1500L;
	public String callingServiceName=null, convId=null, uniqueId=null, partner=null;
	
	private static final Logger logger = LoggerFactory.getLogger(InvokeRestServiceDelegate.class);

	public enum CallType {
		ENTRY, EXIT
	};

	public void execute(DelegateExecution execution) throws Exception{		
		resetFields();
		
		//set default response
		execution.setVariable(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_SERVICERESPONSE, "");
		
		HashMap<String,Object> invokeRestServiceVariables = null;
		try{

			Long timeLeft = 0L;
			String timeLeftStr = (String) execution.getVariable(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_TIMEOUT);
			if(!timeLeftStr.isEmpty()){
				timeLeft = Long.valueOf(timeLeftStr);
			}			
			if (timeLeft < 1500) {
				timeLeft = 1500L;
			}
			
			invokeRestServiceVariables = this.convertDelegateToMap(execution, timeLeft);
			
			//Invoke Rest Service
			InvokeRestService invokeRestService = new InvokeRestService();
			HashMap<String, Object> prvResponse = invokeRestService.invoke(invokeRestServiceVariables);
			String response = (String) prvResponse.get(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_PRVRESPONSE);
			logger.info("response:"+response);			
			
			execution.setVariable(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_SERVICERESPONSE, response);
			logger.info("InvokeService response message:");
			
		}catch(Exception exception){
			throw new Exception(exception.getMessage());
		}		
		
	}
	
	private HashMap<String,Object> convertDelegateToMap(DelegateExecution delegate, Long timeLeft) throws Exception{
		
		//user need to send below data
		HashMap<String,Object> mapVars = new HashMap<String,Object>();
		mapVars.put(CommonNames.TRANSACTION_STATE, UtilLib.getTransactionState(delegate));
		mapVars.put(CommonNames.HEADER_ATT_SERVICE_NAME, (String)delegate.getVariable(CommonNames.HEADER_ATT_SERVICE_NAME));	
		mapVars.put(CommonNames.HEADER_ATT_CONVERSATION_ID, (String)delegate.getVariable(CommonNames.HEADER_ATT_CONVERSATION_ID));
		mapVars.put(CommonNames.HEADER_ATT_UNIQUE_TXN_ID, (String)delegate.getVariable(CommonNames.HEADER_ATT_UNIQUE_TXN_ID));
		
		mapVars.put(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_NAME, (String)delegate.getVariable(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_NAME));
		mapVars.put(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_URI, (String)delegate.getVariable(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_URI));
		mapVars.put(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_CONTENTTYPE, (String)delegate.getVariable(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_CONTENTTYPE));
		mapVars.put(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_METHOD, (String)delegate.getVariable(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_METHOD));
		mapVars.put(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_VERSION, (String)delegate.getVariable(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_VERSION));
		
		mapVars.put(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_TIMEOUT, timeLeft);
		
		//Jilani need to re-visit
		Map<String, String> headerMap = new HashMap<String, String>();
	    headerMap.put("ctn_id","5124228587");
	    
		mapVars.put(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_REQUEST_HEADERS, headerMap);
		mapVars.put(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_USERNAME, (String)delegate.getVariable(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_USERNAME));
		mapVars.put(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_PASSWORD, (String)delegate.getVariable(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_PASSWORD));
		mapVars.put(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_TIMEOUT, (String)delegate.getVariable(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_TIMEOUT));
		
		//
		mapVars.put(RESTSERVICECommonNames.INVOKERESTSERVICE_SERVICERESPONSE_OUTPUT_CODE, "REST_SERVICE_OUTPUT_RESPONSE_CODE");
		mapVars.put(RESTSERVICECommonNames.INVOKERESTSERVICE_SERVICERESPONSE_OUTPUT_HEADERS, "REST_SERVICE_OUTPUT_RESPONSE_HEADERS");
		mapVars.put(RESTSERVICECommonNames.INVOKERESTSERVICE_SERVICERESPONSE_OUTPUT_HEADERKEYMAP, "REST_SERVICE_OUTPUT_RESPONSE_HEADERKEY");
		
		return mapVars;
	}
	
	private void resetFields(){
		convId = null;
		uniqueId=null;
		partner=null;
		callingServiceName = null;
	}

}
