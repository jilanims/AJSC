package com.att.api.framework.ajsc.contivo;

import java.util.List;
import java.util.regex.Pattern;

import javax.xml.namespace.QName;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
//import com.att.ajsc.logging.AjscEelfManager;
import com.att.api.framework.ajsc.csi.framework.service.ServiceCommonNames;
import com.att.api.framework.ajsc.csi.util.BPMNUtilities;
import com.att.api.framework.ajsc.csi.util.XMLUtilities;
import com.att.api.framework.ajsc.trace.Trace;
import com.att.api.framework.common.contivo.InvokeContivo;
import com.att.api.framework.common.utils.CommonNames;
//import com.att.eelf.configuration.EELFLogger;

/**
 * @author jp931e
 *
 */
public class InvokeContivoDelegate<T> implements JavaDelegate {
		
	//private static EELFLogger logger = AjscEelfManager.getInstance().getLogger(InvokeContivoDelegate.class);
	private static Logger logger = LoggerFactory.getLogger(InvokeContivoDelegate.class);
	private String  callingServiceName = null, convId = null, userName =null;	

	@Trace(message="Call InvokeContivoDelegate")
	public void execute(DelegateExecution delegate) throws Exception {
		
		if(logger.isDebugEnabled()){
			logger.debug("********Start ContivoTransformDelegate**********");
		}
		
		resetFields();
		
//		Object[] objectArray  = null;
		
		if(userName == null) {
			userName = (String)delegate.getVariable(ServiceCommonNames.PARTNER_PROFILE_CLIENT);
		}
		if(convId == null) {
			convId = (String)delegate.getVariable(CommonNames.HEADER_ATT_CONVERSATION_ID);
		}
		String uniqueID = (String)delegate.getVariable(CommonNames.HEADER_ATT_UNIQUE_TXN_ID);		
		callingServiceName =(String)delegate.getVariable(AJSCContivoCommonNames.INVOKE_SERVICE_NAME); //
			
		if(logger.isDebugEnabled()){			
			logger.debug("ExchangeId:{}" , uniqueID);
			logger.debug("callingServiceName:{}" , callingServiceName);
			
		}
				
		String transformClassName = (String) delegate.getVariable(AJSCContivoCommonNames.CSI_TRANSFORM_NAME);
		logger.info("i/p className : \n {}",transformClassName);
				
		//comma separated variable name List implementation
		String inputVariableNameList = (String) delegate.getVariable(AJSCContivoCommonNames.CSI_INVOKECONTVO_REQUEST_ARRAY);
				
		if (inputVariableNameList == null) {
		      throw new Exception("Empty contivo Private Request");
		 }
		
		logger.info("inputVariable List : {} " , inputVariableNameList);
		
		//List<String> inputVariables = Arrays.asList(inputVariableNameList.split("||"));
		String[] message = inputVariableNameList.split(Pattern.quote("||"));
		
		//String[] message = new String[inputVariables.size()];
		if(message.length>1){
//			int index = 0;
			List<QName> qNames = BPMNUtilities.getSourceQNames(transformClassName);
			for (int i=0; i<message.length; i++){
			//for (Iterator<String> iterator = inputVariables.iterator(); iterator.hasNext(); index++){
				//message[index] = (String) delegate.getVariable(iterator.next());
				//message[index] = iterator.next();				
				String convInput = XMLUtilities.convObjToXMLString(delegate, message[i]);
				if(convInput!=null){
					message[i] = convInput;
				}
				if(message[i] == null || "".equals(message[i])){
					message[i] = XMLUtilities.getEmptyXml(qNames.get(0));
				}				
			}
		}else{			
			//message[0] = (String) delegate.getVariable(inputVariableNameList);
			message[0] = XMLUtilities.convObjToXMLString(delegate, inputVariableNameList);
			if(message[0] == null)
			{
				message[0]= inputVariableNameList;
			}
		}
		
		if(logger.isDebugEnabled()){
			for (String input : message) {
				logger.debug("input value:\n {} " , input);
			}
		}		
		
		
		String output = null;
		try
		{
			output = (String)InvokeContivo.invokeContivo(message, transformClassName);
		}catch(Exception exception)
		{
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		
		logger.info("o/p output :\n {} ",output);		
		//delegate.setVariable("CSI_INVOKECONTIVO_PRVRESPONSE", output);
		//delegate.setVariable("CSI_INVOKECONTIVO_PRVRESPONSE", XMLUtilities.convLargeXMLtoObj(output));
		delegate.setVariable("CSI_INVOKECONTIVO_PRVRESPONSE", XMLUtilities.convStringLargeXMLtoByteArray(output));
		if(logger.isDebugEnabled()){
			logger.debug("********End ContivoTransformDelegate**********");
		}
	}
	
	private void resetFields(){
		convId = null;
		userName =null;
		callingServiceName = null;
	}
}
