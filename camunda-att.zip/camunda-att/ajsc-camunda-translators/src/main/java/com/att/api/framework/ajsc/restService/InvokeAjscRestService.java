package com.att.api.framework.ajsc.restService;


import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Future;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
//import com.att.ajsc.logging.AjscEelfManager;
import com.att.api.framework.ajsc.trace.Trace;
//import com.att.api.framework.common.adapter.LoadAdapterMap;
import com.att.api.framework.common.logging.APITransactionLogger;
import com.att.api.framework.common.logging.TransactionLogger;
import com.att.api.framework.common.restservice.InvokeRESTParams;
import com.att.api.framework.common.restservice.jaxb.responseinfo.ResponseInfo;
import com.att.api.framework.common.state.api.AJSCTransactionStateImpl;
import com.att.api.framework.common.utils.CommonNames;
import com.att.api.framework.jaxb.requestparameters.RequestParameters;
//import com.att.eelf.configuration.EELFLogger;

/**
 *
 */
public class InvokeAjscRestService{
	
	//private static EELFLogger LOGGER = AjscEelfManager.getInstance().getLogger(InvokeAjscRestService.class);
	private static Logger LOGGER = LoggerFactory.getLogger(InvokeAjscRestService.class);
	
	private String acceptType = null;
	private String uri = null;
	private String service = null;
	private String stringQueryParams = null;
	private String method = null;
	private String version = null;

	private String callingServiceName = null, targetService = null, convId = null, userName =null;
	private long minTimeout = 2000;

	private static final String DEFAULT_AJSC_INSTANCE_NAME = "UNSPECIFIED_AJSC_INSTANCE";
	private static final String CONTENT_TYPE = "Content-Type";

	public enum CallType {
		ENTRY, EXIT
	};
	
	//to be tested
	/*static {
		LoadAdapterMap loadAdapterMap = new LoadAdapterMap();
	}*/
	
	/**
	 * 
	 * @param mapVars
	 * @return
	 * @throws Exception
	 * 
	 */
	
	@Trace(message="Call InvokeAjscRestService")
	public final Map<String, Object>  invoke(Map<String, Object> mapVars) throws Exception {

		resetFields();
		AJSCTransactionStateImpl transState =  (AJSCTransactionStateImpl)mapVars .get(CommonNames.TRANSACTION_STATE);
		callingServiceName = (String)mapVars .get(CommonNames.HEADER_ATT_SERVICE_NAME);

		ResponseInfo restResponseInfo=null;
		Future<ResponseInfo> responseFutureObject;
		String uniqueId = (String) mapVars.get(CommonNames.HEADER_ATT_UNIQUE_TXN_ID);
		try{

			InvokeRESTParams restParams=createRESTParams(mapVars, transState, callingServiceName);
			responseFutureObject= com.att.api.framework.common.restservice.InvokeRESTService.invoke(restParams);
			restResponseInfo=responseFutureObject.get();
		}
		catch(Exception exception){
			throw exception;
		}
		if (restResponseInfo != null) {
			mapVars.put(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_SERVICERESPONSE,
					restResponseInfo.getBody());
			mapVars.put(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_SERVICERESPONSE_STRING,
					restResponseInfo.getBody());
			mapVars.put(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_SERVICERESPONSE_CODE,
					Integer.valueOf(restResponseInfo.getCode().intValue()));
			mapVars.put(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_SERVICERESPONSE_HEADERS,
					restResponseInfo.getHeader());
		} else {
			throw new Exception(
					"x-code:500:SVC9999:An internal error has occurred: Unable to capture response");
		}		

		mapVars.put(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_PRVRESPONSE, restResponseInfo);
		return mapVars;
	}
	
	@SuppressWarnings("unchecked")
	private InvokeRESTParams createRESTParams(Map<String, Object> mapVars,AJSCTransactionStateImpl transState,String callingServiceName) throws Exception{

		String authorization = null, targetUri = null, targetAcceptType = null, targetMethod = null, payload = null, mhMessageId= null,
				orginatorId= null;
		Map mapQueryParams = null, targetRequestHeaders = null;
		InputStream payloadInputStream = null;		
		long timeToLive = 0L;

		TransactionLogger logger = new APITransactionLogger(callingServiceName);		
		RequestParameters reqParam = ((AJSCTransactionStateImpl)transState).getRequestParameters();

		targetService = (String)mapVars.get(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_NAME);
		if (targetService == null || targetService.isEmpty()) {
			targetService = service;
		}
		if(callingServiceName==null){
			callingServiceName = targetService;
		}

		String targetVersion = (String)mapVars.get(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_VERSION);
		if (targetVersion == null || targetVersion.isEmpty()) {
			targetVersion = version;
		}
		if (targetVersion == null || targetVersion.isEmpty()) {
			throw new Exception("Request version not set");
		}

		String key, ttl = null, timeStamp=null,guid = "";

//		for (int i=0; i<reqParam.getHeader().getPair().size(); i++) {
//			key = reqParam.getHeader().getPair().get(i).getKey();
//			if (key.equalsIgnoreCase(CommonNames.HEADER_ATT_SERVICE_NAME) && targetService == null)
//				targetService = reqParam.getHeader().getPair().get(i).getValue();
//			else if (key.equalsIgnoreCase(CommonNames.HEADER_ATT_TIME_TO_LIVE))
//				ttl = reqParam.getHeader().getPair().get(i).getValue();
//			else if (key.equalsIgnoreCase(CommonNames.HEADER_ATT_CONVERSATION_ID))
//				convId = reqParam.getHeader().getPair().get(i).getValue();
//			else if (key.equalsIgnoreCase(CommonNames.GUID))
//				guid = reqParam.getHeader().getPair().get(i).getValue();
//			else if (key.equalsIgnoreCase(CommonNames.HEADER_ATT_MESSAGE_ID))
//				mhMessageId = reqParam.getHeader().getPair().get(i).getValue();
//			else if (key.equalsIgnoreCase(CommonNames.HEADER_ATT_ORIGINATOR_ID))
//				orginatorId = reqParam.getHeader().getPair().get(i).getValue();			
//			else if (key.equalsIgnoreCase(CommonNames.HEADER_ATT_DATE_TIME_STAMP))
//				timeStamp = reqParam.getHeader().getPair().get(i).getValue();
//			else if (key.equalsIgnoreCase(CommonNames.HEADER_ATT_VERSION) && targetVersion == null)
//				targetVersion = reqParam.getHeader().getPair().get(i).getValue();			
//			else if (key.equalsIgnoreCase(CommonNames.CSI_USER_NAME))
//				userName = reqParam.getHeader().getPair().get(i).getValue(); 
//			else if (key.equalsIgnoreCase(CommonNames.HTTP_AUTHORIZATION)) {
//				authorization = reqParam.getHeader().getPair().get(i).getValue();
//				if (authorization != null) {
//					userName = CommonUtil.extractUserNameFromHeader(authorization);
//				}
//			}
//		}
		
		// if the converstionid is not available in the header then get it from map variables....
		if(convId == null) {
			convId = (String)mapVars.get(CommonNames.HEADER_ATT_CONVERSATION_ID);
		}
		//exchange.setProperty("uniqueTransactionId", uniqueTransactionId);
		Object timeOutValue = 0;
		long timeout ;
		timeOutValue = (Object) mapVars.get(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_TIMEOUT);
		if(timeOutValue == null)
		{
			timeout = 0;
		}
		else
		{
			timeout = Long.valueOf(timeOutValue.toString());
		}
		if (timeout < 1500) {
			long stime = 0;
			if(timeStamp!=null){
				stime = Long.parseLong(timeStamp);
			}
			timeout = Long.parseLong(ttl) - (System.nanoTime()/1000000 - stime);
		}
		String instanceName = DEFAULT_AJSC_INSTANCE_NAME;

		targetUri = (String) mapVars.get(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_URI);
		if ((targetUri == null) || (targetUri.isEmpty())) {
			targetUri = this.uri;
		}

		targetAcceptType = (String) mapVars.get(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_CONTENTTYPE);
		if ((targetAcceptType == null) || (targetAcceptType.isEmpty())) {
			targetAcceptType = this.acceptType;
		}

		targetMethod = (String) mapVars.get(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_METHOD);
		if ((targetMethod == null) || (targetMethod.isEmpty())) {
			targetMethod = this.method;
		}		

		targetRequestHeaders = (Map) mapVars.get(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_REQUEST_HEADERS);
		if (targetRequestHeaders == null) {
			targetRequestHeaders = new HashMap();
		}

		mapQueryParams = (Map) mapVars.get(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_QUERY_PARAMS_MAP);
		if (mapQueryParams == null) {
			mapQueryParams = new HashMap();
			if ((this.stringQueryParams != null)
					&& (!(this.stringQueryParams.isEmpty()))) {
				for (String query : this.stringQueryParams.split("&")) {
					String[] thisQuery = query.split("=");
					mapQueryParams.put(thisQuery[0], thisQuery[1]);
				}
			}
		}

		payloadInputStream = (InputStream) mapVars.get(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_PAYLOAD_STREAM);
		if (payloadInputStream == null) {
			payload = (String) mapVars.get(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_PAYLOAD_STRING);
			if (payload == null) {
				payload = "";
			}
			payloadInputStream = new ByteArrayInputStream(payload.getBytes());
		}

		logger.setConversationId(convId);
		logger.setEngine(instanceName);
		logger.setServiceName(callingServiceName);	
		logger.setGuid(guid);

		String engineName = DEFAULT_AJSC_INSTANCE_NAME;
		InvokeRESTParams restParams= new InvokeRESTParams();		

		targetRequestHeaders.put("X-CSI-Version", this.version);
		targetRequestHeaders.put("X-CSI-OriginalVersion", "");
		targetRequestHeaders.put("X-CSI-MessageId", mhMessageId);
		targetRequestHeaders.put(CommonNames.CSI_USER_NAME, userName);		
		targetRequestHeaders.put("X-CSI-ConversationId", convId);				
		targetRequestHeaders.put("X-CSI-TimeToLive", Long.toString(timeToLive));				
		targetRequestHeaders.put("X-CSI-OriginatorId", orginatorId);
		targetRequestHeaders.put("X-CSI-UniqueTransactionId", guid);
		targetRequestHeaders.put(CommonNames.HTTP_AUTHORIZATION, authorization);
		targetRequestHeaders.put("X-CSI-SequenceNumber", "1");
		targetRequestHeaders.put("X-CSI-TotalInSequence", "1");
		targetRequestHeaders.put("X-CSI-ClientApp","AJSC-CSI~"+engineName +"~"+callingServiceName);
		targetRequestHeaders.put(CommonNames.CLIENT_APP,"AJSC-CSI~"+engineName +"~"+callingServiceName);
		targetRequestHeaders.put(CONTENT_TYPE, targetAcceptType);
		targetRequestHeaders.put(mapVars.get("contentLength"), Integer.toString(null!=payload ? payload.length() : 0));
		restParams.setTargetRequestHeaders(targetRequestHeaders);
		restParams.setPayload(payload);
		restParams.setPayloadInputStream(payloadInputStream);
		restParams.setMapQueryParams(mapQueryParams);
		restParams.setCallingServiceName(callingServiceName);
		restParams.setTargetAcceptType(targetAcceptType);
		restParams.setUserName(userName);
		restParams.setTargetUri(targetUri);
		restParams.setTargetMethod(targetMethod);
		restParams.setTargetVersion(targetVersion);
		restParams.setTargetService(targetService);

		String versionApplEnv = System.getProperty(CommonNames.VERSION_ROUTEOFFER_ENVCONTEXT);		
		String[] splitInstance = versionApplEnv.split("\\/");
		String defaultEnvContext = splitInstance[2];
		String stickySelectorKey = splitInstance[1];

		restParams.setDefaultDME2EnvContext(defaultEnvContext);
		restParams.setStickySelectorKey(stickySelectorKey);
		restParams.setTimeLeft(timeout);
		return restParams;
	}

	
	public String getAcceptType() {
		return this.acceptType;
	}

	public void setAcceptType(String acceptType) {
		this.acceptType = acceptType;
	}

	public String getUri() {
		return this.uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public String getService() {
		return this.service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public String getStringQueryParams() {
		return this.stringQueryParams;
	}

	public void setStringQueryParams(String stringQueryParams) {
		this.stringQueryParams = stringQueryParams;
	}

	public String getMethod() {
		return this.method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getVersion() {
		return this.version;
	}

	public void setVersion(String version) {
		this.version = version;
	}
	
	private void resetFields(){
		targetService = null;
		convId = null;
		userName =null;
		callingServiceName = null;
	}


}
