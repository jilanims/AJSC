package com.att.api.framework.ajsc.csi.util;

import static org.camunda.spin.Spin.XML;

import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TimeZone;

import javax.script.Bindings;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import javax.script.SimpleBindings;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import org.apache.commons.lang.StringEscapeUtils;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.variable.Variables;
import org.camunda.bpm.engine.variable.value.ObjectValue;
import org.camunda.spin.SpinList;
import org.camunda.spin.impl.xml.dom.DomXmlElement;
import org.camunda.spin.plugin.variable.SpinValues;
import org.camunda.spin.plugin.variable.value.XmlValue;
import org.camunda.spin.xml.SpinXPathException;
import org.camunda.spin.xml.SpinXPathQuery;
import org.camunda.spin.xml.SpinXmlElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

/**
 * @author jn448j
 *
 */
public class XMLUtilities {
	
	//@Value("${large.xml.spin.xmlvalue:false}")
	public static String spinXmlValue= System.getProperty("large.xml.spin.xmlvalue");
	
	private static final Logger logger = LoggerFactory.getLogger(XMLUtilities.class);
	
	public static Boolean evaluateExpression(String expression,  Map<String, Object> variableMap, Map<String, String> nsMap){
		Boolean isStatisfied = false;
		ScriptEngineManager mgr = new ScriptEngineManager();
	    ScriptEngine engine = mgr.getEngineByName("JavaScript");
	    Bindings bindings = new SimpleBindings();
	    bindings.putAll(variableMap);
	    bindings.put("xpath", new XPath(nsMap));
	    try {
	    	isStatisfied = (Boolean) engine.eval(expression, bindings);
		} catch (ScriptException exception) {
			logger.error(exception.getMessage(), exception);
		}
		return isStatisfied;
	}
	
	public static String getRootElementName(String xml){
		return isNullOrEmpty(xml) ? xml : XML(xml).name();
	}
	
	public static String evaluateXPath(SpinXmlElement xmlElement, String xpathExression, Map<String, String> nsMap){
	    return getXpathQuery(xmlElement, xpathExression, nsMap).string();
	}
	
	public static String evaluateXPath(String xml, String xpathExression, Map<String, String> nsMap){
		return isNullOrEmpty(xml) ? "" : evaluateXPath(XML(xml), xpathExression, nsMap);
	}
	
	public static XmlValue evaluateXPath(XmlValue  xmlvalue, String xpathExression, Map<String, String> nsMap){
		return  SpinValues.xmlValue(evaluateXPath(xmlvalue.getValue(), xpathExression, nsMap)).create();
	}
	
	public static String extractFromJmsPayload(SpinXmlElement jmsElement, String elementName){
		Map<String, String> nsMap = new HashMap<String, String>();
		nsMap.put("jms", getSchemaNamespace("JMS", jmsElement.name()));
		SpinXPathQuery xpathQuery = getXpathQuery(jmsElement, "/jms:" + jmsElement.name() +"/jms:" + elementName, nsMap);
		return xpathQuery.element().toString().replace(getSchemaNamespace("JMS", jmsElement.name()), getSchemaNamespace("Container", elementName));
	}
	
	public static String getContainerElementName(String jmsElementName){
		String containerElementName = jmsElementName;
		if("SoapFaultResponse".equals(jmsElementName)){
			containerElementName = "Fault";
		}
		return containerElementName;
	}
	
	public static String getContainerPayload(String jmsPayload){
		SpinXmlElement jmsElement = XML(jmsPayload);
		String containerElementName = getContainerElementName(jmsElement.name());
		return extractFromJmsPayload(jmsElement, containerElementName);
	}
	
	public static ArrayList<String> getInternalLoopRequestList(String loopRequestXml){
		ArrayList<String> list = new ArrayList<String>(2);
		SpinXmlElement root = XML(loopRequestXml);
		SpinList<SpinXmlElement> requests = root.childElements(root.name().replace("Internal_Loop_", ""));
		for (Iterator<SpinXmlElement> iterator = requests.iterator(); iterator.hasNext();) {
			SpinXmlElement request = iterator.next();
			list.add(request.toString().replace("Private/Internal/Internal_Loop_", "Public/").replace("req:InquireSubscriberRequest", "ns0:InquireSubscriberRequest"));
		}
		logger.debug("getInternalLoopRequestList Output - {}", list);
		return list;
	}
	
	// to handle both xml and soap xml's
	public static ArrayList<String> getInternalLoopRequestList(String loopRequestXml, String adapterMethod, String soapMsgHeader, String invokServVersion, String targetNamespace){
		ArrayList<String> list = new ArrayList<String>(2);
		//targetNamespace ="http://cingular.com/cam/interfaces/subscriber";
		SpinXmlElement root = XML(loopRequestXml);
		if(root.name().contains("Internal_Loop_")){
		SpinList<SpinXmlElement> requests = root.childElements(root.name().replace("Internal_Loop_", ""));
		for (Iterator<SpinXmlElement> iterator = requests.iterator(); iterator.hasNext();) {
			SpinXmlElement request = iterator.next();
			if(null==adapterMethod){
				list.add(XMLUtilities.generateSoapMessage(request.toString(), invokServVersion, soapMsgHeader));
			}else{
				boolean nmExists = request.hasNamespace("http://cingular.com/cam/interfaces/subscriber");
				if(null!=targetNamespace){
					list.add(request.toString().replace( request.namespace(), targetNamespace).replace("Private/Internal/Internal_Loop_", "Public/"));
				}else{
					list.add(request.toString().replace("Private/Internal/Internal_Loop_", "Public/"));
				}
				
			}
		}
		}else{
			list.add(XMLUtilities.generateSoapMessage(loopRequestXml, invokServVersion, soapMsgHeader)); // single soap request
		}
		logger.debug("getInternalLoopRequestList Output - {}", list);
		return list;
	}
	
	private static String generateSoapMessage(String soapMessage, String mhVersion, String mh){
		//check for JMSpayload, if yes then add the soap header	
		if(XMLUtilities.isXmlType(soapMessage, "Envelope", "http://schemas.xmlsoap.org/soap/envelope/")){
			// TODO
		}else if(!XMLUtilities.isJMSPayload(soapMessage)){
			//String mhVersion = (String)execution.getVariable(ServiceCommonNames.CSI_INVOKESERVICE_VERSION);
			//String mh = (String) execution.getVariable("SoapMessageHeader");				
			String updatedMh = XMLUtilities.updateVersion(mhVersion, mh);
			updatedMh.replace("/JMS/", "/");
			soapMessage = XMLUtilities.generateSoapStr(updatedMh, soapMessage);			
		}
		soapMessage = soapMessage.replace("Private/Internal/Internal_Loop_", "Public/");
		logger.debug("soapMessage:", soapMessage);
		return soapMessage;
	}
	
	private static SpinXmlElement appendResultSet(SpinXmlElement response, Object result){
		SpinXmlElement resultSet = XML("<ResultSet xmlns=\"" + response.namespace() + "\" />");
		SpinXmlElement child = XML(result);
		resultSet.append(child);
		String name = "Fault".equals(child.name()) ?  "SoapFault" : child.name();
		if(name.contains("Fault")){
			resultSet.replaceChild(child, XML("<" + name + " xmlns=\"" + response.namespace()+ "\"/>").append(child.childElements()));
		}		
		return response.append(resultSet);
	}
	
	public static String getInternalLoopResponse(String loopRequestXml, ArrayList<Object> responseList){
		SpinXmlElement loopRequest = XML(loopRequestXml);
		SpinXmlElement response = XML("<"  + loopRequest.name().replace("Request", "Response") + " xmlns=\"" + loopRequest.namespace().replace("Request", "Response") + "\" />");
		for (Iterator<Object> iterator = responseList.iterator(); iterator.hasNext();) {
			response = appendResultSet(response, iterator.next());
		}
		String loopResponse  = null;
		try{
		loopResponse = response.toString();
		}catch(Exception e){
			e.printStackTrace();
		}
		logger.debug("getInternalLoopResponse Output - {}", loopResponse);
		return loopResponse;
	}
	
	public static String getJMSElementName(String conatinerElementName){
		String jmsElementName = conatinerElementName;
		if("Fault".equals(conatinerElementName)){
			jmsElementName = "SoapFaultResponse";
		}
		return jmsElementName;
	}
	
	public static SpinXmlElement getJmsPayload(SpinXmlElement mhElement, SpinXmlElement containerElement){
		SpinXmlElement jmsElement = XML("<" + getJMSElementName(containerElement.name())  + " xmlns=\"" + getSchemaNamespace("JMS", getJMSElementName(containerElement.name())) + "\"/>");
		jmsElement.append(mhElement, containerElement);
		jmsElement.replaceChild(jmsElement.childElement(getSchemaNamespace("Container",  mhElement.name()), mhElement.name()), 
				XML("<" + mhElement.name() + " xmlns=\"" + getSchemaNamespace("JMS", getJMSElementName(containerElement.name())) + "\"/>").append(mhElement.childElements()));
		
		jmsElement.replaceChild(jmsElement.childElement(getSchemaNamespace("Container",  containerElement.name()), containerElement.name()), 
				XML("<" + containerElement.name() + " xmlns=\"" + getSchemaNamespace("JMS", getJMSElementName(containerElement.name()) ) + "\"/>").append(containerElement.childElements()));
		return jmsElement;
	}
	
	public static String getJmsPayload(String messageHeader, String containerPayload){
		return getJmsPayload(XML(messageHeader), XML(containerPayload)).toString();
	}
	
	public static XmlValue getJmsPayload(XmlValue messageHeader, XmlValue containerPayload){
		return  SpinValues.xmlValue(getJmsPayload(messageHeader.getValue(), containerPayload.getValue()).toString()).create();
	}
	
	private static String getSchemaNamespace(String nsType, String rootElementName){
		String ns = null;
		if("GenericFalloutResponse".equals(rootElementName)){
			ns = "http://csi.cingular.com/CSI/Namespaces/" + nsType + "/Public/GenericFalloutM2EResponse.xsd";
		}else if("GenericFalloutRequest".equals(rootElementName)){
			ns = "http://csi.cingular.com/CSI/Namespaces/" + nsType + "/Public/GenericFalloutM2ERequest.xsd";
		}else if("MessageHeader".equals(rootElementName)){
			ns = "http://csi.cingular.com/CSI/Namespaces/Types/Public/MessageHeader.xsd";
		}else if("Fault".equals(rootElementName)){
				ns = "http://csi.cingular.com/CSI/Namespaces/Types/Public/SoapFault.xsd";
		}else if("SoapFaultResponse".equals(rootElementName)){
			ns = "http://csi.cingular.com/CSI/Namespaces/JMS/Public/SoapFaultResponse.xsd";
		}else{
			ns = "http://csi.cingular.com/CSI/Namespaces/" + nsType + "/Public/" + rootElementName +".xsd";
		}
		return ns;
	}
	
	public static SpinXPathQuery getXpathQuery(SpinXmlElement xmlElement, String xpathExression, Map<String, String> nsMap){
	    return xmlElement.xPath(xpathExression).ns(nsMap);
	}
	
	public static SpinXmlElement getXPathXmlElement(SpinXmlElement xmlElement, String xpathExression, Map<String, String> nsMap){
		SpinXmlElement element = null;
		SpinXPathQuery xpathQuery = getXpathQuery(xmlElement, xpathExression, nsMap);
		try{
			element = xpathQuery.element();
		}catch(SpinXPathException exception){
			logger.debug(xpathExression, exception);
		}
	    return element;
	}
	
	public static boolean isContainerPayload(String xml){
		return isNullOrEmpty(xml) ? false : isXmlType(xml, null, getSchemaNamespace("Container", XML(xml).name()));
	}
	
	public static boolean isFault(String xml){
		return isNullOrEmpty(xml) ? false : isXmlType(xml, "Fault", getSchemaNamespace("JMS","Fault"));
	}
	
	public static boolean isJMSPayload(String xml){
		return isNullOrEmpty(xml) ? false : isXmlType(xml, null, getSchemaNamespace("JMS", XML(xml).name()));
	}
	
	public static boolean isNullOrEmpty(Object obj){
		boolean isNullOrEmpty = false;
		if(obj == null){
			isNullOrEmpty = true;
		}else if(String.class.isInstance(obj) && "".equals(obj)){
			isNullOrEmpty = true;
		}
		return isNullOrEmpty;
	}
	
	public static boolean isXmlType(String xml, String rootName, String rootNamespace){
		boolean isXmlType = false;
		if(!isNullOrEmpty(xml)){
			SpinXmlElement root = XML(xml);
			if(rootName != null && rootNamespace != null){
				isXmlType = root.name().equals(rootName) && rootNamespace.equals(root.namespace());
			}else if(rootName != null){
				isXmlType = root.name().equals(rootName);
			}else if(rootNamespace != null){
				isXmlType = rootNamespace.equals(root.namespace());
			}
		}
		return isXmlType;
	}
	
	public static SpinXmlElement replaceElement(SpinXmlElement xmlElement, String xpathExression, Map<String, String> nsMap, String value) {
		SpinXmlElement element = getXPathXmlElement(xmlElement, xpathExression, nsMap);
		if(element != null){
			element.textContent(value == null ? "": value);
		}
		return xmlElement;
	}
	
	public static String replaceElement(String xml, String xpathExression, Map<String, String> nsMap, String value) {
		return isNullOrEmpty(xml) ? xml : replaceElement(XML(xml), xpathExression, nsMap, value).toString();
	}
	
	public static String replaceElement(XmlValue  xmlvalue, String xpathExression, Map<String, String> nsMap, String value) {
		return replaceElement(xmlvalue.getValue(), xpathExression, nsMap, value).toString();
	}
	
	public static String stringifyXml(String xml){
		return xml != null ? StringEscapeUtils.escapeXml(xml.replaceAll("\\<\\?xml(.+?)\\?\\>", "").trim()) : null;
	}
	
	public static String getResumeRequest(String key, String step, String subStep, String payload){
		StringBuilder builder = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><ResumeRequest xmlns:=\"http://csi.cingular.com/CSI/Namespaces/Container/Public/ResumeRequest.xsd\">");
		builder.append("<key>");
		builder.append(emptyIfNull(key));
		builder.append("</key>");
		builder.append("<step>");
		builder.append(emptyIfNull(step));
		builder.append("</step>");
		builder.append("<subStep>");
		builder.append(emptyIfNull(subStep));
		builder.append("</subStep>");
		builder.append("<request>");
		builder.append(stringifyXml(emptyIfNull(payload)));
		builder.append("</request></ResumeRequest>");
		return builder.toString();
	}
	
	public static String getEmptyXml(QName qName){
		StringBuilder builder = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
		builder.append("<" + qName.getLocalPart());
		if(!isNullOrEmpty(qName.getNamespaceURI()))
			builder.append(" xmlns=\"" + qName.getNamespaceURI() + "\"");
		builder.append("/>");
		return builder.toString();
	}
	
	private static String emptyIfNull(String str){
		return str == null ? "" : str;
	}
	
	public static XMLGregorianCalendar getXMLGregorianCalendar(){
		XMLGregorianCalendar calendar = null;
		try {
			calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(new GregorianCalendar(TimeZone.getTimeZone("UTC")));
		} catch (DatatypeConfigurationException e) {
			logger.error("Failed while creating DateTimeStamp", e);
		}
		return calendar;
	}
	
	public static String updateVersion(String mhVersion, String msgheader){
		Map<String, String> nsMap = new HashMap<String, String>();
		nsMap.put("mh", "http://csi.cingular.com/CSI/Namespaces/Types/Public/MessageHeader.xsd");
		nsMap.put("cng", "http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd");		
		return XMLUtilities.replaceElement(msgheader, "/mh:MessageHeader/mh:TrackingMessageHeader/cng:version", nsMap, mhVersion);
	}
		
	public static void generateSoapMessage(String[] args) {
		//http://www.jitendrazaa.com/blog/java/create-soap-message-using-java/
		try{
			MessageFactory factory = MessageFactory.newInstance();
			SOAPMessage soapMsg = factory.createMessage();
			SOAPPart part = soapMsg.getSOAPPart();

			SOAPEnvelope envelope = part.getEnvelope();
			SOAPHeader header = envelope.getHeader();
			SOAPBody body = envelope.getBody();

			header.addTextNode("Training Details");

			SOAPBodyElement element = body.addBodyElement(envelope.createName("JAVA", "training", "http://JitendraZaa.com/blog"));
			element.addChildElement("WS").addTextNode("Training on Web service");

			SOAPBodyElement element1 = body.addBodyElement(envelope.createName("JAVA", "training", "http://JitendraZaa.com/blog"));
			element1.addChildElement("Spring").addTextNode("Training on Spring 3.0");

			soapMsg.writeTo(System.out);

			FileOutputStream fOut = new FileOutputStream("SoapMessage.xml");
			soapMsg.writeTo(fOut);

			System.out.println();
			System.out.println("SOAP msg created");

		}catch(Exception e){
			e.printStackTrace();
		}

	}
	
	public static String generateSoapStr(String msgHeaderStr, String bodyStr){			
		//StringBuilder soapSb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
		StringBuilder soapSb = new StringBuilder();
		//soapSb.append("<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">");
		soapSb.append("<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">");
		soapSb.append("<SOAP-ENV:Header>");
		soapSb.append(msgHeaderStr.replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", ""));
		soapSb.append("</SOAP-ENV:Header>");
		soapSb.append("<SOAP-ENV:Body>");
		soapSb.append(bodyStr.replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", ""));
		soapSb.append("</SOAP-ENV:Body>");
		soapSb.append("</SOAP-ENV:Envelope>");		
		String soapMsg = soapSb.toString().replaceAll("\\r", "");
		soapMsg = soapMsg.replaceAll("\\t", "");
		soapMsg = soapMsg.replaceAll("\\n", "");
		logger.debug("Generated SOAP Message Request - {}"+soapMsg);
		return soapMsg; 
	}
	
	public static String convObjToXMLString(DelegateExecution execution, String processVariableName){
		logger.info("*********************************** convObjToXMLString method start ***********************************");
		String responseXml = null;
		Object obj = execution.getVariable(processVariableName);
		if(obj instanceof  byte[]){
			return new String( (byte[]) execution.getVariable(processVariableName));			
		}else if(obj instanceof  DomXmlElement){
			DomXmlElement respXMLObj = (DomXmlElement) execution.getVariable(processVariableName);
			responseXml = respXMLObj.toString();
		}else{
			responseXml = (String) execution.getVariable(processVariableName);
		}
		logger.info("string responseXml:"+responseXml);
		logger.info("*********************************** convObjToXMLString method end ***********************************");
		return responseXml;
	}
	
	public static ObjectValue convLargeXMLtoObj(Object prvResponse){
		logger.info("*********************************** convLargeXMLtoObj method start ***********************************");
		logger.info("Object value:"+prvResponse);
		
		ObjectValue responseObj = Variables.objectValue(prvResponse)
				  .serializationDataFormat(Variables.SerializationDataFormats.JAVA)
				  .create();
		//if(logger.isDebugEnabled()){	
			String res = responseObj.toString();
			int responseObjsize = res.length();
			if(responseObjsize>4194304){ //4MB of prvResponse data
				logger.info("*************************************************process instance variable size is greater than 4 MB***********************");
				logger.info("current variable size::"+responseObjsize+" > 4194304");
			}
			logger.info("(type:Serialized XML String Objet):"+responseObjsize);
		//}		
		logger.info("*********************************** convLargeXMLtoObj method end ***********************************");		
		return responseObj;		
	}
	
	public static XmlValue convLargeXMLtoXmlValueObj(Object prvResponse){
		logger.info("*********************************** convLargeXMLtoXmlValueObj method start ***********************************");
		logger.info("Object value:"+prvResponse);	
		SpinXmlElement spinRespElement = XML(prvResponse);
		XmlValue respXmlValue = SpinValues.xmlValue(spinRespElement).create();
		logger.info("(type:XmlValue):"+respXmlValue);
		logger.info("*********************************** convLargeXMLtoXmlValueObj method end ***********************************");
		return respXmlValue;		
	}
	
	public static byte[] convStringLargeXMLtoByteArray(String prvResponse){
		logger.info("*********************************** convStringLargeXMLtoByteArray method ***********************************");
		logger.info("String value:"+prvResponse);		
		return prvResponse.getBytes();		
	}
	
	/*public static Object convLargeXMLtoSeriObjOrXmlValue(Object prvResponse){
		logger.info("*********************************** convLargeXMLtoSeriObjOrXmlValue method start ***********************************");
		logger.info("Object value:"+prvResponse);		
		if("true".equalsIgnoreCase(spinXmlValue)){
			XmlValue xmlVal = convLargeXMLtoXmlValueObj(prvResponse);
			return xmlVal;
		}else{
			ObjectValue objres = convLargeXMLtoObj(prvResponse);
			return objres;
		}
			
	}*/
}
