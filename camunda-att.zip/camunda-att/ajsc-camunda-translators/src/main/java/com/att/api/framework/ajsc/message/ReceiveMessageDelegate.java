package com.att.api.framework.ajsc.message;

import java.util.Map;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.core.JmsTemplate;

import com.att.api.framework.ajsc.csi.util.BPMNConstants;
import com.att.api.framework.ajsc.csi.util.BPMNUtilities;
import com.att.api.framework.ajsc.csi.util.JMSSender;

/**
 *
 */
public class ReceiveMessageDelegate implements JavaDelegate{
	
	private static final Logger logger = LoggerFactory.getLogger(ReceiveMessageDelegate.class);
	
	private JmsTemplate jmsTemplate;
	
	public ReceiveMessageDelegate(JmsTemplate jmsTemplate)
	{
		this.jmsTemplate = jmsTemplate;
	}
	
	
	@Override
	public void execute(DelegateExecution delegate) throws Exception {
		BPMNUtilities.logDelegate(delegate);

		Map<String, String> paramMap = BPMNUtilities.loadParameterMap(delegate, (String) delegate.getVariable(BPMNConstants._Parameters)) ;
		String requestqueueName =( String) delegate.getVariable(BPMNConstants.REQUEST_QUEUE);
		String timeout =( String) delegate.getVariable(BPMNConstants.TIME_OUT);
		String messageSelector = (String) delegate.getVariable(BPMNConstants.MESSAGE_SELECTOR);
		String requestSecondaryqueueName = (String) delegate.getVariable("SecondaryQueueName");
		long currentTimeOutMillis = Long.parseLong(timeout);
		String response = null;
		long currentSystemTimeInMilli = System.currentTimeMillis();
		while((System.currentTimeMillis() < (currentTimeOutMillis + currentSystemTimeInMilli)) && response == null)
		{
			try{
				response = JMSSender.receive(jmsTemplate,requestqueueName, messageSelector);
				if(response == null)
				{
					try 
					{
						response = JMSSender.receive(jmsTemplate,requestSecondaryqueueName, messageSelector);
					}
					catch(Exception e)
					{
						logger.debug("will try to get message from queue again");
					}
				}
			}catch(Exception exception){
				if(requestSecondaryqueueName != null)
				{
					try 
					{
						response = JMSSender.receive(jmsTemplate,requestSecondaryqueueName, messageSelector);
					}
					catch(Exception e)
					{
						logger.debug("will try to get message from queue again");
					}
				}
			}
		}
		String outputVariable = (String) delegate.getVariable(BPMNConstants._Output) ;
		delegate.setVariable(outputVariable.trim(), response);
		
		BPMNUtilities.delegateCleanUp(delegate);
		logger.debug("execute():end");
	}
	
}