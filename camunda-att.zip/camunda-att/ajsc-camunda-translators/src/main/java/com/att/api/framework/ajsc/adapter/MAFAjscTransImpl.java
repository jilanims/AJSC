package com.att.api.framework.ajsc.adapter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.api.framework.ajsc.csi.framework.service.InvokeServiceDelegate;
import com.att.api.framework.common.adapter.MAFApiTransImpl;
import com.att.api.framework.common.configurationmanager.PropertyManager;
import com.att.api.framework.common.logging.TransactionLogger;

/**
 * @author jp931e
 * AjscCSITrans is the AJSC implementation of CSI Environment and Transactional
 * info.
 * 
 * 
 * 
 */
public class MAFAjscTransImpl extends MAFApiTransImpl {
	
	private static final Logger logger = LoggerFactory.getLogger(InvokeServiceDelegate.class);
		
	public MAFAjscTransImpl(TransactionLogger logger) {
		
		super(logger);

	}
	
	
// Custom methods can be added or overridden in future...	
	
	@Override
	public String getProperty(String key) {
				
		String val = null;
		
//		String val = PropertiesMapBean.getProperty("spm2.properties", key);
		try
		{	logger.info("key:"+key);
			val = PropertyManager.getProperty("spm2.properties", key);
		}
		catch (Exception e)
		{
			//System.err.println("[ERROR][PropertyManager] Failed to read property " + key + ". " + e.getMessage() );
			logger.error( "[ERROR][PropertyManager] Failed to read property {}{} " , key + ". " , e.getMessage() );
		}
		
		return val;
	}
	

}
