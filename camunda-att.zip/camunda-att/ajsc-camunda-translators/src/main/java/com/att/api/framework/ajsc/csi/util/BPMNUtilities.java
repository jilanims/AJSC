package com.att.api.framework.ajsc.csi.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.io.IOUtils;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentFragment;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.contivo.runtime.core.IPropertyNames;
import com.contivo.runtime.core.TMapper;
import com.contivo.runtime.core.TSourceRecord;
import com.contivo.runtime.dom.ITransform;
import com.contivo.runtime.wrapper.TransformAny;
import com.contivo.runtime.wrapper.TransformAny.DocSpec;
import com.contivo.runtime.wrapper.TransformAnyResults;
import com.att.api.framework.common.security.utils.XXESettingUtils;
/**
 *
 */
public class BPMNUtilities {
	
	public enum MESSAGE_HEADER{version, conversationId, userName, infrastructureVersion, uniqueTransactionId,timeToLive,originatorId,totalInSequence,sequenceNumber}
	
	private static final Logger logger = LoggerFactory.getLogger(BPMNUtilities.class);
	
	private static final String UTF8_BOM = "\uFEFF";;
	
	public static String createSOAPXml(String header, String body) {
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		try {
			SOAPMessage soapMsg = MessageFactory.newInstance().createMessage();
			SOAPPart part = soapMsg.getSOAPPart();
			SOAPEnvelope envelope = part.getEnvelope();
			if(header != null){
				Document headerDocument = getDocument(header);
				DocumentFragment docFrag = headerDocument.createDocumentFragment();
				Element rootElement = headerDocument.getDocumentElement();
				if (rootElement != null) {
					docFrag.appendChild(rootElement);
					Document ownerDoc = envelope.getHeader().getOwnerDocument();
					org.w3c.dom.Node replacingNode = ownerDoc.importNode(docFrag,
							true);
					envelope.getHeader().appendChild(replacingNode);
				}
			}
			if(body != null){
				envelope.getBody().addDocument(getDocument(body));
			}
			soapMsg.writeTo(os);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return os.toString();
	}
	
/*	public static void delegateCleanUp(DelegateExecution delegate){
		List<String> list = new ArrayList<String>();
		list.add(BPMNConstants._Input);
		list.add(BPMNConstants._Parameters);
		list.add(BPMNConstants._Implementation);
		list.add(BPMNConstants._Output);
		list.add(BPMNConstants._Namespaces);
		delegate.removeVariables(list);
	}*/
	
	private static String getChildString(Iterator<?> iterator)
	{
		StringWriter sw = new StringWriter();
		try {
			while (iterator.hasNext()) {
				Node node = (Node) iterator.next();
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element ele = (Element) node;
					TransformerFactory tf = TransformerFactory.newInstance();
					XXESettingUtils.setTransformerFactoryXXE(tf);
					tf.newTransformer().transform(new DOMSource(ele), new StreamResult(sw));
					break;
				}
			}
		} catch (TransformerException | TransformerFactoryConfigurationError e) {
			logger.error(e.getMessage(), e);
		}
		sw.flush();
		return trim(sw.toString());
	}
	
	public static String getConversationId(String soapPayload) {
		Map<String, String> nsMap = new HashMap<String, String>();
		nsMap.put("soap", "http://schemas.xmlsoap.org/soap/envelope/");
		nsMap.put("mh", "http://csi.cingular.com/CSI/Namespaces/Types/Public/MessageHeader.xsd");
		nsMap.put("cng", "http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd");
		return XMLUtilities.evaluateXPath(soapPayload, "/soap:Envelope/soap:Header/mh:MessageHeader/mh:TrackingMessageHeader/cng:conversationId", nsMap);
	}
	
	public static String getDateTimeStamp(String dateFormat, String timeZone){
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat format = new SimpleDateFormat(dateFormat);
		format.setTimeZone(TimeZone.getTimeZone(timeZone));
		return format.format(cal.getTime());
	}
	
	public static Document getDocument(String xml){
		Document doc = null;
		try {
			if(xml != null){
			    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			    XXESettingUtils.setDocumentBuilderFactoryXXE(factory, logger);
			    factory.setNamespaceAware(true);
				DocumentBuilder db = factory.newDocumentBuilder();
				doc = db.parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
			}
		} catch (ParserConfigurationException | SAXException | IOException e) {
			logger.error(e.getMessage(), e);
		}
		return doc;
	}
	
	private static Map<String, String> getFalloutRequestNsMap(){
		Map<String, String> nsMap = new HashMap<String, String>();
		nsMap.put("jms", "http://csi.cingular.com/CSI/Namespaces/JMS/Public/GenericFalloutM2ERequest.xsd");
		nsMap.put("pub", "http://csi.cingular.com/CSI/Namespaces/Container/Public/GenericFalloutM2ERequest.xsd");
		return nsMap;
	}

	private static Map<String, String> getFalloutResponseNsMap(){
		Map<String, String> nsMap = new HashMap<String, String>();
		nsMap.put("jms", "http://csi.cingular.com/CSI/Namespaces/JMS/Public/GenericFalloutM2EResponse.xsd");
		nsMap.put("pub", "http://csi.cingular.com/CSI/Namespaces/Container/Public/GenericFalloutM2EResponse.xsd");
		return nsMap;
	}
	
	public static String getFalloutResponseVariable(String payload, String variable){
		return XMLUtilities.evaluateXPath(payload, "/jms:GenericFalloutResponse/jms:GenericFalloutResponse/pub:" + variable, getFalloutResponseNsMap());
	}
	
	public static String getMessageHeaderInfo(String messageHeader, MESSAGE_HEADER variableName){
		String response = null;
		Map<String, String> nsMap = getMessageHeaderNamespace();
		 if(MESSAGE_HEADER.userName.equals(variableName)){
			 response = (String) XMLUtilities.evaluateXPath(messageHeader, "/mh:MessageHeader/mh:SecurityMessageHeader/cng:userName", nsMap);
		 }else if(MESSAGE_HEADER.version.equals(variableName)){
			 response = (String) XMLUtilities.evaluateXPath(messageHeader, "/mh:MessageHeader/mh:TrackingMessageHeader/cng:version", nsMap);
		 }else if(MESSAGE_HEADER.infrastructureVersion.equals(variableName)){
			 response = (String) XMLUtilities.evaluateXPath(messageHeader, "/mh:MessageHeader/mh:TrackingMessageHeader/cng:infrastructureVersion", nsMap);
		 }else if(MESSAGE_HEADER.conversationId.equals(variableName)){
			 response = (String) XMLUtilities.evaluateXPath(messageHeader, "/mh:MessageHeader/mh:TrackingMessageHeader/cng:conversationId", nsMap);
		 }else if(MESSAGE_HEADER.uniqueTransactionId.equals(variableName)){
			 response = (String) XMLUtilities.evaluateXPath(messageHeader, "/mh:MessageHeader/mh:TrackingMessageHeader/cng:uniqueTransactionId", nsMap);
		 }else if(MESSAGE_HEADER.timeToLive.equals(variableName)){
			 response = (String) XMLUtilities.evaluateXPath(messageHeader, "/mh:MessageHeader/mh:TrackingMessageHeader/cng:timeToLive", nsMap);
		 }else if(MESSAGE_HEADER.sequenceNumber.equals(variableName)){
			 response = (String) XMLUtilities.evaluateXPath(messageHeader, "/mh:MessageHeader/mh:SequenceMessageHeader/cng:sequenceNumber", nsMap);
		 }else if(MESSAGE_HEADER.totalInSequence.equals(variableName)){
			 response = (String) XMLUtilities.evaluateXPath(messageHeader, "/mh:MessageHeader/mh:SequenceMessageHeader/cng:totalInSequence", nsMap);
		 }
		 
		return response;
	}
	
	private static Map<String, String> getMessageHeaderNamespace(){
		 Map<String, String> nsMap = new HashMap<String, String>();
		 nsMap.put("mh", "http://csi.cingular.com/CSI/Namespaces/Types/Public/MessageHeader.xsd");
		 nsMap.put("cng", "http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd");
		 return nsMap;
	}
	
	public static String getSOAPBody(SOAPMessage message){
		String body = null;
		try {
			body =  getChildString(message.getSOAPBody().getChildElements());
		} catch (SOAPException e) {
			logger.error(e.getMessage(), e);
		}
		return body;
	}

	public static String getSOAPBody(String soapXml){
		return getSOAPBody(getSOAPMessage(soapXml));
	}
	
	public static String getSOAPHeader(SOAPMessage message){
		String header = null;
		try {
			header =   getChildString(message.getSOAPHeader().getChildElements());
		} catch (SOAPException e) {
			logger.error(e.getMessage(), e);
		}
		return header;
	}
	
	public static String getSOAPHeader(String soapXml){
		return getSOAPHeader(getSOAPMessage(soapXml));
	}
	
	public static SOAPMessage getSOAPMessage(String soapXml){
		SOAPMessage message = null;
		try {
			message = MessageFactory.newInstance().createMessage(null, new ByteArrayInputStream(soapXml.getBytes()));
		} catch (IOException | SOAPException e) {
			logger.error(e.getMessage(), e);
		}
		return message;
	}
	
	/*public static String getXml(Document doc)
	{
		StringWriter sw = new StringWriter();
		try {
			Transformer transformer = TransformerFactory.newInstance().newTransformer();
			transformer.transform(new DOMSource(doc), new StreamResult(sw));
		} catch (TransformerFactoryConfigurationError | TransformerException e) {
			logger.error(e.getMessage(), e);
		}
		return sw.toString();
	}*/
	
	public static List<QName> getSourceQNames(String transformName) {
		List<QName> qnames = new ArrayList<QName>();
	    try {
	        Class<?> klass = Class.forName(transformName);
	        Field field = klass.getDeclaredField("m_mapper");
	        boolean wasAccessible = field.isAccessible();
	        field.setAccessible(true);
	        TMapper tMapper = (TMapper) field.get(null);
	        boolean moreSourceRecords = true;
	    	TSourceRecord sr = tMapper.getSourceHead();
	    	
	    	if (sr != null)
	    	{        	
	        	while (moreSourceRecords) {
	    			QName qn = new QName(sr.getNamespace(), sr.getName());
	    			qnames.add(qn);
	    			sr = (TSourceRecord)sr.getNext();
	    			if (sr == null) {
	    				moreSourceRecords = false;
	    			}
	    		}
	    	}
	       field.setAccessible(wasAccessible);
	    } catch (Throwable e) {
	    	throw new RuntimeException(transformName +  " - Unable to reflectively obtain access to necessary transform input QName's", e);          
	    }
	    return qnames;
	}
	
	public static String invokeContivo(String transformClassName, String inputs[]) throws Exception {
		TransformAny tAny = null;
		Class transformClass= Class.forName(transformClassName);
		ITransform xform = (ITransform)transformClass.newInstance();	
		String version = (String) transformClass.getMethod("getProperty", String.class).invoke(xform, IPropertyNames.PROPERTY_ANALYSTVERSION);
		if (version.contains("5.6")) {
			tAny = new TransformAny(xform);
		}
		else {
			tAny = new TransformAny(transformClassName);
		}
		tAny.setKeepInstance(false);
		for (int i = 0; i < inputs.length; i++) {
			InputStream in = IOUtils.toInputStream(trim(inputs[i]), "UTF-8");
	        DocSpec docSpec = new DocSpec(in);
	        tAny.addSource(docSpec);
		}
		StringWriter outData = new StringWriter();
        DocSpec outputSpec = new DocSpec(outData);
        tAny.toTargetDoc(outputSpec);
        
        TransformAnyResults tAnyResults = tAny.getResults();
        if(tAnyResults.hasFatalError()) {
			String msg = tAnyResults.getFatalErrorMessageAsString(true);
			Exception exception = new Exception(msg);
			throw exception;
		}

        if(tAnyResults.hasTransformException()){
			String msg = tAnyResults.getTransformException().getMessage();
			Exception exception = new Exception(msg);
			throw exception;
		}
		return outData.toString();
	}
	
	public static Map<String, String> loadKeyValueMap(String line){
		Map<String, String> map = new HashMap<String, String>(4);;
		try
		{
			if(line != null){
				String[] tokens = line.split(" *, *");
				for (int i = 0; i < tokens.length; i++) {
					String[] tokens2 = tokens[i].trim().split(" *= *");
					if(tokens2.length>1) 
						map.put(tokens2[0].trim(), tokens2[1].trim());
					else{
						String prevKey = tokens[i - 1].trim().split(" *= *")[0]; 
						String prevVal = map.get(prevKey);
						map.put(prevKey, prevVal + ","+ tokens[i]);
					}
				}
			}
		}catch(Exception e){
			logger.error(line, e);
		}
		return map;
	}
	
	public static List<String> loadList(String line){
		List<String> list = new ArrayList<String>(1);
		if(line != null){
			String[] tokens = line.split(" *, *");
			for (int i = 0; i < tokens.length; i++) 
				list.add(tokens[i].trim());
		}
		return list;
	}
	
	public static Map<String, String> loadParameterMap(DelegateExecution delegate, String line){
		Map<String, String> map = loadKeyValueMap(line);
		Map<String, String> finalMap = new HashMap<String, String>();
		Set<Entry<String, String>> entrySet = map.entrySet();
		for (Iterator<Entry<String, String>> iterator = entrySet.iterator(); iterator.hasNext();) {
			Entry<String, String> entry = iterator.next();
			if(entry.getValue() != null && entry.getValue().startsWith("$")){
				finalMap.put(entry.getKey(), (String) delegate.getVariable(entry.getValue().replace("$", "")));
			}else{
				finalMap.put(entry.getKey(), entry.getValue());
			}
		}
		return finalMap;
	}
	
	/*public static void logDelegate(DelegateExecution delegate){
		if(logger.isDebugEnabled()){
			StringBuilder builder = new StringBuilder();
			builder.append("[ID:" + delegate.getCurrentActivityId());
			builder.append("|Name:" + delegate.getCurrentActivityName());
			Map<String, String> map = BPMNUtilities.loadParameterMap(delegate, (String) delegate.getVariable(BPMNConstants._Parameters)) ;
			if(map.size() > 0){
				builder.append("|_Parameters:" + map);
			}
			map = BPMNUtilities.loadKeyValueMap((String) delegate.getVariable(BPMNConstants._Implementation)) ;
			if(map.size() > 0){
				builder.append("|_Implementation:" + map);
			}
			map = BPMNUtilities.loadKeyValueMap((String) delegate.getVariable(BPMNConstants._Namespaces)) ;
			if(map.size() > 0){
				builder.append("|_Namespaces:" + map);
			}
			List<String> list = BPMNUtilities.loadList((String) delegate.getVariable(BPMNConstants._Input)) ;
			if(list.size() > 0){
				builder.append("|_Input:" + list);
			}
			list = BPMNUtilities.loadList((String) delegate.getVariable(BPMNConstants._Output)) ;
			if(list.size() > 0){
				builder.append("|_Output:" + list);
			}
			builder.append("]");
			logger.debug(builder.toString());
		}
	}*/
	
	public static void logOutput(DelegateExecution delegate, String outputVariable, Object outputValue){
		if(logger.isDebugEnabled()){
			StringBuilder builder = new StringBuilder();
			builder.append("[ID:" + delegate.getCurrentActivityId() + "|");
			builder.append("Name:" + delegate.getCurrentActivityName() + "|");
			builder.append("Output:[" + outputVariable + "=" + outputValue + "]]");
			logger.debug(builder.toString());
		}
	}

	public static String setFalloutRequestVariable(String payload, String variableName, String value){
		return XMLUtilities.replaceElement(payload, "/jms:GenericFalloutRequest/jms:GenericFalloutRequest/pub:" + variableName, getFalloutRequestNsMap(), value);
	}
	
	public static String setMessageHeaderInfo(String messageHeader, String value, MESSAGE_HEADER variableName){
		String response = messageHeader;
		Map<String, String> nsMap = getMessageHeaderNamespace();
		 if(MESSAGE_HEADER.userName.equals(variableName)){
			 response = XMLUtilities.replaceElement(messageHeader, "/mh:MessageHeader/mh:SecurityMessageHeader/cng:userName", nsMap, value);
		 }else if(MESSAGE_HEADER.version.equals(variableName)){
			 response = XMLUtilities.replaceElement(messageHeader, "/mh:MessageHeader/mh:TrackingMessageHeader/cng:version", nsMap, value);
		 }else if(MESSAGE_HEADER.infrastructureVersion.equals(variableName)){
			 response = XMLUtilities.replaceElement(messageHeader, "/mh:MessageHeader/mh:TrackingMessageHeader/cng:infrastructureVersion", nsMap, value);
		 }
		return response;
	}

	private static String trim(String xml){
		if (xml.startsWith(UTF8_BOM)) {
			xml = xml.substring(1);
        }
		return xml;
	}
	
	public static void logAttributes(HttpServletRequest  request){
		if(logger.isDebugEnabled()){
			StringBuilder builder = new StringBuilder();
			Enumeration<String> attribs = request.getAttributeNames();
			builder.append("Attributes[");
			while (attribs.hasMoreElements()) {
				String attr = (String) attribs.nextElement();
				builder.append(attr + ":" + request.getAttribute(attr));
			}
			builder.append("]Header[");
			attribs = request.getHeaderNames();
			while (attribs.hasMoreElements()) {
				String attr = (String) attribs.nextElement();
				builder.append(attr + ":" + request.getHeader(attr));
			}
			builder.append("]");
			logger.debug(builder.toString());
		}
	}
	
	
	public static void logDelegate(DelegateExecution delegate){
		if(logger.isDebugEnabled()){
			StringBuilder builder = new StringBuilder();
			builder.append("[ID:" + delegate.getCurrentActivityId());
			builder.append("|Name:" + delegate.getCurrentActivityName());
			Map<String, String> map = BPMNUtilities.loadParameterMap(delegate, (String) delegate.getVariable(BPMNConstants._Parameters)) ;
			if(map.size() > 0){
				builder.append("|_Parameters:" + map);
			}
			map = BPMNUtilities.loadKeyValueMap((String) delegate.getVariable(BPMNConstants._Implementation)) ;
			if(map.size() > 0){
				builder.append("|_Implementation:" + map);
			}
			map = BPMNUtilities.loadKeyValueMap((String) delegate.getVariable(BPMNConstants._Namespaces)) ;
			if(map.size() > 0){
				builder.append("|_Namespaces:" + map);
			}
			List<String> list = BPMNUtilities.loadList((String) delegate.getVariable(BPMNConstants._Input)) ;
			if(list.size() > 0){
				builder.append("|_Input:" + list);
			}
			list = BPMNUtilities.loadList((String) delegate.getVariable(BPMNConstants._Output)) ;
			if(list.size() > 0){
				builder.append("|_Output:" + list);
			}
			builder.append("]");
			logger.debug(builder.toString());
		}
	}
	
	
	public static void delegateCleanUp(DelegateExecution delegate){
		List<String> list = new ArrayList<String>();
		list.add(BPMNConstants._Input);
		list.add(BPMNConstants._Parameters);
		list.add(BPMNConstants._Implementation);
		list.add(BPMNConstants._Output);
		list.add(BPMNConstants._Namespaces);
		delegate.removeVariables(list);
	}
}
