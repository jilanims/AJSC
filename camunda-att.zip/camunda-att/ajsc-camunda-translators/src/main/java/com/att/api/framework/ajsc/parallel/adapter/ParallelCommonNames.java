package com.att.api.framework.ajsc.parallel.adapter;

/**
 * @author jp931e
 *
 */
public class ParallelCommonNames {
	
	//common
	public static final String CSI_INVOKE_SERVICEREQUEST = "CSI_INVOKE_SERVICEREQUEST";
	public static final String CSI_INVOKE_SERVICERESPONSE = "CSI_INVOKE_SERVICERESPONSE";
	
	public static final String CSI_INVOKESERVICE_SERVICEREQUEST ="CSI_INVOKESERVICE_SERVICEREQUEST";
	
	public static final String CSI_INVOKE_TIMEOUT = "CSI_INVOKE_TIMEOUT";
	public static final String CSI_INVOKE_MODE = "CSI_INVOKE_MODE";
	public static final String CSI_INVOKE_SVCKEYDATA1 = "CSI_INVOKE_SVCKEYDATA1";
	public static final String CSI_INVOKE_SVCKEYDATA2 = "CSI_INVOKE_SVCKEYDATA2";
	public static final String CSI_TARGET_SERVICE_NAME ="CSI_TARGET_SERVICE_NAME";
	public static final String ATTR_START_TIME ="ATTR_START_TIME";
	public static final String PARTNER_PROFILE_CLIENT ="PARTNER_PROFILE_CLIENT";
	
	//Invoke Service
	public static final String CSI_TARGET_SERVICE_VERSION ="CSI_TARGET_SERVICE_VERSION";
	public static final String CSI_INVOKESERVICE_JMSIGNORE_ACK = "CSI_INVOKESERVICE_JMSIGNORE_ACK";
	public static final String CSI_INVOKESERVICE_TGTVOLTAGESTATE ="CSI_INVOKESERVICE_TGTVOLTAGESTATE";
	public static final String CSI_INVOKESERVICE_CALTARGETGSMSESSIONKEY = "CSI_INVOKESERVICE_CALTARGETGSMSESSIONKEY";
	public static final String CSI_INVOKESERVICE_MH_MESSAGE_ID ="CSI_INVOKESERVICE_MH_MESSAGE_ID";
	public static final String CSI_INVOKESERVICE_MH_VERSION = "CSI_INVOKESERVICE_MH_VERSION";
	public static final String CSI_INVOKESERVICE_GSMSESSIONKEY = "CSI_INVOKESERVICE_GSMSESSIONKEY";
	public static final String CSI_INVOKESERVICE_CROSSRELSUPPORT ="CSI_INVOKESERVICE_CROSSRELSUPPORT";
	
	
	//Invoke Adapter
	public static final String CSI_TARGET_ADAPTER_METHOD ="CSI_TARGET_ADAPTER_METHOD";
	public static final String CSI_ADAPTER_MESSAGEHEADER ="CSI_ADAPTER_MESSAGEHEADER";
	public static final String CSI_ADAPTER_SUBSCRIBER ="CSI_ADAPTER_SUBSCRIBER";
	public static final String CSI_INVOKEADAPTER_MDL = "CSI_INVOKEADAPTER_MDL";
	public static final String CSI_INVOKEADAPTER_BAN = "CSI_INVOKEADAPTER_BAN";
		
	//additional variables
	public static final String PERFORMANCE_TRACKER_BEAN = "PERFORMANCE_TRACKER_BEAN";
	public static final String INVOKE_SERVICE_NAME ="INVOKE_SERVICE_NAME";
	
	//Parallel or Serial Adapter call
	public static final String PARALLEL_SERIAL_ADAPTER = "PARALLEL_SERIAL_ADAPTER";
	
	// Service XML root Element name
	public static final String SERVICE_XML_ELEMENT_NAME = "SERVICE_XML_ELEMENT_NAME";
	public static final String TARGET_NAMESPACE = "TARGET_NAMESPACE";
}
