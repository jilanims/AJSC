package com.att.api.framework.ajsc.adapter.atlas;

import java.util.HashMap;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.engine.variable.Variables;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.api.framework.common.atlas.InvokeAtlasAdapterParams;
import com.att.api.framework.common.atlas.InvokeGenericAsyncAdapter;
import com.att.api.framework.common.configurationmanager.PropertyManager;

public class InvokeAtlasJMSDelegate implements JavaDelegate{
	
	private static final Logger logger = LoggerFactory.getLogger(InvokeAtlasJMSDelegate.class);

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		logger.debug(" ************ InvokeAtlasJMSDelegate start ******************************* ");
		PropertyManager pm = new PropertyManager();
		
		execution.setVariable("CSI_ATLAS_JMS_RESPONSE", null);
		
		InvokeAtlasAdapterParams  invokeAtlasAdapterParams = new InvokeAtlasAdapterParams();
		invokeAtlasAdapterParams.setReqQueueName((String)execution.getVariable("CSI_ATLAS_JMS_QNAME"));
		invokeAtlasAdapterParams.setSolaceJNDILookup(true);
		String timeoutST = (String)execution.getVariable("CSI_ATLAS_JMS_TIME_TO_LIVE");
		
		Long ttl = 30000L;
		
		if(timeoutST!=null){
			ttl = Long.valueOf(timeoutST);
		}
		ttl = ttl + System.currentTimeMillis();
		invokeAtlasAdapterParams.setTimeToLive(Long.toString(ttl)); //lastMoment
		invokeAtlasAdapterParams.setProviderJMSPropFileName("ATLAS_OUTGOING");
		
		String prvRequest = (String)execution.getVariable("CSI_ATLAS_PREVREQUEST");		
		logger.info("CSI_ATLAS_PREVREQUEST:{}",prvRequest);
		HashMap<String,Object> asyncMapResponse = (HashMap<String,Object>)InvokeGenericAsyncAdapter.invokeAsyncAdapter(invokeAtlasAdapterParams, prvRequest);
		if(asyncMapResponse!=null){			
			//execution.setVariable("CSI_ATLAS_JMS_RESPONSE", asyncMapResponse.get("TimeToLive"));
			execution.setVariable("CSI_ATLAS_JMS_RESPONSE", Variables.objectValue(asyncMapResponse.get("TimeToLive")).create());
		}
		logger.debug(" ************ InvokeAtlasJMSDelegate end ******************************* ");
	}

}
