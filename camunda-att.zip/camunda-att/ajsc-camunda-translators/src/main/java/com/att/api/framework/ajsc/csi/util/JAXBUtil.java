package com.att.api.framework.ajsc.csi.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;

/**
 * @author jn448j
 *
 */
public class JAXBUtil {
	
	private JAXBContext jc = null;
	private Unmarshaller unmarshaller = null;
	private Marshaller marshaller = null;

	public JAXBUtil(String packageName) {
		try {
			jc = JAXBContext.newInstance(packageName);
			unmarshaller = jc.createUnmarshaller();
			marshaller = jc.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,
					Boolean.TRUE);
		} catch (JAXBException e) {
			e.printStackTrace();
		}
	}

	public Object unmarshall(File file){
		JAXBElement jaxbElement = null;
		try {
			jaxbElement = (JAXBElement) unmarshaller.unmarshal(file);
		} catch (JAXBException e) {
			e.printStackTrace();
		}
		return jaxbElement.getValue();
	}
	
	public Object unmarshall(String xml){
		JAXBElement jaxbElement = null;
		try {
			jaxbElement = (JAXBElement) unmarshaller.unmarshal(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
		} catch (JAXBException e) {
			e.printStackTrace();
		}
		return jaxbElement.getValue();
	}
	
	public void marshall(Object obj, File file){
		try {
			marshaller.marshal(obj, file);
		} catch (JAXBException e) {
			e.printStackTrace();
		}
	}
	
	public String marshall(Object obj){
		String value = null;
		try {
			ByteArrayOutputStream os = new ByteArrayOutputStream();
			marshaller.marshal(obj, os);
			value = new String(os.toByteArray(),"UTF-8");
		} catch (JAXBException | UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return value; 
	}
	
	public String marshall(QName rootElement, Object obj){
		String value = null;
		try {
			ByteArrayOutputStream os = new ByteArrayOutputStream();
			marshaller.marshal(new JAXBElement(rootElement, obj.getClass() ,obj), os);
			value = new String(os.toByteArray(),"UTF-8");
		} catch (JAXBException | UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return value; 
	}
	
	public void marshall(QName rootElement, Object obj, File file){
		try {
			marshaller.marshal(new JAXBElement(rootElement, obj.getClass() ,obj), file);
		} catch (JAXBException e) {
			e.printStackTrace();
		}
	}
}
