package com.att.api.framework.ajsc.parallel.adapter;

import org.slf4j.Logger;

import com.att.api.framework.common.logging.TransactionLogger;

public class TransactionLoggerImpl implements TransactionLogger{
	
	private String conversationId;
	private String guid;
	private String engine;
	private String serviceName;
	private String methodName;
	private String downstreamSystem;
	
	public String getConversationId() {
		return conversationId;
	}
	
	public void setConversationId(String conversationId) {
		this.conversationId = conversationId;
	}
	
	public String getGuid() {
		return guid;
	}
	
	public void setGuid(String guid) {
		this.guid = guid;
	}
	
	public String getEngine() {
		return engine;
	}
	
	public void setEngine(String engine) {
		this.engine = engine;
	}
	
	public String getServiceName() {
		return serviceName;
	}
	
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	
	public String getMethodName() {
		return methodName;
	}
	
	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}
	
	public String getDownstreamSystem() {
		return downstreamSystem;
	}
	
	public void setDownstreamSystem(String downstreamSystem) {
		this.downstreamSystem = downstreamSystem;
	}

	@Override
	public Logger getDebugLogger() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isDebugEnabled() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void logTrace(Object... params) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void logDebug(Object... params) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void logInfo(Object... params) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void logWarn(Object... params) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void logException(Object... params) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void logError(Object... params) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void logCritical(Object... params) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void logPrivateRequest(Object... params) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void logPrivateResponse(Object... params) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void logAdapterRequest(Object... params) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void logAdapterResponse(Object... params) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void logServiceManagerException(Object... params) {
		// TODO Auto-generated method stub
		
	}
	
}
