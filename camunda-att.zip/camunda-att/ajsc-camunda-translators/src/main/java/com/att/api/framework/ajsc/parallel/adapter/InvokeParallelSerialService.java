package com.att.api.framework.ajsc.parallel.adapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.api.framework.ajsc.adapter.AdapterCommonNames;
import com.att.api.framework.ajsc.csi.framework.service.AjscIntroscopeService;
import com.att.m2e.csi.common.exceptions.CSIControlException;
import com.att.api.framework.common.adapter.MAFApiTransImpl;
import com.att.api.framework.common.adapter.MAFRemoteAdapter.MAFRemoteFuture;
import com.att.api.framework.common.logging.APITransactionLogger;
import com.att.api.framework.common.logging.PerformanceTrackingRecord;
import com.att.api.framework.common.logging.PerformanceTrackingTrailMark;
import com.att.api.framework.common.logging.TransactionLogger;
import com.att.api.framework.common.parallelrequest.ProcessRequestParams;
import com.att.api.framework.common.service.InvokeService.InvokeServiceFuture;
import com.att.api.framework.common.service.InvokeServiceParams;
import com.att.api.framework.common.state.api.AJSCTransactionStateImpl;
import com.att.api.framework.common.utils.CommonNames;
import com.att.api.framework.common.utils.CommonUtil;
import com.att.api.framework.jaxb.requestparameters.RequestParameters;
import com.att.env.APIException;


/**
 * @author jp931e
 *
 */
public class InvokeParallelSerialService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(InvokeParallelSerialService.class);
	private long minTimeout = 2000;	
	private String callingServiceName = null, convId = null, userName =null, uniqueID=null;
	
	public final HashMap<String, Object> invokeService(HashMap<String, Object> mapVariables) throws Exception{
		
		AJSCTransactionStateImpl state = (AJSCTransactionStateImpl)mapVariables.get(CommonNames.TRANSACTION_STATE);
		PerformanceTrackingRecord tracking = state.getTrackingRecord();
		
		ArrayList<Future<String>> responseFutureObjects = null;
		ArrayList<Object> responseObjects = null;
		
		callingServiceName = (String)mapVariables.get(ParallelCommonNames.INVOKE_SERVICE_NAME);
		//Operational Parameters
		userName = (String) mapVariables.get(AdapterCommonNames.PARTNER_PROFILE_CLIENT);
		if(userName==null || userName==""){
			userName ="ajscUser"; //default user
		}
		convId = (String)mapVariables.get(CommonNames.HEADER_ATT_CONVERSATION_ID);
		
		uniqueID = (String)mapVariables.get(CommonNames.HEADER_ATT_UNIQUE_TXN_ID);
		
		String  key, ttl = null;	
		if(state.getRequestParameters().getHeader()!=null){
	    	for (int i=0; i<state.getRequestParameters().getHeader().getPair().size(); i++) {
	    		key = state.getRequestParameters().getHeader().getPair().get(i).getKey();
	    		if (key.equalsIgnoreCase(CommonNames.HEADER_ATT_TIME_TO_LIVE))
					ttl = state.getRequestParameters().getHeader().getPair().get(i).getValue();
	    		else if (key.equalsIgnoreCase(CommonNames.HEADER_ATT_CONVERSATION_ID))
					convId = state.getRequestParameters().getHeader().getPair().get(i).getValue();				
				else if (key.equalsIgnoreCase(CommonNames.CSI_USER_NAME))
					userName = state.getRequestParameters().getHeader().getPair().get(i).getValue(); 
				else if (key.equalsIgnoreCase(CommonNames.HTTP_AUTHORIZATION)) {
					String authHeader = state.getRequestParameters().getHeader().getPair().get(i).getValue();
					if (authHeader != null) {
						userName = CommonUtil.extractUserNameFromHeader(authHeader);
					}
				}
			}
		}
	
		String adapterType = (String)mapVariables.get(ParallelCommonNames.PARALLEL_SERIAL_ADAPTER);
		
		ArrayList<String> inputArrayList = (ArrayList<String>) mapVariables.get(ParallelCommonNames.CSI_INVOKESERVICE_SERVICEREQUEST);
		if (inputArrayList == null ||inputArrayList.size()==0) {
			throw new Exception("Empty Request");
		}
		String[] messageArray = new String[inputArrayList.size()];
		messageArray = inputArrayList.toArray(messageArray);		

		String targetService = (String)mapVariables.get(ParallelCommonNames.CSI_TARGET_SERVICE_NAME);
		if (targetService == null || targetService.isEmpty()) {
			throw new Exception("CSI_TARGET_SERVICE_NAME is empty");
		}
		String methodName = (String)mapVariables.get(ParallelCommonNames.CSI_TARGET_ADAPTER_METHOD);
		
		//Operational Parameters		
		if(mapVariables.get(ParallelCommonNames.PARTNER_PROFILE_CLIENT)!=null){
			userName = (String) mapVariables.get(ParallelCommonNames.PARTNER_PROFILE_CLIENT);
		}
		
		PerformanceTrackingTrailMark trailMark = tracking.addTrailMark("InvokeParallelAdapter");
		try {
			
			ProcessRequestParams parallelRequestParams = new ProcessRequestParams();
			
			if(methodName!=null){
				//Invoke Adapter Call
				//TransactionLogger logger = new TransactionLoggerImpl();				
				MAFApiTransImpl mafTrans = getAjscTransImpl(mapVariables, state, callingServiceName);	
				parallelRequestParams.setMafTrans(mafTrans);
				
				//set default dataContext //TODO
				String[] dataContextArray = new String[messageArray.length];
				for(int kk=0; kk<messageArray.length; kk++){
					dataContextArray[kk] = "";
				}
				//dataContextArray[0] = "205977";
				parallelRequestParams.setDataContextArray(dataContextArray);
				
				//check for partner
				if(null==parallelRequestParams.getPartner()){					
					parallelRequestParams.setPartner(userName);				
				}
				
				String stickySelector = System.getProperty("com.att.aft.dme2.jms.stickySelectorKey");
				parallelRequestParams.setStickySelector(stickySelector);
				
			}else{
				//Invoke Service Call
				InvokeServiceParams invokeServiceParams = getAjscEnvImpl(mapVariables, state, callingServiceName);			
				parallelRequestParams.setInvokeServiceParams(invokeServiceParams);
			}
					
			//Introscope instrumentation call before the downstream call
			AjscIntroscopeService.callIntroscopeSyncMethod(uniqueID, convId, userName, callingServiceName, AjscIntroscopeService.CallType.ENTRY, AjscIntroscopeService.INVOKE_SERVICE);
		
			if(messageArray instanceof String[]){
				switch (adapterType) {
				case "PARALLEL":
					responseFutureObjects = com.att.api.framework.common.parallelrequest.ProcessRequest.processRequest(parallelRequestParams, messageArray);
					if(responseFutureObjects!=null){			
						responseObjects = new ArrayList<Object>();
						for(int kk=0; kk<responseFutureObjects.size(); kk++){	
							if(responseFutureObjects.get(kk) instanceof MAFRemoteFuture){							
								responseObjects.add(responseFutureObjects.get(kk).get());
							}else if (responseFutureObjects.get(kk) instanceof InvokeServiceFuture) {
								responseObjects.add(responseFutureObjects.get(kk).get());
							}		
						}
					}	
					break;
				case "SERIAL":					
					long timeLeft = getTimeLeft(mapVariables, ttl);
					parallelRequestParams.setTimeLeft(timeLeft); //This property is required for serial request call
					//parallelRequestParams.getOverrideTimeoutMillis(overideTimeoutGV); //This property can be set to override the timeout set from gateway (only for serial request call)
					long overridedLastMoment = timeLeft + System.currentTimeMillis();
					parallelRequestParams.setTheLastMoment(overridedLastMoment); //This property is required for serial request call. (last moment, ie., timeout + current system milliseconds)
					
					
					responseObjects = com.att.api.framework.common.serialrequest.SerialRequest.serialRequest(parallelRequestParams, messageArray);
					break;
				}
			} else {
				throw new APIException("Input request message is not an String");
			}			
			
		}catch (APIException apie) {//TODO : Need to do the necessary changes when AJSC error / exception handling stories are completed.			
			//this.handleException(apie);
			throw apie;				
		}catch (Exception e) {			
			throw new APIException(e);				
		} finally {
			trailMark.done();	
			//Introscope instrumentation call after the downstream call
			AjscIntroscopeService.callIntroscopeSyncMethod(uniqueID, convId, userName, callingServiceName, AjscIntroscopeService.CallType.EXIT, AjscIntroscopeService.INVOKE_SERVICE);						
		}
		
		
		mapVariables.put(ParallelCommonNames.CSI_INVOKE_SERVICERESPONSE, responseObjects);
		return mapVariables;
	}
	
	public void handleException(Object ob) throws Exception{
		
		if(ob instanceof APIException){
			APIException st = (APIException)ob;					
			//System.out.println("Response XML:"+st.getMessage());							
		}else if(ob instanceof ExecutionException){
			ExecutionException st = (ExecutionException)ob;	
			//System.out.println("Response XML cause:"+st.getCause().toString());
			//System.out.println("Response XML:"+st.getMessage());		
		}else{
			if (ob instanceof MAFRemoteFuture) {
				String st = ((MAFRemoteFuture)ob).get();
				//System.out.println("Response XML:"+st);
			}else if (ob instanceof InvokeServiceFuture) {
				String st = ((InvokeServiceFuture)ob).get();				
				//System.out.println("Response XML:"+st);
			}
		}
	}
	private long getTimeLeft(HashMap<String, Object> mapVariables, String ttl){
		long timeLeft = 0L;
		Object tempTimeLeft = mapVariables.get(ParallelCommonNames.CSI_INVOKE_TIMEOUT);
		if (tempTimeLeft == null) {
			timeLeft = 0L;
		} else {
			timeLeft = Long.valueOf(tempTimeLeft.toString());
		}
		if (timeLeft < minTimeout) {
			//TODO check timeleft with start time
			long stime = Long.parseLong((String) mapVariables.get(ParallelCommonNames.ATTR_START_TIME));
			if(ttl!=null)
			timeLeft = Integer.parseInt(ttl) - (System.nanoTime()/1000000 - stime);
		}
		return timeLeft;
	}
	
	/**
	 * @param exchange
	 * @param perfTrackerBean
	 * @param callingServiceName
	 * @return InvokeServiceParams
	 * @throws Exception
	 */
	private InvokeServiceParams getAjscEnvImpl(HashMap<String, Object> mapVariables, AJSCTransactionStateImpl transState, String callingServiceName)
			throws Exception {

		
		long timeToLive = 0L;		
		TransactionLogger logger = new APITransactionLogger(callingServiceName);
		RequestParameters reqParam = ((AJSCTransactionStateImpl)transState).getRequestParameters();
		
		

		String targetService = (String)mapVariables.get(ParallelCommonNames.CSI_TARGET_SERVICE_NAME);
		if (targetService == null || targetService.isEmpty()) {
			throw new Exception("CSI_INVOKESERVICE_NAME is empty");
		}

		String targetVersion = (String)mapVariables.get(ParallelCommonNames.CSI_TARGET_SERVICE_VERSION);
		if (targetVersion == null || targetVersion.isEmpty()) {
			throw new Exception("CSI_INVOKESERVICE_VERSION is empty");
		}
		
		String instanceName = "UNSPECIFIED_AJSC_CAMUNDA_INSTANCE";
		
		String key, ttl = null, timeStamp=null, serviceKeyData1 = "", serviceKeyData2 = "";	
		if(reqParam.getHeader()!=null){
	    	for (int i=0; i<reqParam.getHeader().getPair().size(); i++) {
				key = reqParam.getHeader().getPair().get(i).getKey();
				if (key.equalsIgnoreCase(CommonNames.SERVICE_KEY_DATA1))
					serviceKeyData1 = reqParam.getHeader().getPair().get(i).getValue();
				else if (key.equalsIgnoreCase(CommonNames.SERVICE_KEY_DATA2))
					serviceKeyData2 = reqParam.getHeader().getPair().get(i).getValue();			
				else if (key.equalsIgnoreCase(CommonNames.HEADER_ATT_TIME_TO_LIVE))
					ttl = reqParam.getHeader().getPair().get(i).getValue();				
				else if (key.equalsIgnoreCase(CommonNames.HEADER_ATT_DATE_TIME_STAMP))
					timeStamp = reqParam.getHeader().getPair().get(i).getValue();				
			}
		}
		
		long timeLeft = getTimeLeft(mapVariables, ttl);
		//System.out.println("timeLeft:"+timeLeft);
		timeToLive = timeLeft + System.currentTimeMillis();

		String mode = (String)mapVariables.get(ParallelCommonNames.CSI_INVOKE_MODE);
		if (mode == null  ||  mode.isEmpty())
		{
			mode = "";
		};

		String jmsIgnoreAck = (String)mapVariables.get(ParallelCommonNames.CSI_INVOKESERVICE_JMSIGNORE_ACK);
		if (jmsIgnoreAck == null  ||  jmsIgnoreAck.isEmpty())
		{
			jmsIgnoreAck = "";
		}

		boolean targetVoltageState = false;
		String targetVoltageStateStr = (String)mapVariables.get(ParallelCommonNames.CSI_INVOKESERVICE_TGTVOLTAGESTATE);
		if (targetVoltageStateStr != null  &&  targetVoltageStateStr.equalsIgnoreCase("true"))
		{
			targetVoltageState = true;
		}

		boolean calculateTargetGSMSessionKey = false;
		String calculateTargetGSMSessionKeyStr = (String)mapVariables.get(ParallelCommonNames.CSI_INVOKESERVICE_CALTARGETGSMSESSIONKEY);
		if (calculateTargetGSMSessionKeyStr != null  &&  calculateTargetGSMSessionKeyStr.equalsIgnoreCase("true"))
		{
			calculateTargetGSMSessionKey = true;
		}

		String mhMessageId= (String)mapVariables.get(ParallelCommonNames.CSI_INVOKESERVICE_MH_MESSAGE_ID);
		if (mhMessageId == null  ||  mhMessageId.isEmpty())
		{
			mhMessageId = "";
		}	
		String mhVersion= (String)mapVariables.get(ParallelCommonNames.CSI_INVOKESERVICE_MH_VERSION);
		if (mhVersion == null  ||  mhVersion.isEmpty())
		{
			mhVersion = "";
		}
		String gsmSessionKey= (String)mapVariables.get(ParallelCommonNames.CSI_INVOKESERVICE_GSMSESSIONKEY);
		
		String crossReleaseSupport= (String)mapVariables.get(ParallelCommonNames.CSI_INVOKESERVICE_CROSSRELSUPPORT);
			
		
		//String engineName = "UNSPECIFIED_AJSC_INSTANCE";
		logger.setConversationId(convId);
		logger.setEngine(instanceName);
		//logger.setTimeout(timeToLive);
		logger.setServiceName(callingServiceName);	
		logger.setGuid(uniqueID);
		logger.setDownstreamSystem(targetService);
		
		InvokeServiceParams serviceParams = new InvokeServiceParams(logger);		
		serviceParams.setMode(mode);
		serviceParams.setServiceKeyData1(serviceKeyData1);
		serviceParams.setServiceKeyData2(serviceKeyData2);
		serviceParams.setClientApp("AJSC-CSI~"+instanceName +"~"+callingServiceName);
		serviceParams.setServiceName(callingServiceName);
		serviceParams.setPartner(userName);
		serviceParams.setGuid(uniqueID);

		serviceParams.setInvokeServiceName(targetService);			
		serviceParams.setTargetVersion(targetVersion); // required for getting the service version from mepom file...
		serviceParams.setCalculateTargetGSMSessionKey(calculateTargetGSMSessionKey);
		serviceParams.setCrossReleaseSupport(crossReleaseSupport);
		serviceParams.setGsmSessionKey(gsmSessionKey);
		serviceParams.setMhMessageId(mhMessageId);
		serviceParams.setMhVersion(mhVersion);
		serviceParams.setJmsIgnoreAck(jmsIgnoreAck);
		serviceParams.setTargetVoltageState(targetVoltageState);
		serviceParams.setTimeToLive(timeToLive); //used in txtmsg. set time to live		timeLeft + System.currentTimeMillis();
		serviceParams.setOverridedLastMoment(timeToLive); // used in MessageProducer.send()
		serviceParams.setApplEnvContext(System.getProperty("defaultDME2EnvContext"));
		serviceParams.setApplEnvVersion(targetVersion);
		serviceParams.setStickySelector(System.getProperty("com.att.aft.dme2.jms.stickySelectorKey"));
		return serviceParams;
	}
	
	/**
	 * @param exchange
	 * @param perfTrackerBean
	 * @param callingServiceName
	 * @return MAFAjscTransImpl
	 * @throws Exception
	 */
	private MAFApiTransImpl getAjscTransImpl(HashMap<String, Object> mapVariables, AJSCTransactionStateImpl transState, String callingServiceName)
	throws Exception {
		
		//ApiLogger logger = new ApiLogger(callingServiceName);
		//TransactionLogger logger = new TransactionLoggerImpl();
		
		TransactionLogger logger = new APITransactionLogger(callingServiceName);
		//MAFApiTransImpl mafTrans = new MAFApiTransImpl(logger);
		RequestParameters reqParam = ((AJSCTransactionStateImpl)transState).getRequestParameters();
		
				
		String mode = (String)mapVariables.get(ParallelCommonNames.CSI_INVOKE_MODE);    	
    	if (mode == null  ||  mode.isEmpty())
    	{
    		mode = "";
    	};
		
    	String key, ttl = null, timeStamp=null, serviceKeyData1 = "", serviceKeyData2 = "";	
		if(reqParam.getHeader()!=null){
	    	for (int i=0; i<reqParam.getHeader().getPair().size(); i++) {
				key = reqParam.getHeader().getPair().get(i).getKey();
				if (key.equalsIgnoreCase(CommonNames.SERVICE_KEY_DATA1))
					serviceKeyData1 = reqParam.getHeader().getPair().get(i).getValue();
				else if (key.equalsIgnoreCase(CommonNames.SERVICE_KEY_DATA2))
					serviceKeyData2 = reqParam.getHeader().getPair().get(i).getValue();			
				else if (key.equalsIgnoreCase(CommonNames.HEADER_ATT_TIME_TO_LIVE))
					ttl = reqParam.getHeader().getPair().get(i).getValue();				
				else if (key.equalsIgnoreCase(CommonNames.HEADER_ATT_DATE_TIME_STAMP))
					timeStamp = reqParam.getHeader().getPair().get(i).getValue();				
			}
		}
    	
	    String adapterName = (String)mapVariables.get(ParallelCommonNames.CSI_TARGET_SERVICE_NAME);		
	    if (adapterName == null || adapterName.isEmpty()) {
			throw new Exception("CSI_TARGET_SERVICE_NAME is empty");
		}
		
	    String adapterMethod = (String)mapVariables.get(ParallelCommonNames.CSI_TARGET_ADAPTER_METHOD);		
		if (adapterMethod == null || adapterMethod.isEmpty()) {
			throw new Exception("CSI_TARGET_ADAPTER_METHOD is empty");
		}
		
	    String messageHeader = (String)mapVariables.get(ParallelCommonNames.CSI_ADAPTER_MESSAGEHEADER);
	    String ban = (String)mapVariables.get(ParallelCommonNames.CSI_INVOKEADAPTER_BAN);
		if (ban == null || ban.isEmpty()) {
			ban = "N/A";
		}
		
	    String subscriber = (String)mapVariables.get(ParallelCommonNames.CSI_ADAPTER_SUBSCRIBER);
		if (subscriber == null || subscriber.isEmpty()) {
			subscriber = "N/A";
		}
		
	    Map<String, String> mdlProps = (Map<String, String>)mapVariables.get(ParallelCommonNames.CSI_INVOKEADAPTER_MDL);
	    
	    long timeLeft;
	    long timeToLive;
	    long minTimeout = 2000;
	    
	    Object tempTimeLeft = (Object)mapVariables.get(ParallelCommonNames.CSI_INVOKE_TIMEOUT);
		long stime = 0L;
		
		if (tempTimeLeft == null) {
			timeLeft = 0;
		} else {
			//timeLeft = (Long)tempTimeLeft;
			timeLeft = Long.valueOf(tempTimeLeft.toString());
		}
		
		try {			
			if (timeLeft < minTimeout) {			
				if(mapVariables.get(ParallelCommonNames.ATTR_START_TIME)!=null){
					stime = Long.parseLong((String) mapVariables.get(ParallelCommonNames.ATTR_START_TIME));
				}
				
				timeLeft = Integer.parseInt(ttl) - (System.nanoTime()/1000000 - stime);
			}
		}
		catch (Exception e)
		{			
			LOGGER.info(e.getMessage());
			throw e;
		}
	    
		timeToLive = timeLeft + System.currentTimeMillis();

		String engineName = "UNSPECIFIED_AJSC_CAMUNDA_INSTANCE";
		logger.setConversationId(convId);
		logger.setEngine(engineName);		
		logger.setServiceName(callingServiceName);
		logger.setMethodName(adapterMethod);
		logger.setDownstreamSystem(adapterName);	
		logger.setGuid("");
		
		try {
		
			MAFApiTransImpl trans = new MAFApiTransImpl(logger);			
			
			trans.setBan(ban);
			trans.setSubscriber(subscriber);			
			//trans.setTimeout(Long.toString(timeToLive)); //Need timeleft+ System.currentTimeMillis();	
			trans.setTimeout(Long.toString(timeLeft)); //Need timeleft	
			trans.setMessageHeader(messageHeader);  
			
			HashMap<String, String> mdlProperties = (HashMap<String, String>)mdlProps;
			trans.setMDLProperties(mdlProperties);
			trans.setMode(mode);
			trans.setServiceKeyData1(serviceKeyData1);
			trans.setServiceKeyData2(serviceKeyData2);
			trans.setClientApp("AJSC-CSI~"+engineName +"~"+callingServiceName);
			trans.setServiceName(callingServiceName);
			trans.setOverridedLastMoment(timeToLive); //Need timeleft+ System.currentTimeMillis();		
			return trans;
		
		}
		catch (Exception e) {
			
			CSIControlException csiex = null;				
			if (e.getCause() instanceof CSIControlException){
				csiex = (CSIControlException)e.getCause();					
			} else{
				csiex = new CSIControlException(e);
			}
			LOGGER.info(e.getMessage());
			throw csiex;
		}

	}
	
}
