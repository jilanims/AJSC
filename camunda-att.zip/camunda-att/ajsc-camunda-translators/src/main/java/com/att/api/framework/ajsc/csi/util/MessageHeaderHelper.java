package com.att.api.framework.ajsc.csi.util;

import static org.camunda.spin.Spin.XML;

import java.math.BigInteger;
import java.util.Base64;
import java.util.Base64.Decoder;

import javax.servlet.http.HttpServletRequest;
import javax.xml.namespace.QName;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.MessageHeaderSecurity;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.MessageHeaderSequence;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.MessageHeaderTracking;
import com.cingular.csi.csi.namespaces.types._public.messageheader.MessageHeaderInfo;


public class MessageHeaderHelper {
	
	private static final Logger logger = LoggerFactory.getLogger(MessageHeaderHelper.class);
	
	private static MessageHeaderSequence getMessageHeaderSequence(HttpServletRequest  request){
		MessageHeaderSequence sequence = new MessageHeaderSequence();
		sequence.setSequenceNumber((String) request.getAttribute("X-CSI-SequenceNumber"));
		sequence.setTotalInSequence((String) request.getAttribute("X-CSI-TotalInSequence"));
		return sequence;
	}
	
	private static MessageHeaderSecurity getMessageHeaderSecurity(HttpServletRequest  request){
		MessageHeaderSecurity security = new MessageHeaderSecurity();
		String credential = decode(request.getHeader("Authorization"));
		 String[] credentials = credential.split(":");
		 if(credentials != null && credentials.length > 1){
			 security.setUserName(credentials[0]);
			 security.setUserPassword(credentials[1]);
		 }
		return security;
	}
	
	private static MessageHeaderTracking getMessageHeaderTracking(HttpServletRequest  request){
		MessageHeaderTracking tracking = new MessageHeaderTracking();
		 String version = (String) request.getAttribute("X-CSI-Version");
		 if("N/A".equals(version))
			 version = System.getProperty(BPMNConstants.SOACLOUD_VERSION).split("\\.")[0];
		tracking.setVersion(version);
		tracking.setOriginalVersion((String) request.getAttribute("X-CSI-OriginalVersion"));
		tracking.setOriginatorId((String) request.getAttribute("X-CSI-OriginatorId"));
		tracking.setMessageId((String) request.getAttribute("X-CSI-MessageId"));
		String convId = request.getHeader("X-CSI-ConversationId") ;
		convId = (convId == null) ? (String) request.getAttribute("X-CSI-ConversationId") : null;
		tracking.setConversationId(convId);
		tracking.setTimeToLive(BigInteger.valueOf(Long.valueOf((String) request.getAttribute("X-CSI-TimeToLive"))));
		tracking.setDateTimeStamp(XMLUtilities.getXMLGregorianCalendar());
		tracking.setUniqueTransactionId((String) request.getAttribute("X-CSI-UniqueTransactionId"));
		return tracking;
	}

	private static MessageHeaderInfo getMessageHeaderInfo(HttpServletRequest  request){
		BPMNUtilities.logAttributes(request);
		MessageHeaderInfo messageHeader = new MessageHeaderInfo();
		messageHeader.setSequenceMessageHeader(getMessageHeaderSequence(request));
		messageHeader.setSecurityMessageHeader(getMessageHeaderSecurity(request));
		messageHeader.setTrackingMessageHeader(getMessageHeaderTracking(request));
		return messageHeader;
	}
	
	public static String getMessageHeaderXml(HttpServletRequest request){
		JAXBUtil jxb = new JAXBUtil("com.cingular.csi.csi.namespaces.types._public.messageheader");
		QName qName = new QName("http://csi.cingular.com/CSI/Namespaces/Types/Public/MessageHeader.xsd", "MessageHeader");
		String messageHeader = jxb.marshall(qName, getMessageHeaderInfo(request));
		logger.debug("Generated MessageHeader {}", messageHeader);
		return messageHeader;
	}
	
	public static String getMessageHeaderFromJMSPayload(String jmsPayload){
		return XMLUtilities.extractFromJmsPayload(XML(jmsPayload), "MessageHeader");
	}
	
	public static String decode(String encodedString) {
		String[] splitStr = encodedString.split("\\s+");
		String decodedString = null;
		if ("Basic".equals(splitStr[0])) {
			Decoder decoder = Base64.getDecoder();
			byte[] b = decoder.decode(splitStr[1].getBytes());
			decodedString = new String(b);
		}
		return decodedString;
	}
	
	
}
