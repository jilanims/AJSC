package com.att.api.framework.ajsc.dmn;

import java.util.List;
import java.util.Map;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.api.framework.ajsc.csi.util.BPMNConstants;
import com.att.api.framework.ajsc.csi.util.BPMNUtilities;
import com.att.api.framework.ajsc.util.DMNRuleHandler;
import com.att.api.framework.ajsc.util.SimpleDMNRuleEngine;

/**
 *
 * @param <T>
 */
public class InvokeDMNRuleDelegate<T> implements JavaDelegate {
	
	private static final Logger logger = LoggerFactory.getLogger(InvokeDMNRuleDelegate.class);
	
	public void execute(DelegateExecution delegate) throws InstantiationException, IllegalAccessException, ClassNotFoundException {
		BPMNUtilities.logDelegate(delegate);

		Map<String, String> paramMap = BPMNUtilities.loadKeyValueMap((String) delegate.getVariable(BPMNConstants._Parameters)) ;
		String dmnName = paramMap.get(BPMNConstants.DMN_NAME);
		String ruleHandler = (String) paramMap.get(BPMNConstants.DMN_RULE_HANDLER);
		
		String inputVariable = (String) delegate.getVariable(BPMNConstants._Input) ;
		String ruleInputXml = (String)delegate.getVariable(inputVariable.trim());

		DMNRuleHandler handler = (DMNRuleHandler) Class.forName(ruleHandler).newInstance();
		
		if(String.class.isInstance(ruleInputXml))
			logger.debug("{} INPUT - {}", dmnName, ruleInputXml);
		List<Map<String, Object>> resultList = SimpleDMNRuleEngine.execute(dmnName, handler.getRuleInputs(ruleInputXml));
		Object ruleOutput = handler.handleRuleOutput(ruleInputXml, resultList);
		if(String.class.isInstance(ruleOutput))
			logger.debug("{} OUTPUT - {}", dmnName, ruleOutput);

		String outputVariable = (String) delegate.getVariable(BPMNConstants._Output) ;
		delegate.setVariable(outputVariable.trim(), ruleOutput);
		BPMNUtilities.delegateCleanUp(delegate);
		logger.debug("execute():end");
	}
	
	
	
}