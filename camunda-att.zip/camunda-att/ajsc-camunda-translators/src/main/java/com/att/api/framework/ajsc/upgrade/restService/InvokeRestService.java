package com.att.api.framework.ajsc.upgrade.restService;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Future;

import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.att.aft.dme2.internal.jersey.core.util.Base64;
import com.att.api.framework.ajsc.trace.Trace;
import com.att.api.framework.ajsc.utils.UtilLib;
import com.att.api.framework.common.logging.APITransactionLogger;
import com.att.api.framework.common.logging.PerformanceTrackingRecord;
import com.att.api.framework.common.logging.PerformanceTrackingTrailMark;
import com.att.api.framework.common.logging.TransactionLogger;
import com.att.api.framework.common.restservice.InvokeRESTParams;
import com.att.api.framework.common.restservice.jaxb.responseinfo.Header;
import com.att.api.framework.common.restservice.jaxb.responseinfo.HeaderKeyMap;
import com.att.api.framework.common.restservice.jaxb.responseinfo.ResponseInfo;
import com.att.api.framework.common.state.api.AJSCTransactionStateImpl;
import com.att.api.framework.common.utils.CommonNames;
import com.att.api.framework.common.utils.ServiceNetworkInfo;
import com.att.env.APIException;

/**
 * @author ah539b
 *
 */
@Component(InvokeRestService.INVOKE_REST_SERVICE)
public class InvokeRestService {
	
	public static final String INVOKE_REST_SERVICE = "InvokeRestService";
	private static final Logger LOGGER = LoggerFactory.getLogger(InvokeRestService.class);

	//Below properties are  default values loaded from the bean definition 
	String acceptType = null;
	String uri = null;
	String service = null;
	String stringQueryParams = null;
	String method = null;
	String version = null;

	private static final String DEFAULT_AJSC_INSTANCE_NAME = "UNSPECIFIED_AJSC_INSTANCE";
	private static final String CONTENT_TYPE = "Content-Type";

	/**
	 * @param exchange
	 * @throws Exception
	 */
	@SuppressWarnings({ "unused", "unchecked" })
	@Trace(message = "Call InvokeRestService")
	public final HashMap<String, Object> invoke(HashMap<String, Object> mapVariables) throws Exception {
		
		resetFields();
		String prvResponsePayload = null;
		
		Integer prvResponseStatusCode = null;
		Header prvResponseHeaders = null;
		HeaderKeyMap prvResponseHeaderKeymap = null;
		
		Map<String, String> headersMap;

		// try fetching the state and headers directly from the exchange first
		AJSCTransactionStateImpl state = (AJSCTransactionStateImpl)mapVariables.get(CommonNames.TRANSACTION_STATE);
		PerformanceTrackingRecord tracking = state.getTrackingRecord();
		
		headersMap = (Map<String, String>) mapVariables.get(CommonNames.REQUEST_HEADER_MAP);

		// otherwise grab it from the underlying http request
		/*
		if (state == null || headersMap == null) {
		HttpServletRequest request = transactionHelper.getHttpServletRequest(exchange.getIn());

			state = (AJSCTransactionStateImpl) request.getAttribute(CommonNames.TRANSACTION_STATE);
			headersMap = (Map<String, String>) request.getAttribute(CommonNames.REQUEST_HEADER_MAP);
		}
		*/

		if (UtilLib.checkTTL(state) && (state.getTimeOutTimestamp() < UtilLib.getCurrentTimeInMilliSeconds())) {
			//jilani re-visit here
			//ExceptionUtils.handleTranslatorTimeout(transactionHelper.getHttpServletRequest(exchange.getIn()), transactionHelper.getHttpServletResponse(exchange.getIn()), COMPONENT_NAME);
			//return;
		}
		
		//PerformanceTrackingRecord tracking = state.getTrackingRecord();
		boolean streamingEnabled = false;
		
		if(mapVariables.get(RESTSERVICECommonNames.CSI_INVOKE_STREAM) != null){
			streamingEnabled = (Boolean) mapVariables.get(RESTSERVICECommonNames.CSI_INVOKE_STREAM);
		}
		ResponseInfo restResponseInfo=null;
		Future<ResponseInfo> responseFutureObject;
		
		String responseOutputProperty = (String) mapVariables.get(CommonNames.AJSC_NM_ACTIVITY_OUTPUT_PROPERTY);
		if (responseOutputProperty == null) {
			throw new APIException("Response output property for InvokeRestService : (ACTIVITY_OUTPUT_PROPERTY) is not set.");
		}
		
		String callingServiceName = headersMap.get(CommonNames.HEADER_ATT_SERVICE_NAME);
		if(callingServiceName == null){
			callingServiceName = headersMap.get(CommonNames.HEADER_ATT_METHOD_NAME);
		}
		
		String targetService = (String)mapVariables.get(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_NAME);
		if (targetService == null || targetService.isEmpty()) {
			targetService = service;
		}
		
		if(targetService==null && null != headersMap.get(CommonNames.HEADER_ATT_SERVICE_NAME) && !headersMap.get(CommonNames.HEADER_ATT_SERVICE_NAME).isEmpty()) {
			targetService = headersMap.get(CommonNames.HEADER_ATT_SERVICE_NAME);
		}		
		if(callingServiceName==null){
			callingServiceName = targetService;
		}

		//PerformanceTrackingTrailMark trailMark = tracking.addTrailMark(COMPONENT_NAME, targetService);
		PerformanceTrackingTrailMark trailMark = tracking.addTrailMark(INVOKE_REST_SERVICE);
		try{

			InvokeRESTParams restParams=createRESTParams(mapVariables, callingServiceName, targetService, streamingEnabled, headersMap);

			if(streamingEnabled){
				com.att.api.framework.common.restservice.InvokeRESTService.invokeStream(restParams);
			}
			else{
				responseFutureObject= com.att.api.framework.common.restservice.InvokeRESTService.invoke(restParams);
				restResponseInfo=responseFutureObject.get();
			}
		}
		catch(Exception exception){
			throw new APIException(exception);
		}finally {
			trailMark.done();
		}
		if (restResponseInfo != null) {
			
			prvResponsePayload = restResponseInfo.getBody();
			
			String codeProperty = (String)mapVariables.get(RESTSERVICECommonNames.INVOKERESTSERVICE_SERVICERESPONSE_OUTPUT_CODE);
			if(codeProperty != null && !codeProperty.isEmpty()){
				prvResponseStatusCode = restResponseInfo.getCode().intValue();
			}
			String headersProperty = (String)mapVariables.get(RESTSERVICECommonNames.INVOKERESTSERVICE_SERVICERESPONSE_OUTPUT_HEADERS);
			if(headersProperty != null && !headersProperty.isEmpty()){
				prvResponseHeaders=restResponseInfo.getHeader();
			}
			String headersKeyProperty = (String)mapVariables.get(RESTSERVICECommonNames.INVOKERESTSERVICE_SERVICERESPONSE_OUTPUT_HEADERKEYMAP);
			if(headersKeyProperty != null && !headersKeyProperty.isEmpty()){
				prvResponseHeaderKeymap= restResponseInfo.getHeaderKeyMap();
			}
			
			
			LOGGER.info("Invoke Rest Service Response:"+prvResponsePayload);
			mapVariables.put(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_PRVRESPONSE, prvResponsePayload);
			
			
			
		}else if(RESTSERVICECommonNames.CSI_INVOKE_STREAM.equalsIgnoreCase("true")){
			//do nothing
		}
		else {
			throw new APIException("x-code:500:SVC9999:An internal error has occurred: Unable to capture response");
		}
		
		return mapVariables;
	}

	/**
	 * @param exchange
	 * @param perfTrackerBean
	 * @param callingServiceName
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	private InvokeRESTParams createRESTParams(HashMap<String, Object> mapVariables,String callingServiceName, String targetService, boolean streamingEnabled, Map<String, String> headersMap) throws Exception{

		String targetUri;
		String targetAcceptType;
		String targetMethod;
		String payload = null;
		Map<String, String> mapQueryParams;
		Map<String, String>	targetRequestHeaders;
		InputStream payloadInputStream;		
		long timeToLive = 0L;

		TransactionLogger logger = new APITransactionLogger(callingServiceName);
		
		String targetVersion = (String)mapVariables.get(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_VERSION);
		if (targetVersion == null || targetVersion.isEmpty()) {
			targetVersion = version;
		}
		if(targetVersion==null && null != headersMap.get(CommonNames.HEADER_ATT_VERSION) && !headersMap.get(CommonNames.HEADER_ATT_VERSION).isEmpty()){
			targetVersion = headersMap.get(CommonNames.HEADER_ATT_VERSION);
		}

		if (targetVersion == null || targetVersion.isEmpty() ) {
			throw new APIException("InvokeRestService target version is not set");
		}

		String timeStamp = headersMap.get(CommonNames.HEADER_ATT_DATE_TIME_STAMP);
		String guid = (null==headersMap.get(CommonNames.GUID)?"":headersMap.get(CommonNames.GUID));
		long timeLeft = 0;
		timeLeft = (Long) mapVariables.get(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_TIMEOUT);

		if (timeLeft < 1500) {
			long stime = 0;
			if(timeStamp!=null){
				stime = Long.parseLong(timeStamp);
			}
			timeLeft = Long.parseLong(headersMap.get(CommonNames.HEADER_ATT_TIME_TO_LIVE)) - (System.nanoTime()/1000000 - stime);
		}

		String instanceName = (ServiceNetworkInfo.getHostName() == null? DEFAULT_AJSC_INSTANCE_NAME:ServiceNetworkInfo.getHostName());

		targetUri = (String) mapVariables.get(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_URI);
		if ((targetUri == null) || (targetUri.isEmpty())) {
			targetUri = this.uri;
		}

		targetAcceptType = (String) mapVariables.get(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_CONTENTTYPE);
		if ((targetAcceptType == null) || (targetAcceptType.isEmpty())) {
			targetAcceptType = this.acceptType;
		}

		targetMethod = (String) mapVariables.get(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_METHOD);
		if ((targetMethod == null) || (targetMethod.isEmpty())) {
			targetMethod = this.method;
		}		

		targetRequestHeaders = (Map<String, String>) mapVariables.get(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_REQUEST_HEADERS);
		if (targetRequestHeaders == null) {
			targetRequestHeaders = new HashMap<String, String>();
		}

		mapQueryParams = (Map<String, String>) mapVariables.get(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_QUERY_PARAMS_MAP);
		if (mapQueryParams == null) {
			mapQueryParams = new HashMap<String, String>();
			if ((this.stringQueryParams != null)
					&& (!(this.stringQueryParams.isEmpty()))) {
				for (String query : this.stringQueryParams.split("&")) {
					String[] thisQuery = query.split("=");
					mapQueryParams.put(thisQuery[0], thisQuery[1]);
				}
			}
		}

		payloadInputStream = (InputStream) mapVariables.get(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_PAYLOAD_STREAM);
		if (payloadInputStream == null) {
			payload = (String) mapVariables.get(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_PAYLOAD_STRING);
			if (payload == null) {
				payload = "";
			}
			payloadInputStream = new ByteArrayInputStream(payload.getBytes());
		}

		String convId = headersMap.get(CommonNames.HEADER_ATT_CONVERSATION_ID);
		String userName = headersMap.get(CommonNames.CSI_USER_NAME);

		logger.setConversationId(convId);
		logger.setEngine(instanceName);
		logger.setServiceName(callingServiceName);	
		logger.setGuid(guid);

		String engineName = (ServiceNetworkInfo.getHostName() == null? DEFAULT_AJSC_INSTANCE_NAME:ServiceNetworkInfo.getHostName());
		InvokeRESTParams restParams= new InvokeRESTParams();	

		if(!streamingEnabled){
			targetRequestHeaders.put(CommonNames.HEADER_ATT_VERSION, targetVersion);
			targetRequestHeaders.put(CommonNames.HEADER_ATT_ORIGINAL_VERSION, "");
			targetRequestHeaders.put(CommonNames.HEADER_ATT_MESSAGE_ID, headersMap.get(CommonNames.HEADER_ATT_MESSAGE_ID));
			targetRequestHeaders.put(CommonNames.CSI_USER_NAME, userName);		
			targetRequestHeaders.put(CommonNames.HEADER_ATT_CONVERSATION_ID, convId);				
			targetRequestHeaders.put(CommonNames.HEADER_ATT_TIME_TO_LIVE, Long.toString(timeToLive));				
			targetRequestHeaders.put(CommonNames.HEADER_ATT_ORIGINATOR_ID, headersMap.get(CommonNames.HEADER_ATT_ORIGINATOR_ID));
			targetRequestHeaders.put(CommonNames.HEADER_ATT_UNIQUE_TXN_ID, guid);
			String username = (String) mapVariables.get(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_USERNAME);
			String userKey = (String) mapVariables.get(RESTSERVICECommonNames.CSI_INVOKERESTSERVICE_PASSWORD);
			if(username != null && !username.isEmpty() && userKey != null && !userKey.isEmpty()){
				String authString = username + ":" + userKey;
				byte[] authEncBytes = Base64.encode(authString.getBytes());
				String authStringEnc = new String(authEncBytes);
				authStringEnc="Basic " +authStringEnc;
				targetRequestHeaders.put(CommonNames.HTTP_AUTHORIZATION, authStringEnc);
			}else{
				targetRequestHeaders.put(CommonNames.HTTP_AUTHORIZATION, headersMap.get(CommonNames.HTTP_AUTHORIZATION));
			}
			userKey = null;
			targetRequestHeaders.put(CommonNames.HEADER_ATT_SEQUENCE_NUMBER, "1");
			targetRequestHeaders.put(CommonNames.HEADER_ATT_TOTAL_IN_SEQUENCE, "1");
			targetRequestHeaders.put(CommonNames.HEADER_ATT_CLIENT_APP,"AJSC-CSI~"+engineName +"~"+callingServiceName);
			targetRequestHeaders.put(CommonNames.CLIENT_APP,"AJSC-CSI~"+engineName +"~"+callingServiceName);
			targetRequestHeaders.put(CONTENT_TYPE, targetAcceptType);
			targetRequestHeaders.put(Exchange.CONTENT_LENGTH, Integer.toString(payload.length()));
		}
		restParams.setTargetRequestHeaders(targetRequestHeaders);
		restParams.setPayload(payload);
		restParams.setPayloadInputStream(payloadInputStream);
		restParams.setMapQueryParams(mapQueryParams);
		restParams.setCallingServiceName(callingServiceName);
		restParams.setTargetAcceptType(targetAcceptType);
		restParams.setUserName(userName);
		restParams.setTargetUri(targetUri);
		restParams.setTargetMethod(targetMethod);
		restParams.setTargetVersion(targetVersion);
		restParams.setTargetService(targetService);
		restParams.setStreamService(streamingEnabled);
		restParams.setTimeLeft(timeLeft);
		String versionApplEnv = System.getProperty(CommonNames.VERSION_ROUTEOFFER_ENVCONTEXT);		
		String[] splitInstance = versionApplEnv.split("\\/");
		String defaultEnvContext = splitInstance[2];
		String stickySelectorKey = splitInstance[1];

		restParams.setDefaultDME2EnvContext(defaultEnvContext);
		restParams.setStickySelectorKey(stickySelectorKey);

		return restParams;
	}
	
	private void resetFields(){
		acceptType = null;
		uri = null;
		service = null;
		stringQueryParams = null;
		method = null;
		version = null;

	}
}