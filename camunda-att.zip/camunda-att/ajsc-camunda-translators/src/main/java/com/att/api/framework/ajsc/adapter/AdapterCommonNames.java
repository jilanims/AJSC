package com.att.api.framework.ajsc.adapter;

public class AdapterCommonNames {
	
	public static final String CSI_ADAPTER_SERVICEREQUEST = "CSI_ADAPTER_SERVICEREQUEST";
	public static final String CSI_ADAPTER_LOGGER = "CSI_ADAPTER_LOGGER";
	public static final String CSI_ADAPTER_STARTTIME = "CSI_ADAPTER_STARTTIME";
	public static final String CSI_ADAPTER_STATUS = "CSI_ADAPTER_STATUS";
	public static final String CSI_ADAPTER_NAME = "CSI_ADAPTER_NAME";
	public static final String CSI_ADAPTER_METHOD = "CSI_ADAPTER_METHOD";
	public static final String CSI_ADAPTER_REQSIZE = "CSI_ADAPTER_REQSIZE";
	public static final String CSI_ADAPTER_RESPSIZE = "CSI_ADAPTER_RESPSIZE";
	
	public static final String CSI_INVOKEADAPTER_TIMEOUT = "CSI_INVOKEADAPTER_TIMEOUT";
	public static final String CSI_INVOKEADAPTER_BAN = "CSI_INVOKEADAPTER_BAN";
	public static final String CSI_INVOKEADAPTER_SUBSCRIBER = "CSI_INVOKEADAPTER_SUBSCRIBER";
	public static final String CSI_INVOKEADAPTER_MESSAGEHEADER = "CSI_INVOKEADAPTER_MESSAGEHEADER";
	public static final String CSI_INVOKEADAPTER_PRVREQUEST = "CSI_INVOKEADAPTER_PRVREQUEST";
	public static final String CSI_INVOKEADAPTER_PRVRESPONSE = "CSI_INVOKEADAPTER_PRVRESPONSE";
	public static final String CSI_INVOKEADAPTER_MDL = "CSI_INVOKEADAPTER_MDL";
	public static final String CSI_INVOKEADAPTER_VERSION = "CSI_INVOKEADAPTER_VERSION";
	public static final String CSI_INVOKEADAPTER_MODE = "CSI_INVOKEADAPTER_MODE";
	public static final String CSI_INVOKEADAPTER_CLIENTAPP = "CSI_INVOKEADAPTER_CLIENTAPP";
	public static final String CSI_INVOKEADAPTER_SVCKEYDATA1 = "CSI_INVOKEADAPTER_SVCKEYDATA1";
	public static final String CSI_INVOKEADAPTER_SVCKEYDATA2 = "CSI_INVOKEADAPTER_SVCKEYDATA2";
	
	//
	public static final String CSI_MAF_ADAPTER_TYPE = "CSI_MAF_ADAPTER_TYPE"; //MAFINLINE OR MAFREMOTE
	public static final String MAFINLINE = "MAFINLINE";
	public static final String MAFREMOTE = "MAFREMOTE";	
	
	public static final String INVOKE_SERVICE_NAME = "INVOKE_SERVICE_NAME";
	//PARTNER
	public static final String PARTNER_PROFILE_CLIENT ="PARTNER_PROFILE_CLIENT";
	
	public static enum Modes {
		INLINE,
		REMOTE
	}
}
