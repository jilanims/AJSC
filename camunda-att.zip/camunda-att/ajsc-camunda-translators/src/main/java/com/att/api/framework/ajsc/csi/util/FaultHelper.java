package com.att.api.framework.ajsc.csi.util;

import static org.camunda.spin.Spin.XML;

import java.util.HashMap;
import java.util.Map;

import javax.xml.namespace.QName;

import org.camunda.spin.xml.SpinXmlElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cingular.csi.csi.namespaces.types._private.errortranslationrequest.ErrorTranslationRequest;
import com.cingular.csi.csi.namespaces.types._private.implementation.transactionheader.TransactionHeader;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.ResponseInfo;
import com.cingular.csi.csi.namespaces.types._public.errorresponse.CSIApplicationException;
import com.cingular.csi.csi.namespaces.types._public.errorresponse.ServiceEntityFaultInfo;
import com.cingular.csi.csi.namespaces.types._public.errorresponse.ServiceProviderEntityInfo;
import com.cingular.csi.csi.namespaces.types._public.errorresponse.ServiceProviderEntityInfo.ServiceProviderRawError;
import com.cingular.csi.csi.namespaces.types._public.soapfault.FaultInfo;
import com.cingular.csi.csi.namespaces.types._public.soapfault.FaultInfo.Detail;

public class FaultHelper {
	
	private static final Logger logger = LoggerFactory.getLogger(FaultHelper.class);
	
	public static String extractErrorTranslationInfo(SpinXmlElement errTranslationResponse, String variableName){
		 return XMLUtilities.evaluateXPath(errTranslationResponse, "/etr:ErrorTranslationResponse/etr:ServiceEntityFault/er:" + variableName, getNamespaceMap("ErrorTranslationResponse"));
	}
	
	public static String extractErrorTranslationInfo(String errTranslationResponse, String variableName){
		 return isNullOrEmpty(errTranslationResponse) ? "": extractErrorTranslationInfo(XML(errTranslationResponse), variableName);
	}
	
	public static String getFaultXml(CSIException csiException, String errorTranslationResponse){
		JAXBUtil jxb = new JAXBUtil("com.cingular.csi.csi.namespaces.types._public.soapfault");
		QName qName = new QName("http://csi.cingular.com/CSI/Namespaces/Types/Public/SoapFault.xsd", "Fault");
		String fault = jxb.marshall(qName, getFaultInfo(csiException, errorTranslationResponse));
		logger.debug("Generated Fault {}", fault);
		return fault;
	}
	
	private static CSIApplicationException getCSIApplicationException(CSIException csiException, String cingularErrorCategory, String cingularErrorDescription, String cingularErrorCode){
		CSIApplicationException csiAppExc = new CSIApplicationException();
		csiAppExc.setResponse(getResponseInfo(cingularErrorCategory, cingularErrorDescription));
		csiAppExc.getServiceProviderEntity().add(getServiceProviderEntity(csiException, cingularErrorCode));
		return csiAppExc;
	}

	private static Detail getDetail(CSIException csiException, String cingularErrorCategory, String cingularErrorDescription, String cingularErrorCode){
		Detail detail = new Detail();
		detail.setCSIApplicationException(getCSIApplicationException(csiException, cingularErrorCategory, cingularErrorDescription, cingularErrorCode));
		detail.setCSIInternalException(getServiceEntityFaultInfo(csiException, cingularErrorCategory, cingularErrorDescription, cingularErrorCode));
		return detail;
	}

	private static ErrorTranslationRequest getErrorTranslationRequest(CSIException csiException) {
		ErrorTranslationRequest request = new ErrorTranslationRequest();
		request.setTransactionHeader(getTransactionHeader(csiException));
		request.getServiceEntityFault().add(getSServiceProviderEntityInfo(csiException));
		request.setOperation(csiException.getApplication());
		return request;
	}
	
	public static String getErrorTranslationRequestXml(CSIException csiException){
		JAXBUtil jxb = new JAXBUtil("com.cingular.csi.csi.namespaces.types._private.errortranslationrequest");
		QName qName = new QName("http://csi.cingular.com/CSI/Namespaces/Types/Private/ErrorTranslationRequest.xsd", "ErrorTranslationRequest");
		String errorTranslationRequest = jxb.marshall(qName, getErrorTranslationRequest(csiException));
		logger.debug("Generated CAET Request {}", errorTranslationRequest);
		return errorTranslationRequest;
	}
	
	public static String getFaultCode(String faultXml){
		return getFaultInfo(faultXml, "code");
	}
	
	public static String getFaultInfo(String faultXml, String variableName){
		return isNullOrEmpty(faultXml) ? "" : getFaultInfo(XML(faultXml), variableName);
	}
	
	public static String getFaultInfo(SpinXmlElement fault, String variableName){
		String value = "";
		Map<String, String> nsMap = getNamespaceMap("SoapFault");
		if("code".equals(variableName)){
			value =  XMLUtilities.evaluateXPath(fault, "/soap:Fault/soap:detail/soap:CSIApplicationException/err:Response/cng:code", nsMap);
		}else if("description".equals(variableName)){
			value =  XMLUtilities.evaluateXPath(fault, "/soap:Fault/soap:detail/soap:CSIApplicationException/err:Response/cng:description", nsMap);
		}else if("reportingServiceEntity".equals(variableName)){
			value =  XMLUtilities.evaluateXPath(fault, "/soap:Fault/soap:detail/soap:CSIApplicationException/err:ServiceProviderEntity/err:reportingServiceEntity", nsMap);
		}
		return value;
	}
	
	public static String getFaultDescription(String faultXml){
		return getFaultInfo(faultXml, "description");
	}

	public static String getFaultFromSoapFault(String soapFault){
		SpinXmlElement faultElement = XML(getFaultTemplate());
		if(!isNullOrEmpty(soapFault)){
			SpinXmlElement soapElement = XML(soapFault);
			faultElement.childElement("detail")
						.childElement("CSIApplicationException").append(soapElement.childElement("Body")
							.childElement("Fault")
							.childElement(null,"detail")
							.childElement("http://csi.cingular.com/CSI/Namespaces/Types/Public/SoapFaultDetails.xsd","CSIApplicationException")
							.childElements());
			
			faultElement.childElement("faultcode").textContent("ns1:"  + soapElement.childElement("Body").childElement("Fault").childElement(null, "faultcode").textContent().split(":")[1]);
			faultElement.childElement("faultstring").textContent(soapElement.childElement("Body").childElement("Fault").childElement(null, "faultstring").textContent());
			faultElement.childElement("faultactor").textContent(soapElement.childElement("Body").childElement("Fault").childElement(null, "faultactor").textContent());
		}
		return faultElement.toString();
	}

	private static FaultInfo getFaultInfo(CSIException csiException, String errorTranslationResponse){
		logger.debug("getFaultInfo from {} & {}", csiException.toString(), errorTranslationResponse);
		String cingularErrorCode = extractErrorTranslationInfo(errorTranslationResponse, "cingularErrorCode");
		cingularErrorCode = !isNullOrEmpty(cingularErrorCode) ? cingularErrorCode : csiException.getCode();
			
		String cingularErrorDescription = extractErrorTranslationInfo(errorTranslationResponse, "cingularErrorDescription");
		cingularErrorDescription = !isNullOrEmpty(cingularErrorDescription) ? cingularErrorDescription : csiException.getMessage();
		
		String cingularErrorCategory =	extractErrorTranslationInfo(errorTranslationResponse, "cingularErrorCategory");
		cingularErrorCategory = !isNullOrEmpty(cingularErrorCategory) ? cingularErrorCategory : "900";
		
		FaultInfo fault = new FaultInfo();
		fault.setFaultcode(new QName("http://schemas.xmlsoap.org/soap/envelope/", "Client"));
		fault.setFaultactor(cingularErrorCategory);
		fault.setFaultstring(cingularErrorDescription);
		fault.setDetail(getDetail(csiException, cingularErrorCategory, cingularErrorDescription, cingularErrorCode));
		return fault;
	}
	
	private static String getFaultTemplate(){
		return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
				+ "<ns4:Fault xmlns:ns4=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/SoapFault.xsd\">"
				+ "<ns4:faultcode xmlns:ns1=\"http://schemas.xmlsoap.org/soap/envelope/\">ns1:Client</ns4:faultcode>"
				+ "<ns4:faultstring/>"
				+ "<ns4:faultactor/>"
				+ "<ns4:detail>"
				+ "<ns4:CSIApplicationException/>"
				+ "<ns4:CSIInternalException/>"
				+ "</ns4:detail>"
				+ "</ns4:Fault>";
	}
	
	private static Map<String, String> getNamespaceMap(String schemaName) {
		Map<String, String> nsMap = new HashMap<String, String>();
		if("ErrorTranslationResponse".equals(schemaName)){
			 nsMap.put("etr", "http://csi.cingular.com/CSI/Namespaces/Types/Private/ErrorTranslationResponse.xsd");
			 nsMap.put("er", "http://csi.cingular.com/CSI/Namespaces/Types/Public/ErrorResponse.xsd");
		}else if("SoapFault".equals(schemaName)){
			nsMap.put("soap", "http://csi.cingular.com/CSI/Namespaces/Types/Public/SoapFault.xsd");
			nsMap.put("cng", "http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd");
			nsMap.put("err", "http://csi.cingular.com/CSI/Namespaces/Types/Public/ErrorResponse.xsd");
		}
		return nsMap;
	}
	
	private static ResponseInfo getResponseInfo(String cingularErrorCategory, String cingularErrorDescription){
		ResponseInfo responseInfo = new ResponseInfo();
		responseInfo.setCode(cingularErrorCategory);
		responseInfo.setDescription(cingularErrorDescription);
		return responseInfo;
	}
	
	private static ServiceEntityFaultInfo getServiceEntityFaultInfo(CSIException csiException, String cingularErrorCategory, String cingularErrorDescription, String cingularErrorCode){
		ServiceEntityFaultInfo faultInfo = new ServiceEntityFaultInfo();
		faultInfo.setReportingServiceEntity(csiException.getFaultEntity());
		faultInfo.setFaultCode(cingularErrorCode);
		faultInfo.setFaultDate(XMLUtilities.getXMLGregorianCalendar());
		faultInfo.setFaultDescription(csiException.getMessage());
		faultInfo.setFaultLevel("ERROR");
		faultInfo.setFaultSequenceNumber("1");
		faultInfo.setCingularErrorCategory(cingularErrorCategory);
		faultInfo.setCingularErrorCode(cingularErrorCode);
		faultInfo.setCingularErrorDescription(cingularErrorDescription);
		return faultInfo;
	}
	
	private static ServiceProviderEntityInfo getServiceProviderEntity(CSIException csiException, String cingularErrorCode) {
		ServiceProviderEntityInfo entityInfo = new ServiceProviderEntityInfo();
		entityInfo.setReportingServiceEntity(csiException.getFaultEntity());
		entityInfo.setFaultCode(cingularErrorCode);
		entityInfo.setFaultDate(XMLUtilities.getXMLGregorianCalendar());
		entityInfo.setFaultDescription(csiException.getMessage());
		entityInfo.setFaultLevel("ERROR");
		entityInfo.setFaultSequenceNumber("1");
		ServiceProviderRawError rawError = new ServiceProviderRawError();
		rawError.setCode(csiException.getCode());
		rawError.setDescription(csiException.getMessage());
		entityInfo.setServiceProviderRawError(rawError);
		return entityInfo;
	}
	
	private static ServiceProviderEntityInfo getSServiceProviderEntityInfo(CSIException csiException) {
		ServiceProviderEntityInfo info = new ServiceProviderEntityInfo();
		info.setFaultCode(csiException.getCode());
		info.setFaultDescription(csiException.getMessage());
		info.setReportingServiceEntity(csiException.getFaultEntity());
		return info;
	}
	
	private static TransactionHeader getTransactionHeader(CSIException csiException){
		TransactionHeader header = new TransactionHeader();
		header.setApplicationId(csiException.getApplication());
		return header;
	}
	
	private static boolean isNullOrEmpty(Object obj){
		boolean isNullOrEmpty = false;
		if(obj == null){
			isNullOrEmpty = true;
		}else if(String.class.isInstance(obj) && "".equals(obj)){
			isNullOrEmpty = true;
		}
		return isNullOrEmpty;
	}
}
