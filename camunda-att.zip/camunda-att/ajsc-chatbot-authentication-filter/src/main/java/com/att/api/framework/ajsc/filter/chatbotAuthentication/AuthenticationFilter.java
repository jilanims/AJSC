package com.att.api.framework.ajsc.filter.chatbotAuthentication;

import java.io.IOException;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.atomic.AtomicReference;

import com.att.aft.dme2.internal.jetty.http.HttpStatus;
import com.att.api.framework.ajsc.utils.ExceptionUtils;
import com.att.api.framework.ajsc.utils.logging.LoggingRecordHelper;
import com.att.api.framework.common.logging.Markers;
import com.att.api.framework.common.utils.CommonNames;
import com.att.api.framework.common.utils.ExceptionNames;
//import com.att.chatbots.authn.BasicAuthValidator;
import com.att.api.framework.ajsc.filter.chatbotAuthentication.BasicAuthValidator;
import com.att.chatbots.util.CbConstants.Headers;
import com.att.chatbots.util.gson.GsonSupport;
import com.google.gson.Gson;


public class AuthenticationFilter   implements  Filter {

	private static final Logger logger = LoggerFactory.getLogger(AuthenticationFilter.class);
	private static Logger securityLogger = LoggerFactory.getLogger(CommonNames.SECURITY_LOGGER);
    private AtomicReference<BasicAuthValidator> authCheckerRef = null;
    private final Gson gson = GsonSupport.create();  

	private String chatBotId;
	private String secretKey;
	
	public AuthenticationFilter(String chatBotId, String secretKey) {
		this.chatBotId = chatBotId;
		this.secretKey = secretKey;
	}


    
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		
        authCheckerRef = new AtomicReference<>(new BasicAuthValidator(chatBotId, secretKey));
	}

	@Override
	public  void doFilter(ServletRequest servetRequest, ServletResponse servetResponse, FilterChain chain) throws IOException, ServletException {

		if (logger.isDebugEnabled()) {
			logger.debug("entered {}.doFilter()", AuthenticationFilter.class.getName());
		}

		HttpServletRequest request = (HttpServletRequest) servetRequest;
		HttpServletResponse response = (HttpServletResponse) servetResponse;
		Map<String, String> headerMaps = (Map<String, String>) request.getAttribute(CommonNames.REQUEST_HEADER_MAP);
				
        if (!authCheckerRef.get().checkAuth(request.getHeader(Headers.AUTHORIZATION))) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			ExceptionUtils.handleFilterException(request, response, ExceptionNames.AUTHZ_UNAUTHORIZED_FAILURE);
			securityLogger.info(Markers.SECURITY, "Security", LoggingRecordHelper.createSecurityInfo(CommonNames.SECURITY_AUTHORIZATION_STR, CommonNames.SECURITY_PROTOCOL_BASIC_ChatBot, chatBotId, CommonNames.SECURITY_PROTOCOL_DENIED));
            return;
        }
		securityLogger.info(Markers.SECURITY, "Security", LoggingRecordHelper.createSecurityInfo(CommonNames.SECURITY_AUTHORIZATION_STR, CommonNames.SECURITY_PROTOCOL_BASIC_ChatBot, chatBotId, CommonNames.SECURITY_PROTOCOL_APPROVED));

		chain.doFilter(request, response);

		if (logger.isDebugEnabled()) {
			logger.debug("leaving {}.doFilter()", AuthenticationFilter.class.getName());
		}

	}
	

	@Override
	public void destroy() {
		// Nothing to cleanup

	}
}
