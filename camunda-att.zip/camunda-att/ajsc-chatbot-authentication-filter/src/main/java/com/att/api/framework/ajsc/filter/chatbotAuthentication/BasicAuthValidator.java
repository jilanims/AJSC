package com.att.api.framework.ajsc.filter.chatbotAuthentication;

import com.att.chatbots.util.TextSupport;

import java.io.UnsupportedEncodingException;

//import org.glassfish.jersey.internal.util.Base64;
import com.att.aft.dme2.internal.jersey.core.util.Base64;

// This is duplicate class of BasicAuthValidator from chatbot-config 0.2.7, as it was not supporting jersey 2.29.1 upgrade 
// due to missing Base64 class. This class may be removed later once chatbot-config was refactored.
// Used in 'AuthenticationFilter' class in this package. 
/**
* Provides HTTP Basic Authentication validation
*/
public class BasicAuthValidator {

   private final String botId;
   private final String secretKey;

   /**
    * Create new instance that uses jvm parms: bot.id and secret.key<br>
    * if secret key is not defined, this checker passes everything
    */
   public BasicAuthValidator() {
       this.botId = System.getProperty("bot.id", "");
       this.secretKey = System.getProperty("secret.key", "");
   }

   public BasicAuthValidator(String botId, String secretKey) {
       this.botId = botId;
       this.secretKey = secretKey;

   }

   public boolean checkAuth(String auth) {
       if (TextSupport.isEmpty(secretKey)) {
           return true;
       }

       if (TextSupport.isNotEmpty(auth)) {
           // look for password in the Authorization header
           /*String decoded = Base64.decodeAsString(auth.replace("Basic ", ""));
           String[] split = decoded.split(":");
           String workingId = split[0];
           String workingPwd = split[1];
           return workingId.equalsIgnoreCase(botId) && workingPwd.equalsIgnoreCase(secretKey);
           */
    	   String decoded = null;
    	   byte[] result = Base64.decode(auth.replace("Basic ", ""));
    	   try {
    		   decoded = new String(result, "ASCII");
           } catch (final UnsupportedEncodingException ex) {
               // should never happen
        	   decoded = new String(result.toString());
           }
           String[] split = decoded.split(":");    	   
           if(split.length > 1) { //Assuming there should be userid and password
        	   return split[0].equalsIgnoreCase(botId) && split[1].equalsIgnoreCase(secretKey);
           }

       }

       return false;
   }
   
}

