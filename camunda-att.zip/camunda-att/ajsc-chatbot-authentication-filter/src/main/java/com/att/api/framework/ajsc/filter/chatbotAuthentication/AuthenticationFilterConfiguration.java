package com.att.api.framework.ajsc.filter.chatbotAuthentication;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.att.api.framework.ajsc.filter.FilterOrders;
import com.att.api.framework.ajsc.filter.FilterConfiguration;

@Configuration
public class AuthenticationFilterConfiguration {

	
	@Value("${chatbot.chatBotId:#{null}}")
	private String chatBotId;
    
    @Value("${chatbot.secretKey:#{null}}")
	private String secretKey;
	    
	@Bean
	public FilterRegistrationBean chatBotFilter() {

		FilterRegistrationBean registration = new FilterRegistrationBean();
		AuthenticationFilter filter = new AuthenticationFilter(chatBotId, secretKey);
		registration.setFilter(filter);
		registration.setOrder(FilterOrders.CHATBOTAUTH);
		registration.setUrlPatterns(FilterConfiguration.getPatternUrls());		
		registration.setServletNames(FilterConfiguration.getServletNames());

		return registration;
	}
}
