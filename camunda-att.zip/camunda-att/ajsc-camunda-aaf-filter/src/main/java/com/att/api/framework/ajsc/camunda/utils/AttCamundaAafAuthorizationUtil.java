package com.att.api.framework.ajsc.camunda.utils;

import java.security.Principal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ServiceLoader;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.camunda.bpm.engine.AuthorizationService;
import org.camunda.bpm.engine.IdentityService;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.identity.Group;
import org.camunda.bpm.engine.identity.GroupQuery;
import org.camunda.bpm.engine.identity.User;
import org.camunda.bpm.engine.rest.spi.ProcessEngineProvider;
import org.camunda.bpm.webapp.impl.security.auth.UserAuthentication;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.api.framework.ajsc.camunda.yaml.beans.AafPermission;
import com.att.api.framework.ajsc.camunda.yaml.beans.AttCamundaUser;
import com.att.api.framework.ajsc.camunda.yaml.beans.AuthorizationGrant;
import com.att.api.framework.ajsc.camunda.yaml.beans.CamundaGroup;
import com.att.api.framework.ajsc.camunda.yaml.beans.GroupAssociation;
import com.att.api.framework.common.security.utils.SanitizeUtils;
//import com.att.cadi.principal.CachedBasicPrincipal;
import org.onap.aaf.cadi.principal.CachedBasicPrincipal; // Class is available only in CADI 2.x
import static org.camunda.bpm.engine.authorization.Authorization.AUTH_TYPE_GRANT;
import com.att.cadi.taf.csp.CSPPrincipal;
import static org.camunda.bpm.engine.authorization.Permissions.ACCESS;
import static org.camunda.bpm.engine.authorization.Resources.APPLICATION;

/**
 * @author jp931e
 *
 */
public class AttCamundaAafAuthorizationUtil {

	private static final Logger logger = LoggerFactory.getLogger(AttCamundaAafAuthorizationUtil.class);

	/*
	 * Get engine and application name based on url i.e.
	 * localhost:8080/app/default
	 */
	public static String[] getAppInfo(String url) {
		String[] appInfo = null;
		if (url.endsWith("/")) {
			int index = url.indexOf(CamundaConstants.APP_MARK);
			if (index >= 0) {
				String apps = "";
				if (index + CamundaConstants.APP_MARK.length() < url.length() - 1) {
					apps = url.substring(index + CamundaConstants.APP_MARK.length(), url.length() - 1);
				} else {
					apps = url;
				}
				String[] aa = apps.split("/");
				if (aa.length == 2) {
					appInfo = aa;
				}
			}
		}
		return appInfo;
	}

	public static ProcessEngine lookupProcessEngine(String engineName) {

		ServiceLoader<ProcessEngineProvider> serviceLoader = ServiceLoader.load(ProcessEngineProvider.class);
		Iterator<ProcessEngineProvider> iterator = serviceLoader.iterator();
		if (iterator.hasNext()) {
			ProcessEngineProvider provider = iterator.next();
			return provider.getProcessEngine(engineName);

		}
		return null;
	}

	/*
	 * 2. Create Group Association for a User based on AAF Permissions
	 */
	public static void createGroupAssociation(List<GroupAssociation> groupAssociationList,
			IdentityService identityService, String userName, HttpServletRequest hReq) throws Exception {
		List<String> authorizedGroupIds = new ArrayList<String>();
		if (groupAssociationList != null && groupAssociationList.size() > 0) {

			for (GroupAssociation grpAssociation : groupAssociationList) {

				AafPermission aafPermission = AttCamundaUserAuthorizationUtil
						.aafPermissionNotEmpty(grpAssociation.getAafPermission());
				CamundaGroup grp = AttCamundaUserAuthorizationUtil.camundaGroupNotEmpty(grpAssociation.getCamGroup());

				// check AAF CADI permissions available
				boolean permAuthorized = hReq.isUserInRole(aafPermission.toString());				
				if (permAuthorized) {
					createGroupMembership(identityService, grp.getId(), userName);
					authorizedGroupIds.add(grp.getId());
				} else {
					logger.debug("AAF GROUP PERMISSION DOES NOT EXISTS IN AAF {}", SanitizeUtils.sanitizeLogData(aafPermission.toString()));
				}
			}

		}else{
			logger.debug("AAF GROUP PERMISSION IS EMPTY IN AJSC-AAF-CAMUNDA.YAML FILE");
		}
		// delete revoked group association
		deleteGroupMembership(identityService, userName, authorizedGroupIds);

	}

	/*
	 * 2.a create group membership
	 */
	private static void createGroupMembership(IdentityService identityService, String groupName, String aafUserName) {
		if (identityService.createUserQuery().userId(aafUserName).memberOfGroup(groupName).count() == 0) {
			identityService.createMembership(aafUserName, groupName);
		}
	}

	// 2.b delete group membership for revoked memberships
	private static void deleteGroupMembership(IdentityService identityService, String userName,
			List<String> authorizedGroupIds) {
		GroupQuery groupQuery = identityService.createGroupQuery();
		List<Group> groupList = groupQuery.groupMember(userName).list();
		if (groupList != null && groupList.size() > 0) {
			for (Group group : groupList) {
				String groupId = group.getId();
				if (!authorizedGroupIds.contains(groupId)) {
					if (identityService.createUserQuery().userId(userName).memberOfGroup(groupId).count() > 0) {
						logger.debug("Deleted Revoked userName {} for a group {}", SanitizeUtils.sanitizeLogData(userName), groupId);
						identityService.deleteMembership(userName, groupId);
					}
				}
			}
		}
	}

	/*
	 * 3. Create User Authorization Association for a User based on AAF
	 * Permissions
	 */
	public static void createUserAssociation(List<AuthorizationGrant> userAuthorizationGrantList,
			AuthorizationService authorizationService, String userName, HttpServletRequest hReq) throws Exception {

		if (userAuthorizationGrantList != null && userAuthorizationGrantList.size() > 0) {
			for (AuthorizationGrant userAuth : userAuthorizationGrantList) {

				AafPermission aafPermission = AttCamundaUserAuthorizationUtil
						.aafPermissionNotEmpty(userAuth.getAafPermission());

				// check AAF CADI permissions available
				boolean permAuthorized = hReq.isUserInRole(aafPermission.toString());
				if (permAuthorized) {
					AttCamundaUserAuthorizationUtil.createUserAuthorization(userAuth.getCamAuthorizations(),
							authorizationService, userName, AUTH_TYPE_GRANT);
				} else {
					logger.debug("AAF PERMISSION DOES NOT EXISTS IN AAF {}", SanitizeUtils.sanitizeLogData(aafPermission.toString()));
				}
			}

		}else{
			logger.debug("UserAssociation is Empty AJSC-AAF-Camunda.yaml file");
		}
	}

	// Provide user and group authorization access to login user
	// authentication
	public static UserAuthentication setAuthenticationforUser(List<Group> groupList,
			AuthorizationService authorizationService, String userName, String engineName, String appName)
			throws Exception {
		HashSet<String> authorizedApps = new HashSet<String>();
		UserAuthentication newAuthentication = null;
		// transform into array of strings:
		List<String> groupIds = new ArrayList<String>();
		for (Group group : groupList) {
			groupIds.add(group.getId());
		}
		for (String application : CamundaConstants.APPS) {
			if (isAuthorizedForApp(authorizationService, userName, groupIds, application)) {
				authorizedApps.add(application);
			}
		}
		// authorizedApps.add("admin");
		authorizedApps.add(CamundaConstants.DEFAULT_APP_WELCOME);
		if (authorizedApps.contains(appName)) {
			newAuthentication = new UserAuthentication(userName, engineName);
			if (groupIds.size() > 0) {
				newAuthentication.setGroupIds(groupIds);
			}
			newAuthentication.setAuthorizedApps(authorizedApps);

		} else {
			throw new Exception("Invalid permission to access the application.");
		}
		return newAuthentication;
	}

	/*
	 * check for application permission
	 */
	public static boolean isAuthorizedForApp(AuthorizationService authorizationService, String username,
			List<String> groupIds, String application) {
		logger.debug("isAuthorizedForApp validating");
		return authorizationService.isUserAuthorized(username, groupIds, ACCESS, APPLICATION, application);
	}

	/*
	 * capture cadi firstname and lastname
	 */
	public static User setCadiFirstLastName(Principal principal) throws Exception {
		logger.debug("setCadiFirstLastName method start");

		principalNotNULL(principal);

		String name = principal.getName();
		User user = setUser(name, name, name);

		if (principal instanceof CSPPrincipal) {
			CSPPrincipal<?> cspPrincipal = (CSPPrincipal<?>) principal;
			user = setUser(cspPrincipal.getHRFirstName(), cspPrincipal.getHRLastName(), cspPrincipal.getName());

		} else if (principal instanceof CachedBasicPrincipal) {
			CachedBasicPrincipal cachedBasicPrincipal = (CachedBasicPrincipal) principal;
			user = setUser(cachedBasicPrincipal.getShortName(), cachedBasicPrincipal.getShortName(),
					cachedBasicPrincipal.getName());
		}
		return user;
	}

	private static User setUser(String fName, String lName, String userId) throws Exception {
		if (!StringUtils.isNotBlank(userId)) {
			throw new Exception(CamundaConstants.AAF_PRINCIPAL_USER_ID_EMPTY + " AAF Principal USER_ID is EMPTY");
		}
		User user = new AttCamundaUser();
		user.setFirstName(fName);
		user.setLastName(lName);
		user.setId(userId);
		return user;
	}

	private static void principalNotNULL(Principal principal) throws Exception {
		if (principal == null) {
			throw new Exception(CamundaConstants.AAF_PRINCIPAL_NULL + " AAF Principal is NULL");
		}
	}
}
