package com.att.api.framework.ajsc.camunda.config;


import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.att.api.framework.ajsc.camunda.filter.AttCamundaAuthorizationFilter;
import com.att.api.framework.ajsc.camunda.utils.CamundaConstants;

@Configuration
public class AuthorizationFilterConfig {
	@Value("${com.att.ajsc.camunda.contextPath:/camunda}")
	private String CAMUNDA_SUFFIX;
	
	
	@Bean	
	public FilterRegistrationBean camundaAuthFilterRegistration() {
		FilterRegistrationBean registration = new FilterRegistrationBean();
		registration.setFilter(aafAuthFilter());
		registration.setUrlPatterns(getPatternUrls());
		//registration.addUrlPatterns(CAMUNDA_SUFFIX + "/*");
		registration.setName(CamundaConstants.AUTHENTICATION_FILTER);
		return registration;
	}


	@Bean	
	public AttCamundaAuthorizationFilter aafAuthFilter() {
		return new AttCamundaAuthorizationFilter();
	}

	public Set<String> getPatternUrls(){

		Set<String> patternUrls = new HashSet<String>();
		patternUrls.add(CAMUNDA_SUFFIX + "/*");
		
		String patternUrl = System.getProperty("camunda.aaf.authorization.patternUrls");		
		if(patternUrl != null){		
			String[]  userDefinedPatternUrls = patternUrl.split(",");
			for(int i=0;i<userDefinedPatternUrls.length;i++){
				patternUrls.add(userDefinedPatternUrls[i]);
			}
		}

		return patternUrls;
	}


}
