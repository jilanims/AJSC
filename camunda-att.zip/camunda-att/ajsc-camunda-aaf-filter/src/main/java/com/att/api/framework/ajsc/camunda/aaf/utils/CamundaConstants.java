package com.att.api.framework.ajsc.camunda.aaf.utils;

public class CamundaConstants {
	public static final String APP_MARK = "/app/";
	public static final String[] APPS = new String[] { "cockpit", "tasklist", "admin", "welcome" };
	public static final String AUTHENTICATION_FILTER="Authentication Filter";
}
