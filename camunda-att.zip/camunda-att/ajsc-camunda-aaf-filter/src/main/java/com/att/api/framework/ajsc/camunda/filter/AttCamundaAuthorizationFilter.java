package com.att.api.framework.ajsc.camunda.filter;

import java.io.IOException;
import java.security.Principal;
import java.util.List;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.camunda.bpm.engine.AuthorizationService;
import org.camunda.bpm.engine.IdentityService;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.identity.Group;
import org.camunda.bpm.engine.identity.User;
import org.camunda.bpm.webapp.impl.security.SecurityActions;
import org.camunda.bpm.webapp.impl.security.SecurityActions.SecurityAction;
import org.camunda.bpm.webapp.impl.security.auth.Authentications;
import org.camunda.bpm.webapp.impl.security.auth.UserAuthentication;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.api.framework.ajsc.camunda.utils.AttCamundaAafAuthorizationUtil;
import com.att.api.framework.ajsc.camunda.utils.AttCamundaUserAuthorizationUtil;
import com.att.api.framework.ajsc.camunda.utils.CamundaConstants;
import com.att.api.framework.ajsc.camunda.yaml.beans.AjscCamundaIdentityAuthBean;
import com.att.api.framework.ajsc.camunda.yaml.beans.GroupAssociations;
import com.att.api.framework.ajsc.utils.ExceptionUtils;
import com.att.api.framework.ajsc.utils.UtilLib;
import com.att.api.framework.ajsc.utils.logging.LoggingRecordHelper;
import com.att.api.framework.common.logging.Markers;
import com.att.api.framework.common.security.utils.SanitizeUtils;
import com.att.api.framework.common.utils.CommonNames;
import com.att.api.framework.common.utils.ExceptionNames;

/**
 * This security filter maps the user to the camunda user and group management
 *
 * @author jp931e
 */
public class AttCamundaAuthorizationFilter implements Filter {

	private static final Logger logger = LoggerFactory.getLogger(AttCamundaAuthorizationFilter.class);
	private static Logger securityLogger = LoggerFactory.getLogger(CommonNames.SECURITY_LOGGER);

	private static String engineName;
	private static String appName;
	private String aafUserName;
	private IdentityService identityService;
	private ProcessEngine processEngine;
	private AuthorizationService authorizationService;

	@Autowired
	private AjscCamundaIdentityAuthBean ajscCamundaIdentityAuthBean;

	/*@Autowired(required = false)
	private GroupAssociations groupAssociations;*/

	public void init(FilterConfig filterConfig) throws ServletException {
	}

	public void doFilter(final ServletRequest request, final ServletResponse response, final FilterChain chain)
			throws IOException, ServletException {
		final HttpServletRequest httpRequest = (HttpServletRequest) request;
		final HttpServletResponse httpResponse = (HttpServletResponse) response;
		// final String username = UtilLib.getUserNamefromRequest(httpRequest);

		clean();

		String url = httpRequest.getRequestURL().toString();
		logger.info("url::" + SanitizeUtils.sanitizeLogData(url));
		
		request.setAttribute("AAFAuthroizationFilterInvoked", "true");
		
		if (!StringUtils.isNotBlank(url)) {
			ExceptionUtils.handleFilterException(httpRequest, httpResponse,
					ExceptionNames.AUTHZ_NULL_SERVLET_PATH_FAILURE);
			// TODO Need to add logic for dynamic security protocol
			// determination when we add OAUTH capability
			securityLogger.info(Markers.SECURITY, "Security",
					LoggingRecordHelper.createSecurityInfo(CommonNames.SECURITY_AUTHORIZATION_STR,
							CommonNames.SECURITY_PROTOCOL_BASIC_AAF, null, CommonNames.SECURITY_PROTOCOL_DENIED));

			return;
		}

		// get authentication from session
		Authentications authentications = Authentications.getFromSession(httpRequest.getSession());
		try {
			setKnownPrinicipal(httpRequest, authentications, url);
			Authentications.setCurrent(authentications);

			SecurityActions.runWithAuthentications(new SecurityAction<Void>() {
				public Void execute() {
					try {
						chain.doFilter(request, response);
					} catch (Exception e) {
						throw new RuntimeException(e);
					}
					return null;
				}
			}, authentications);
		} catch (Exception e) {
			ExceptionUtils.handleFilterException(httpRequest, httpResponse,
					ExceptionNames.AUTHZ_UNEXPECTED_AAF_ERR_FAILURE, e);
			// TODO Need to add logic for dynamic security protocol
			// determination when we add OAUTH capability
			securityLogger.info(Markers.SECURITY, "Security",
					LoggingRecordHelper.createSecurityInfo(CommonNames.SECURITY_AUTHORIZATION_STR,
							CommonNames.SECURITY_PROTOCOL_BASIC_AAF, null, CommonNames.SECURITY_PROTOCOL_DENIED));

			return;
			// throw new ServletException(e.getMessage());
		} finally {
			Authentications.clearCurrent();
			Authentications.updateSession(httpRequest.getSession(), authentications);
		}
	}

	public void destroy() {
		logger.info("destroy  --->> 1111 ");
		this.clean();
	}

	private void clean() {
		identityService = null;
		authorizationService = null;
		processEngine = null;
		engineName = null;
		appName = null;
		aafUserName = null;
	}

	protected void setKnownPrinicipal(final HttpServletRequest req, Authentications authentications, String url)
			throws Exception {

		String[] appInfo = AttCamundaAafAuthorizationUtil.getAppInfo(url);
		if (null != appInfo) {
			logger.debug("appInfo is ::" + SanitizeUtils.sanitizeLogData(appInfo.toString()));
			engineName = appInfo[1]; // default
			appName = appInfo[0]; // app
			processEngine = AttCamundaAafAuthorizationUtil.lookupProcessEngine(engineName);
			if (null != processEngine) {

				Principal principal = req.getUserPrincipal();
				// 1. user creation
				User user = AttCamundaAafAuthorizationUtil.setCadiFirstLastName(principal);
				aafUserName = principal.getName();
				identityService = processEngine.getIdentityService();
				AttCamundaUserAuthorizationUtil.createUser(identityService, principal, aafUserName, user);

				// 2. Create User Authorization Grant / Association based on
				// AAF Permissions
				authorizationService = processEngine.getAuthorizationService();
				AttCamundaAafAuthorizationUtil.createUserAssociation(
						ajscCamundaIdentityAuthBean.getAuthorizationGrant(), authorizationService, aafUserName, req);
				
				// 3. Create Group Association for a User based on AAF
				// Permissions
				AttCamundaAafAuthorizationUtil.createGroupAssociation(ajscCamundaIdentityAuthBean.getGroupAssociation(),
						identityService, aafUserName, req);

				// 4. Add authorization of application to authentication
				this.setAuthenticationforUser(authentications);

			}
		}
	}

	private void setAuthenticationforUser(Authentications authentications) throws Exception {

		// get user's groups
		final List<Group> groupList = identityService.createGroupQuery().groupMember(aafUserName).list();

		UserAuthentication newAuthentication = AttCamundaAafAuthorizationUtil.setAuthenticationforUser(groupList,
				authorizationService, aafUserName, engineName, appName);

		if (newAuthentication != null) {
			authentications.addAuthentication(newAuthentication);
		} else {
			throw new Exception(CamundaConstants.CAMUNDA_APP_INVALID_AAF_PERMISSION
					+ " Invalid permission to access the application.");
		}
	}

}
