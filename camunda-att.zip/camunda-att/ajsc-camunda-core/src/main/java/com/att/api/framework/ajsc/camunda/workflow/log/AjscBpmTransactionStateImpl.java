package com.att.api.framework.ajsc.camunda.workflow.log;

import java.time.Instant;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;

import com.att.api.framework.common.logging.APITransactionLogger;
import com.att.api.framework.common.logging.TransactionLogger;
import com.att.api.framework.common.state.api.AJSCTransactionStateImpl;
import com.att.api.framework.common.utils.CommonNames;
import com.att.api.framework.common.utils.GUIDHelper;
import com.att.api.framework.jaxb.requestparameters.Pair;
import com.att.api.framework.jaxb.requestparameters.RequestParameters;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

/**
 * Add BPM identifiers to the AJSCTransactionStateImpl for 1T logging.
 * Serialize/deserialize to/from json, so that state can be saved/retrieved from a process variable.
 * Don't serialize fields that are not needed for 1T logging.
 * 
 * @author CB3786
 *
 */
@JsonIgnoreProperties({"auditRecord", "trackingRecord", "requestParameters", "messageHeaderInfo", "servletRequest", "servletResponse", "asyncRequest", "queueSession", "csisystemTimeFormattedStartTime", "utctimeFormattedStartTime", "utctimeFormattedEndTime", "csisystemTimeFormattedEndTime", "ajsc", "rest", "async", "elapsedDuration", "lastInstant", "debugLogger"})
public class AjscBpmTransactionStateImpl extends AJSCTransactionStateImpl {
	public static final String BPM_VARIABLE_NAME = "AJSC_STATE";	// save into BPM vairable using this name
	private static final Logger logger = LoggerFactory.getLogger(AjscBpmTransactionStateImpl.class);		

	private String processDefinitionId;
	private String processInstanceId;
		
	public AjscBpmTransactionStateImpl() {
		super();
	}
	
	
	
	/**
	 * Create new AJSC BPM state from existing state.
	 * Use to create state object to pass to BPM process instance. 
	 * Can update the TransactionContext using: TransactionContext.setTransactionState(AjscBpmTransactionStateImpl.create(TransactionContext.setTransactionState()));
	 * 
	 * @param inState
	 * @return
	 */
	public static AjscBpmTransactionStateImpl create(AJSCTransactionStateImpl inState) {
		
		AjscBpmTransactionStateImpl outState = new AjscBpmTransactionStateImpl();
		BeanUtils.copyProperties(inState, outState);
		return outState;
	}

	
	/**
	 * serialize to json
	 * 
	 * @return
	 */
	public String serializeToJson() throws JsonProcessingException {
		String text = "{}";
		
		try {
			ObjectMapper mapper = new ObjectMapper();
			mapper.registerModule(new JavaTimeModule());
			
			text =  mapper.writeValueAsString(this);
			
		} catch (JsonProcessingException e) {
			logger.error("failed to serialize state, exception={}", e);			
			text = "{}";
		}
		
		return text;
	}
	
	/**
	 * deserialize from json
	 * 
	 * @param text
	 * @return
	 */
	public static AjscBpmTransactionStateImpl deserializeFromJson(String text, String conversationId) {

		AjscBpmTransactionStateImpl state = null;
		
		try {
			ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.registerModule(new JavaTimeModule());
			
			state =  mapper.readValue(text, AjscBpmTransactionStateImpl.class);
			TransactionLogger transactionLogger = new APITransactionLogger("");
			state.setDebugLogger(transactionLogger);
		} catch (Exception e) {
			logger.error("failed to deserialize state from: {}, exception={}", text, e);
			state = new AjscBpmTransactionStateImpl();
			//String conversationId = GUIDHelper.createCSIConversationId("");
			state.setConversationId(conversationId);
			//String transactionId = GUIDHelper.createUniqueTransactionId(DEFAULT_TRANSACTION_ID_PREFIX);

			final Instant startTime = Instant.now();
			state.setStartTime(startTime);
		}
		
		return state;
	}
	

	/**
	 * @return the processDefinitionId
	 */
	public String getProcessDefinitionId() {
		return processDefinitionId;
	}

	/**
	 * @param processDefinitionId the processDefinitionId to set
	 */
	public void setProcessDefinitionId(String processDefinitionId) {
		this.processDefinitionId = processDefinitionId;
	}

	/**
	 * @return the processInstanceId
	 */
	public String getProcessInstanceId() {
		return processInstanceId;
	}

	/**
	 * @param processInstanceId the processInstanceId to set
	 */
	public void setProcessInstanceId(String processInstanceId) {
		this.processInstanceId = processInstanceId;
	}

}
