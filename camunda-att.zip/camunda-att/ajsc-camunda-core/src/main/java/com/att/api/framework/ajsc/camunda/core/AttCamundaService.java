package com.att.api.framework.ajsc.camunda.core;

import javax.servlet.http.HttpServletRequest;

public class AttCamundaService {
	
	
	private static HttpServletRequest httpRequest;
	

	public static HttpServletRequest getHttpRequest() {
		return httpRequest;
	}

	public static void setHttpRequest(HttpServletRequest httpRequest) {
		AttCamundaService.httpRequest = httpRequest;
	}
    
}