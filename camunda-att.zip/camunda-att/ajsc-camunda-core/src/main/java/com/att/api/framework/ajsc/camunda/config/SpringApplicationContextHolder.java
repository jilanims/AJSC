package com.att.api.framework.ajsc.camunda.config;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

/**
*
* @author Jilani
*
*/
@Component
public class SpringApplicationContextHolder implements ApplicationContextAware {
	
	/*//@Autowired instead of autowired, we can use below method in Delegate class
	 * private RuntimeService runtimeService = SpringApplicationContextHolder.getApplicationContext()
			.getBean(RuntimeService.class);*/

	private static ApplicationContext applicationContext = null;

	public static ApplicationContext getApplicationContext() {
		return applicationContext;
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		SpringApplicationContextHolder.applicationContext = applicationContext;
	}
}
