package com.att.api.framework.ajsc.camunda.workflow.log;

import java.time.Duration;
import java.time.Instant;

import org.camunda.bpm.engine.ProcessEngineServices;
import org.camunda.bpm.engine.RepositoryService;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.repository.ProcessDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import com.att.api.framework.common.utils.CommonNames;

public class CamundaUtilities {

	private static final Logger logger = LoggerFactory.getLogger(CamundaUtilities.class);

	public static String getProcessName(DelegateExecution execution) {
		String processName = null;
		ProcessEngineServices processEngine = execution.getProcessEngineServices();
		RepositoryService repositoryService = processEngine.getRepositoryService();
		ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery()
				.processDefinitionId(execution.getProcessDefinitionId()).singleResult();
		if (processDefinition != null) {
			processName = processDefinition.getName();
		}
		return processName;
	}

	public static void setCamundaWFConvTrans(String executionId, RuntimeService runtimeService) {

		String conversationId = MDC.get(CamundaLoggingConstants.MDC_CONVERSATION_ID);
		if (!"".equals(conversationId)
				&& "".equals(runtimeService.getVariable(executionId, CommonNames.HEADER_ATT_CONVERSATION_ID))) {
			runtimeService.setVariable(executionId, CommonNames.HEADER_ATT_CONVERSATION_ID, conversationId);
		}
		String transactionId = MDC.get(CamundaLoggingConstants.MDC_TRANSACTION_ID);
		if (!"".equals(transactionId)
				&& "".equals(runtimeService.getVariable(executionId, CommonNames.HEADER_ATT_UNIQUE_TXN_ID))) {
			runtimeService.setVariable(executionId, CommonNames.HEADER_ATT_UNIQUE_TXN_ID, conversationId);
		}
	}

	public static void clearMDCLoggingForException() {
		if (MDC.get(CamundaLoggingConstants.MDC_WF_START_TIME) != null) {
			Instant endTime = Instant.now();
			MDC.put(CamundaLoggingConstants.MDC_WF_END_TIME, endTime.toString());
			long wf_duration = Duration
					.between(Instant.parse(MDC.get(CamundaLoggingConstants.MDC_WF_START_TIME).toString()), endTime)
					.toMillis();
			MDC.put(CamundaLoggingConstants.MDC_WF_DURATION, String.valueOf(wf_duration));
			
			//log the total workflow  duration
			logger.info(CamundaUtilities.logWF());
			MDC.clear();
		}
	}

	public static void cleanWFMDCLogging() {
		MDC.remove(CamundaLoggingConstants.MDC_PROCESS_INSTANCE_ID);
		MDC.remove(CamundaLoggingConstants.MDC_PROCESS_DEFINITION_ID);
		MDC.remove(CamundaLoggingConstants.MDC_WF_ACTIVITY_INSTANCE_ID);
		MDC.remove(CamundaLoggingConstants.MDC_WF_START_TIME);
		MDC.remove(CamundaLoggingConstants.MDC_WF_END_TIME);
		MDC.remove(CamundaLoggingConstants.MDC_WF_DURATION);
	}

	public static void clearActivityMDCLogging() {
		MDC.remove(CamundaLoggingConstants.MDC_ACTIVITY_INSTANCE_ID);
		MDC.remove(CamundaLoggingConstants.MDC_ACTIVITY_START_TIME);
		MDC.remove(CamundaLoggingConstants.MDC_ACTIVITY_END_TIME);
		MDC.remove(CamundaLoggingConstants.MDC_ACTIVITY_DURATION);
	}
	
	public static String logWF(){
		StringBuffer sb = new StringBuffer("Process Definition Id:");
		sb.append(MDC.get(CamundaLoggingConstants.MDC_PROCESS_DEFINITION_ID));
		sb.append(" Process Instance Id:");
		sb.append(CamundaLoggingConstants.MDC_PROCESS_INSTANCE_ID);
		sb.append("Total duration of the complete workflow is");
		sb.append(MDC.get(CamundaLoggingConstants.MDC_WF_DURATION));
		return sb.toString();
	}
	
	public static String logActivity(){
		StringBuffer sb = new StringBuffer("Process Activity Id:");
		sb.append(MDC.get(CamundaLoggingConstants.MDC_WF_ACTIVITY_INSTANCE_ID));
		sb.append(" Process Instance Id:");
		sb.append(CamundaLoggingConstants.MDC_PROCESS_INSTANCE_ID);
		sb.append("Total duration of the complete Activity Instance is");
		sb.append(MDC.get(CamundaLoggingConstants.MDC_ACTIVITY_DURATION));
		return sb.toString();
	}

}
