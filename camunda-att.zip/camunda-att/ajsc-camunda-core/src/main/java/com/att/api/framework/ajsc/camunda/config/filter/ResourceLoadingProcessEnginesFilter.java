package com.att.api.framework.ajsc.camunda.config.filter;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;

import org.camunda.bpm.spring.boot.starter.property.WebappProperty;
import org.camunda.bpm.spring.boot.starter.webapp.filter.ResourceLoaderDependingFilter;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;

/**
*
* @author Jilani
*
*/
public class ResourceLoadingProcessEnginesFilter extends ProcessEnginesFilter implements ResourceLoaderDependingFilter {
	
  private ResourceLoader resourceLoader;
  
  private WebappProperty webAppProperty;
  
  @Override
  protected String getWebResourceContents(String name) throws IOException {
    InputStream is = null;

    try {      	
      name = name.replace(CAMUNDA_SUFFIX, "");
      Resource resource = resourceLoader.getResource("classpath:"+ webAppProperty.getWebjarClasspath() + name);
      is = resource.getInputStream();

      BufferedReader reader = new BufferedReader(new InputStreamReader(is));

      StringWriter writer = new StringWriter();
      String line = null;

      while ((line = reader.readLine()) != null) {
        writer.write(line);
        writer.append("\n");
      }

      return writer.toString();
    } finally {
      if (is != null) {
        try {
          is.close();
        } catch (IOException e) {
        }
      }
    }
  }

  /**
   * @return the resourceLoader
   */
  public ResourceLoader getResourceLoader() {
    return resourceLoader;
  }

  /**
   * @param resourceLoader
   *          the resourceLoader to set
   */
  public void setResourceLoader(ResourceLoader resourceLoader) {
    this.resourceLoader = resourceLoader;
  }

	@Override
	public void setWebappProperty(WebappProperty webAppProperty) {
		this.webAppProperty=webAppProperty;
	}

}
