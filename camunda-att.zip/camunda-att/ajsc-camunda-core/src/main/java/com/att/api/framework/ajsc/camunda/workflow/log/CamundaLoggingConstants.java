package com.att.api.framework.ajsc.camunda.workflow.log;

public class CamundaLoggingConstants {
	public static final String MDC_HOSTNAME = "hostName";
	public static final String MDC_HOSTADDRESS = "hostAddress";
	public static final String MDC_CONVERSATION_ID = "conversationId";
	public static final String MDC_TRANSACTION_ID = "transactionId";
	// Activity start and end tracing
	public static final String MDC_ACTIVITY_INSTANCE_ID = "ActivityInstanceId";
	public static final String MDC_ACTIVITY_START_TIME = "startTime";
	public static final String MDC_ACTIVITY_END_TIME = "endTime";
	public static final String MDC_ACTIVITY_DURATION = "duration";
	// WF start and End tracing
	public static final String MDC_WF_ACTIVITY_INSTANCE_ID = "wf_ActivityInstanceId";
	public static final String MDC_WF_START_TIME = "wf_startTime";
	public static final String MDC_WF_END_TIME = "wf_endTime";
	public static final String MDC_WF_DURATION = "wf_duration";

	public static final String EVENT_START = "start";
	public static final String EVENT_END = "end";
	public static final String MDC_PROCESS_INSTANCE_ID = "ProcessInstanceId";
	public static final String MDC_PROCESS_DEFINITION_ID = "ProcessDefinitionId";
}
