package com.att.api.framework.ajsc.camunda.workflow.log;

import java.util.Map;
import java.util.concurrent.Callable;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.camunda.bpm.application.InvocationContext;
import org.camunda.bpm.application.ProcessApplication;
import org.camunda.bpm.application.ProcessApplicationExecutionException;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.BaseDelegateExecution;
import org.camunda.bpm.spring.boot.starter.SpringBootProcessApplication;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.att.api.framework.common.logging.TransactionContext;
import com.att.api.framework.common.state.api.AJSCTransactionStateImpl;
import com.att.api.framework.common.utils.CommonNames;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

@ProcessApplication
public class CustomProcessEnginePlugin extends SpringBootProcessApplication {

	private static final Logger logger = LoggerFactory.getLogger(CustomProcessEnginePlugin.class);

	@Autowired
	private RuntimeService runtimeService;

	@Value("${ajsc.camunda.workflow.transaction.state.enable:true}")
	private String bpmTransactionState;

	// @Lazy
	@Autowired
	private HttpServletRequest request;

	/*
	 * @Override public ExecutionListener getExecutionListener() { return new
	 * GlobalExecutionListener(); }
	 */

	@SuppressWarnings("unused")
	@Override
	public <T> T execute(Callable<T> callable, InvocationContext invocationContext)
			throws ProcessApplicationExecutionException {
		if (callable != null) {
			try {
				if (invocationContext != null) {
					try {

						if ("true".equals(bpmTransactionState)) {
							if (logger.isDebugEnabled()) {
								logger.debug("Entering ProcessApplication::execute... ");
							}
							BaseDelegateExecution execution = invocationContext.getExecution();
							AJSCTransactionStateImpl inState = (AJSCTransactionStateImpl) TransactionContext
									.get(CommonNames.TRANSACTION_STATE);

							if (null != inState) {
								// Transaction Log
								if (!"".equals(runtimeService.getVariable(execution.getId(),
										AjscBpmTransactionStateImpl.BPM_VARIABLE_NAME))) {
									AjscBpmTransactionStateImpl ajscBPM = AjscBpmTransactionStateImpl.create(inState);
									ajscBPM.setProcessInstanceId(execution.getId());

									Map<String, String> headerMap = (Map<String, String>) request
											.getAttribute(CommonNames.REQUEST_HEADER_MAP);
									runtimeService.setVariable(execution.getId(),
											CommonNames.HEADER_ATT_CONVERSATION_ID,
											headerMap.get(CommonNames.HEADER_ATT_CONVERSATION_ID));
									runtimeService.setVariable(execution.getId(),
											AjscBpmTransactionStateImpl.BPM_VARIABLE_NAME, ajscBPM.serializeToJson());
								}
							} else {
								String inStateStr = (String) runtimeService.getVariable(execution.getId(),
										AjscBpmTransactionStateImpl.BPM_VARIABLE_NAME);

								if (StringUtils.isNotBlank(inStateStr)) {
									AjscBpmTransactionStateImpl deserializeObject = new AjscBpmTransactionStateImpl();
									String conversationId = (String) runtimeService.getVariable(execution.getId(),
											CommonNames.HEADER_ATT_CONVERSATION_ID);
									deserializeObject = deserializeObject.deserializeFromJson(inStateStr, conversationId);
									TransactionContext.put(CommonNames.TRANSACTION_STATE, deserializeObject);
								}
							}
						}
					} catch (Exception e) {
						// TODO
					}
				}
				return super.execute(callable);
			} catch (ProcessApplicationExecutionException e) {
				// CamundaUtilities.clearMDCLoggingForException();
				throw e;
			} finally {
			}
		} else {
			throw new IllegalStateException("Callable is null");
		}
	}

	public String serializeToJson(Object obj) throws JsonProcessingException {

		ObjectMapper mapper = new ObjectMapper();
		mapper.registerModule(new JavaTimeModule());

		return mapper.writeValueAsString(this);
	}
	/* Added by Jilani for Camunda workflow Logging tracking end */

}
