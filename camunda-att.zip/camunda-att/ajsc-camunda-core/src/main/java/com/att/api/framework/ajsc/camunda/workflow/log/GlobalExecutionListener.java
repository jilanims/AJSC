package com.att.api.framework.ajsc.camunda.workflow.log;

import java.time.Instant;
import java.time.Duration;

//import org.apache.log4j.MDC;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.ExecutionListener;
import org.camunda.bpm.model.bpmn.instance.EndEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

/**
 * A listener that is registered to listen to all process activity events..
 */
public class GlobalExecutionListener implements ExecutionListener {

	private static final Logger LOGGER = LoggerFactory.getLogger(GlobalExecutionListener.class);

	@Override
	public void notify(final DelegateExecution execution) throws Exception {
		String processName = CamundaUtilities.getProcessName(execution);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Process Instance Id: " + execution.getProcessInstanceId());
			LOGGER.debug("ProcessName: " + processName);
			LOGGER.debug("Process Definition Id: " + execution.getProcessDefinitionId());
			LOGGER.debug("ActivityInstanceId: " + execution.getActivityInstanceId());
			LOGGER.debug("CurrentActivityId: " + execution.getCurrentActivityId());
			LOGGER.debug("Current Activity Name: " + execution.getCurrentActivityName());
			LOGGER.debug("Event Name: " + execution.getEventName() + "\n\n");

		}

		if (execution.getEventName().equals(ExecutionListener.EVENTNAME_TAKE)) {
			return;
		}

		/*MDC.put(CamundaLoggingConstants.MDC_HOSTNAME, ServiceNetworkInfo.getHostName());
		MDC.put(CamundaLoggingConstants.MDC_HOSTADDRESS, ServiceNetworkInfo.getHostAddress());
*/
		if (execution.getActivityInstanceId() != null) {

			String activityInstanceId = execution.getActivityInstanceId();
			// Start Event
			if (MDC.get(CamundaLoggingConstants.MDC_ACTIVITY_INSTANCE_ID) == null
					&& execution.getEventName().equals(CamundaLoggingConstants.EVENT_START)) {
				MDC.put(CamundaLoggingConstants.MDC_ACTIVITY_INSTANCE_ID, activityInstanceId);
				final Instant startTime = Instant.now();
				MDC.put(CamundaLoggingConstants.MDC_ACTIVITY_START_TIME, startTime.toString());

				// workflow start time
				if (MDC.get(CamundaLoggingConstants.MDC_WF_ACTIVITY_INSTANCE_ID) == null) {
					MDC.put(CamundaLoggingConstants.MDC_PROCESS_INSTANCE_ID, execution.getProcessInstanceId());
					MDC.put(CamundaLoggingConstants.MDC_PROCESS_DEFINITION_ID, execution.getProcessDefinitionId());
					MDC.put(CamundaLoggingConstants.MDC_WF_ACTIVITY_INSTANCE_ID, activityInstanceId);
					MDC.put(CamundaLoggingConstants.MDC_WF_START_TIME, startTime.toString());
				}
			}

			// End Event
			if (MDC.get(CamundaLoggingConstants.MDC_ACTIVITY_INSTANCE_ID) != null
					&& MDC.get(CamundaLoggingConstants.MDC_ACTIVITY_INSTANCE_ID).equals(activityInstanceId)
					&& execution.getEventName().equals(CamundaLoggingConstants.EVENT_END)) {

				Instant endTime = Instant.now();
				MDC.put(CamundaLoggingConstants.MDC_ACTIVITY_END_TIME, endTime.toString());
				long duration = Duration
						.between(Instant.parse(MDC.get(CamundaLoggingConstants.MDC_ACTIVITY_START_TIME).toString()),
								endTime)
						.toMillis();
				MDC.put(CamundaLoggingConstants.MDC_ACTIVITY_DURATION, String.valueOf(duration));

				// clear Activity MDC logging
				CamundaUtilities.clearActivityMDCLogging();

				boolean isEndEvent = execution.getBpmnModelElementInstance() instanceof EndEvent;
				if (isEndEvent) {
					// workflow start time
					if (MDC.get(CamundaLoggingConstants.MDC_WF_ACTIVITY_INSTANCE_ID) != null) {
						// MDC.put(wf_activityInstanceId, activityInstanceId);
						MDC.put(CamundaLoggingConstants.MDC_WF_END_TIME, endTime.toString());
						long wf_duration = Duration
								.between(Instant.parse(MDC.get(CamundaLoggingConstants.MDC_WF_START_TIME).toString()),
										endTime)
								.toMillis();
						MDC.put(CamundaLoggingConstants.MDC_WF_DURATION, String.valueOf(wf_duration));
					}

					// clear workflow MDC logging
					CamundaUtilities.cleanWFMDCLogging();
				}

			}
		}
	}
}
