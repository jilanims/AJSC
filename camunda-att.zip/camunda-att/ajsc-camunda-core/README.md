
# Adding to your project
In order to add this feature to your project you need to have this dependency present in your pom.
```xml
<dependency>
	<groupId>com.att.ajsc</groupId>
	<artifactId>sdk-java-camunda-core</artifactId>
	<version>6.0-SNAPSHOT</version>
</dependency>
```